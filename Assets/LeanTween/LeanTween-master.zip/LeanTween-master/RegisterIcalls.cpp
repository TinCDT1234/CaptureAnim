void RegisterAllStrippedInternalCalls()
{
	//Start Registrations for type : UnityEngine.AndroidJNI

		//System.Boolean UnityEngine.AndroidJNI::CallBooleanMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
		void Register_UnityEngine_AndroidJNI_CallBooleanMethod();
		Register_UnityEngine_AndroidJNI_CallBooleanMethod();

		//System.Boolean UnityEngine.AndroidJNI::CallStaticBooleanMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
		void Register_UnityEngine_AndroidJNI_CallStaticBooleanMethod();
		Register_UnityEngine_AndroidJNI_CallStaticBooleanMethod();

		//System.Boolean UnityEngine.AndroidJNI::GetBooleanArrayElement(System.IntPtr,System.Int32)
		void Register_UnityEngine_AndroidJNI_GetBooleanArrayElement();
		Register_UnityEngine_AndroidJNI_GetBooleanArrayElement();

		//System.Boolean UnityEngine.AndroidJNI::GetBooleanField(System.IntPtr,System.IntPtr)
		void Register_UnityEngine_AndroidJNI_GetBooleanField();
		Register_UnityEngine_AndroidJNI_GetBooleanField();

		//System.Boolean UnityEngine.AndroidJNI::GetStaticBooleanField(System.IntPtr,System.IntPtr)
		void Register_UnityEngine_AndroidJNI_GetStaticBooleanField();
		Register_UnityEngine_AndroidJNI_GetStaticBooleanField();

		//System.Boolean UnityEngine.AndroidJNI::IsAssignableFrom(System.IntPtr,System.IntPtr)
		void Register_UnityEngine_AndroidJNI_IsAssignableFrom();
		Register_UnityEngine_AndroidJNI_IsAssignableFrom();

		//System.Boolean UnityEngine.AndroidJNI::IsInstanceOf(System.IntPtr,System.IntPtr)
		void Register_UnityEngine_AndroidJNI_IsInstanceOf();
		Register_UnityEngine_AndroidJNI_IsInstanceOf();

		//System.Boolean UnityEngine.AndroidJNI::IsSameObject(System.IntPtr,System.IntPtr)
		void Register_UnityEngine_AndroidJNI_IsSameObject();
		Register_UnityEngine_AndroidJNI_IsSameObject();

		//System.Boolean[] UnityEngine.AndroidJNI::FromBooleanArray(System.IntPtr)
		void Register_UnityEngine_AndroidJNI_FromBooleanArray();
		Register_UnityEngine_AndroidJNI_FromBooleanArray();

		//System.Byte UnityEngine.AndroidJNI::CallByteMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
		void Register_UnityEngine_AndroidJNI_CallByteMethod();
		Register_UnityEngine_AndroidJNI_CallByteMethod();

		//System.Byte UnityEngine.AndroidJNI::CallStaticByteMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
		void Register_UnityEngine_AndroidJNI_CallStaticByteMethod();
		Register_UnityEngine_AndroidJNI_CallStaticByteMethod();

		//System.Byte UnityEngine.AndroidJNI::GetByteArrayElement(System.IntPtr,System.Int32)
		void Register_UnityEngine_AndroidJNI_GetByteArrayElement();
		Register_UnityEngine_AndroidJNI_GetByteArrayElement();

		//System.Byte UnityEngine.AndroidJNI::GetByteField(System.IntPtr,System.IntPtr)
		void Register_UnityEngine_AndroidJNI_GetByteField();
		Register_UnityEngine_AndroidJNI_GetByteField();

		//System.Byte UnityEngine.AndroidJNI::GetStaticByteField(System.IntPtr,System.IntPtr)
		void Register_UnityEngine_AndroidJNI_GetStaticByteField();
		Register_UnityEngine_AndroidJNI_GetStaticByteField();

		//System.Byte[] UnityEngine.AndroidJNI::FromByteArray(System.IntPtr)
		void Register_UnityEngine_AndroidJNI_FromByteArray();
		Register_UnityEngine_AndroidJNI_FromByteArray();

		//System.Char UnityEngine.AndroidJNI::CallCharMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
		void Register_UnityEngine_AndroidJNI_CallCharMethod();
		Register_UnityEngine_AndroidJNI_CallCharMethod();

		//System.Char UnityEngine.AndroidJNI::CallStaticCharMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
		void Register_UnityEngine_AndroidJNI_CallStaticCharMethod();
		Register_UnityEngine_AndroidJNI_CallStaticCharMethod();

		//System.Char UnityEngine.AndroidJNI::GetCharArrayElement(System.IntPtr,System.Int32)
		void Register_UnityEngine_AndroidJNI_GetCharArrayElement();
		Register_UnityEngine_AndroidJNI_GetCharArrayElement();

		//System.Char UnityEngine.AndroidJNI::GetCharField(System.IntPtr,System.IntPtr)
		void Register_UnityEngine_AndroidJNI_GetCharField();
		Register_UnityEngine_AndroidJNI_GetCharField();

		//System.Char UnityEngine.AndroidJNI::GetStaticCharField(System.IntPtr,System.IntPtr)
		void Register_UnityEngine_AndroidJNI_GetStaticCharField();
		Register_UnityEngine_AndroidJNI_GetStaticCharField();

		//System.Char[] UnityEngine.AndroidJNI::FromCharArray(System.IntPtr)
		void Register_UnityEngine_AndroidJNI_FromCharArray();
		Register_UnityEngine_AndroidJNI_FromCharArray();

		//System.Double UnityEngine.AndroidJNI::CallDoubleMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
		void Register_UnityEngine_AndroidJNI_CallDoubleMethod();
		Register_UnityEngine_AndroidJNI_CallDoubleMethod();

		//System.Double UnityEngine.AndroidJNI::CallStaticDoubleMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
		void Register_UnityEngine_AndroidJNI_CallStaticDoubleMethod();
		Register_UnityEngine_AndroidJNI_CallStaticDoubleMethod();

		//System.Double UnityEngine.AndroidJNI::GetDoubleArrayElement(System.IntPtr,System.Int32)
		void Register_UnityEngine_AndroidJNI_GetDoubleArrayElement();
		Register_UnityEngine_AndroidJNI_GetDoubleArrayElement();

		//System.Double UnityEngine.AndroidJNI::GetDoubleField(System.IntPtr,System.IntPtr)
		void Register_UnityEngine_AndroidJNI_GetDoubleField();
		Register_UnityEngine_AndroidJNI_GetDoubleField();

		//System.Double UnityEngine.AndroidJNI::GetStaticDoubleField(System.IntPtr,System.IntPtr)
		void Register_UnityEngine_AndroidJNI_GetStaticDoubleField();
		Register_UnityEngine_AndroidJNI_GetStaticDoubleField();

		//System.Double[] UnityEngine.AndroidJNI::FromDoubleArray(System.IntPtr)
		void Register_UnityEngine_AndroidJNI_FromDoubleArray();
		Register_UnityEngine_AndroidJNI_FromDoubleArray();

		//System.Int16 UnityEngine.AndroidJNI::CallShortMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
		void Register_UnityEngine_AndroidJNI_CallShortMethod();
		Register_UnityEngine_AndroidJNI_CallShortMethod();

		//System.Int16 UnityEngine.AndroidJNI::CallStaticShortMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
		void Register_UnityEngine_AndroidJNI_CallStaticShortMethod();
		Register_UnityEngine_AndroidJNI_CallStaticShortMethod();

		//System.Int16 UnityEngine.AndroidJNI::GetShortArrayElement(System.IntPtr,System.Int32)
		void Register_UnityEngine_AndroidJNI_GetShortArrayElement();
		Register_UnityEngine_AndroidJNI_GetShortArrayElement();

		//System.Int16 UnityEngine.AndroidJNI::GetShortField(System.IntPtr,System.IntPtr)
		void Register_UnityEngine_AndroidJNI_GetShortField();
		Register_UnityEngine_AndroidJNI_GetShortField();

		//System.Int16 UnityEngine.AndroidJNI::GetStaticShortField(System.IntPtr,System.IntPtr)
		void Register_UnityEngine_AndroidJNI_GetStaticShortField();
		Register_UnityEngine_AndroidJNI_GetStaticShortField();

		//System.Int16[] UnityEngine.AndroidJNI::FromShortArray(System.IntPtr)
		void Register_UnityEngine_AndroidJNI_FromShortArray();
		Register_UnityEngine_AndroidJNI_FromShortArray();

		//System.Int32 UnityEngine.AndroidJNI::AttachCurrentThread()
		void Register_UnityEngine_AndroidJNI_AttachCurrentThread();
		Register_UnityEngine_AndroidJNI_AttachCurrentThread();

		//System.Int32 UnityEngine.AndroidJNI::CallIntMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
		void Register_UnityEngine_AndroidJNI_CallIntMethod();
		Register_UnityEngine_AndroidJNI_CallIntMethod();

		//System.Int32 UnityEngine.AndroidJNI::CallStaticIntMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
		void Register_UnityEngine_AndroidJNI_CallStaticIntMethod();
		Register_UnityEngine_AndroidJNI_CallStaticIntMethod();

		//System.Int32 UnityEngine.AndroidJNI::DetachCurrentThread()
		void Register_UnityEngine_AndroidJNI_DetachCurrentThread();
		Register_UnityEngine_AndroidJNI_DetachCurrentThread();

		//System.Int32 UnityEngine.AndroidJNI::EnsureLocalCapacity(System.Int32)
		void Register_UnityEngine_AndroidJNI_EnsureLocalCapacity();
		Register_UnityEngine_AndroidJNI_EnsureLocalCapacity();

		//System.Int32 UnityEngine.AndroidJNI::GetArrayLength(System.IntPtr)
		void Register_UnityEngine_AndroidJNI_GetArrayLength();
		Register_UnityEngine_AndroidJNI_GetArrayLength();

		//System.Int32 UnityEngine.AndroidJNI::GetIntArrayElement(System.IntPtr,System.Int32)
		void Register_UnityEngine_AndroidJNI_GetIntArrayElement();
		Register_UnityEngine_AndroidJNI_GetIntArrayElement();

		//System.Int32 UnityEngine.AndroidJNI::GetIntField(System.IntPtr,System.IntPtr)
		void Register_UnityEngine_AndroidJNI_GetIntField();
		Register_UnityEngine_AndroidJNI_GetIntField();

		//System.Int32 UnityEngine.AndroidJNI::GetStaticIntField(System.IntPtr,System.IntPtr)
		void Register_UnityEngine_AndroidJNI_GetStaticIntField();
		Register_UnityEngine_AndroidJNI_GetStaticIntField();

		//System.Int32 UnityEngine.AndroidJNI::GetStringUTFLength(System.IntPtr)
		void Register_UnityEngine_AndroidJNI_GetStringUTFLength();
		Register_UnityEngine_AndroidJNI_GetStringUTFLength();

		//System.Int32 UnityEngine.AndroidJNI::GetVersion()
		void Register_UnityEngine_AndroidJNI_GetVersion();
		Register_UnityEngine_AndroidJNI_GetVersion();

		//System.Int32 UnityEngine.AndroidJNI::PushLocalFrame(System.Int32)
		void Register_UnityEngine_AndroidJNI_PushLocalFrame();
		Register_UnityEngine_AndroidJNI_PushLocalFrame();

		//System.Int32 UnityEngine.AndroidJNI::Throw(System.IntPtr)
		void Register_UnityEngine_AndroidJNI_Throw();
		Register_UnityEngine_AndroidJNI_Throw();

		//System.Int32 UnityEngine.AndroidJNI::ThrowNew(System.IntPtr,System.String)
		void Register_UnityEngine_AndroidJNI_ThrowNew();
		Register_UnityEngine_AndroidJNI_ThrowNew();

		//System.Int32[] UnityEngine.AndroidJNI::FromIntArray(System.IntPtr)
		void Register_UnityEngine_AndroidJNI_FromIntArray();
		Register_UnityEngine_AndroidJNI_FromIntArray();

		//System.Int64 UnityEngine.AndroidJNI::CallLongMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
		void Register_UnityEngine_AndroidJNI_CallLongMethod();
		Register_UnityEngine_AndroidJNI_CallLongMethod();

		//System.Int64 UnityEngine.AndroidJNI::CallStaticLongMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
		void Register_UnityEngine_AndroidJNI_CallStaticLongMethod();
		Register_UnityEngine_AndroidJNI_CallStaticLongMethod();

		//System.Int64 UnityEngine.AndroidJNI::GetLongArrayElement(System.IntPtr,System.Int32)
		void Register_UnityEngine_AndroidJNI_GetLongArrayElement();
		Register_UnityEngine_AndroidJNI_GetLongArrayElement();

		//System.Int64 UnityEngine.AndroidJNI::GetLongField(System.IntPtr,System.IntPtr)
		void Register_UnityEngine_AndroidJNI_GetLongField();
		Register_UnityEngine_AndroidJNI_GetLongField();

		//System.Int64 UnityEngine.AndroidJNI::GetStaticLongField(System.IntPtr,System.IntPtr)
		void Register_UnityEngine_AndroidJNI_GetStaticLongField();
		Register_UnityEngine_AndroidJNI_GetStaticLongField();

		//System.Int64[] UnityEngine.AndroidJNI::FromLongArray(System.IntPtr)
		void Register_UnityEngine_AndroidJNI_FromLongArray();
		Register_UnityEngine_AndroidJNI_FromLongArray();

		//System.IntPtr[] UnityEngine.AndroidJNI::FromObjectArray(System.IntPtr)
		void Register_UnityEngine_AndroidJNI_FromObjectArray();
		Register_UnityEngine_AndroidJNI_FromObjectArray();

		//System.Single UnityEngine.AndroidJNI::CallFloatMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
		void Register_UnityEngine_AndroidJNI_CallFloatMethod();
		Register_UnityEngine_AndroidJNI_CallFloatMethod();

		//System.Single UnityEngine.AndroidJNI::CallStaticFloatMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
		void Register_UnityEngine_AndroidJNI_CallStaticFloatMethod();
		Register_UnityEngine_AndroidJNI_CallStaticFloatMethod();

		//System.Single UnityEngine.AndroidJNI::GetFloatArrayElement(System.IntPtr,System.Int32)
		void Register_UnityEngine_AndroidJNI_GetFloatArrayElement();
		Register_UnityEngine_AndroidJNI_GetFloatArrayElement();

		//System.Single UnityEngine.AndroidJNI::GetFloatField(System.IntPtr,System.IntPtr)
		void Register_UnityEngine_AndroidJNI_GetFloatField();
		Register_UnityEngine_AndroidJNI_GetFloatField();

		//System.Single UnityEngine.AndroidJNI::GetStaticFloatField(System.IntPtr,System.IntPtr)
		void Register_UnityEngine_AndroidJNI_GetStaticFloatField();
		Register_UnityEngine_AndroidJNI_GetStaticFloatField();

		//System.Single[] UnityEngine.AndroidJNI::FromFloatArray(System.IntPtr)
		void Register_UnityEngine_AndroidJNI_FromFloatArray();
		Register_UnityEngine_AndroidJNI_FromFloatArray();

		//System.String UnityEngine.AndroidJNI::CallStaticStringMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
		void Register_UnityEngine_AndroidJNI_CallStaticStringMethod();
		Register_UnityEngine_AndroidJNI_CallStaticStringMethod();

		//System.String UnityEngine.AndroidJNI::CallStringMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
		void Register_UnityEngine_AndroidJNI_CallStringMethod();
		Register_UnityEngine_AndroidJNI_CallStringMethod();

		//System.String UnityEngine.AndroidJNI::GetStaticStringField(System.IntPtr,System.IntPtr)
		void Register_UnityEngine_AndroidJNI_GetStaticStringField();
		Register_UnityEngine_AndroidJNI_GetStaticStringField();

		//System.String UnityEngine.AndroidJNI::GetStringField(System.IntPtr,System.IntPtr)
		void Register_UnityEngine_AndroidJNI_GetStringField();
		Register_UnityEngine_AndroidJNI_GetStringField();

		//System.String UnityEngine.AndroidJNI::GetStringUTFChars(System.IntPtr)
		void Register_UnityEngine_AndroidJNI_GetStringUTFChars();
		Register_UnityEngine_AndroidJNI_GetStringUTFChars();

		//System.Void UnityEngine.AndroidJNI::CallStaticVoidMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
		void Register_UnityEngine_AndroidJNI_CallStaticVoidMethod();
		Register_UnityEngine_AndroidJNI_CallStaticVoidMethod();

		//System.Void UnityEngine.AndroidJNI::CallVoidMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
		void Register_UnityEngine_AndroidJNI_CallVoidMethod();
		Register_UnityEngine_AndroidJNI_CallVoidMethod();

		//System.Void UnityEngine.AndroidJNI::DeleteGlobalRef(System.IntPtr)
		void Register_UnityEngine_AndroidJNI_DeleteGlobalRef();
		Register_UnityEngine_AndroidJNI_DeleteGlobalRef();

		//System.Void UnityEngine.AndroidJNI::DeleteLocalRef(System.IntPtr)
		void Register_UnityEngine_AndroidJNI_DeleteLocalRef();
		Register_UnityEngine_AndroidJNI_DeleteLocalRef();

		//System.Void UnityEngine.AndroidJNI::ExceptionClear()
		void Register_UnityEngine_AndroidJNI_ExceptionClear();
		Register_UnityEngine_AndroidJNI_ExceptionClear();

		//System.Void UnityEngine.AndroidJNI::ExceptionDescribe()
		void Register_UnityEngine_AndroidJNI_ExceptionDescribe();
		Register_UnityEngine_AndroidJNI_ExceptionDescribe();

		//System.Void UnityEngine.AndroidJNI::FatalError(System.String)
		void Register_UnityEngine_AndroidJNI_FatalError();
		Register_UnityEngine_AndroidJNI_FatalError();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_AllocObject(System.IntPtr,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_AllocObject();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_AllocObject();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_CallObjectMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[],System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_CallObjectMethod();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_CallObjectMethod();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_CallStaticObjectMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[],System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_CallStaticObjectMethod();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_CallStaticObjectMethod();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_ExceptionOccurred(System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_ExceptionOccurred();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_ExceptionOccurred();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_FindClass(System.String,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_FindClass();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_FindClass();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_FromReflectedField(System.IntPtr,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_FromReflectedField();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_FromReflectedField();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_FromReflectedMethod(System.IntPtr,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_FromReflectedMethod();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_FromReflectedMethod();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_GetFieldID(System.IntPtr,System.String,System.String,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_GetFieldID();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_GetFieldID();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_GetMethodID(System.IntPtr,System.String,System.String,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_GetMethodID();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_GetMethodID();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_GetObjectArrayElement(System.IntPtr,System.Int32,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_GetObjectArrayElement();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_GetObjectArrayElement();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_GetObjectClass(System.IntPtr,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_GetObjectClass();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_GetObjectClass();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_GetObjectField(System.IntPtr,System.IntPtr,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_GetObjectField();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_GetObjectField();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_GetStaticFieldID(System.IntPtr,System.String,System.String,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_GetStaticFieldID();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_GetStaticFieldID();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_GetStaticMethodID(System.IntPtr,System.String,System.String,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_GetStaticMethodID();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_GetStaticMethodID();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_GetStaticObjectField(System.IntPtr,System.IntPtr,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_GetStaticObjectField();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_GetStaticObjectField();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_GetSuperclass(System.IntPtr,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_GetSuperclass();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_GetSuperclass();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_NewBooleanArray(System.Int32,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewBooleanArray();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewBooleanArray();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_NewByteArray(System.Int32,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewByteArray();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewByteArray();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_NewCharArray(System.Int32,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewCharArray();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewCharArray();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_NewDoubleArray(System.Int32,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewDoubleArray();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewDoubleArray();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_NewFloatArray(System.Int32,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewFloatArray();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewFloatArray();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_NewGlobalRef(System.IntPtr,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewGlobalRef();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewGlobalRef();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_NewIntArray(System.Int32,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewIntArray();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewIntArray();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_NewLocalRef(System.IntPtr,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewLocalRef();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewLocalRef();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_NewLongArray(System.Int32,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewLongArray();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewLongArray();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_NewObject(System.IntPtr,System.IntPtr,UnityEngine.jvalue[],System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewObject();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewObject();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_NewObjectArray(System.Int32,System.IntPtr,System.IntPtr,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewObjectArray();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewObjectArray();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_NewShortArray(System.Int32,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewShortArray();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewShortArray();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_NewStringUTF(System.String,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewStringUTF();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_NewStringUTF();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_PopLocalFrame(System.IntPtr,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_PopLocalFrame();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_PopLocalFrame();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_ToBooleanArray(System.Boolean[],System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_ToBooleanArray();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_ToBooleanArray();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_ToByteArray(System.Byte[],System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_ToByteArray();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_ToByteArray();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_ToCharArray(System.Char[],System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_ToCharArray();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_ToCharArray();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_ToDoubleArray(System.Double[],System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_ToDoubleArray();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_ToDoubleArray();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_ToFloatArray(System.Single[],System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_ToFloatArray();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_ToFloatArray();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_ToIntArray(System.Int32[],System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_ToIntArray();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_ToIntArray();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_ToLongArray(System.Int64[],System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_ToLongArray();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_ToLongArray();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_ToObjectArray(System.IntPtr[],System.IntPtr,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_ToObjectArray();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_ToObjectArray();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_ToReflectedField(System.IntPtr,System.IntPtr,System.Boolean,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_ToReflectedField();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_ToReflectedField();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_ToReflectedMethod(System.IntPtr,System.IntPtr,System.Boolean,System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_ToReflectedMethod();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_ToReflectedMethod();

		//System.Void UnityEngine.AndroidJNI::INTERNAL_CALL_ToShortArray(System.Int16[],System.IntPtr&)
		void Register_UnityEngine_AndroidJNI_INTERNAL_CALL_ToShortArray();
		Register_UnityEngine_AndroidJNI_INTERNAL_CALL_ToShortArray();

		//System.Void UnityEngine.AndroidJNI::SetBooleanArrayElement(System.IntPtr,System.Int32,System.Byte)
		void Register_UnityEngine_AndroidJNI_SetBooleanArrayElement();
		Register_UnityEngine_AndroidJNI_SetBooleanArrayElement();

		//System.Void UnityEngine.AndroidJNI::SetBooleanField(System.IntPtr,System.IntPtr,System.Boolean)
		void Register_UnityEngine_AndroidJNI_SetBooleanField();
		Register_UnityEngine_AndroidJNI_SetBooleanField();

		//System.Void UnityEngine.AndroidJNI::SetByteArrayElement(System.IntPtr,System.Int32,System.SByte)
		void Register_UnityEngine_AndroidJNI_SetByteArrayElement();
		Register_UnityEngine_AndroidJNI_SetByteArrayElement();

		//System.Void UnityEngine.AndroidJNI::SetByteField(System.IntPtr,System.IntPtr,System.Byte)
		void Register_UnityEngine_AndroidJNI_SetByteField();
		Register_UnityEngine_AndroidJNI_SetByteField();

		//System.Void UnityEngine.AndroidJNI::SetCharArrayElement(System.IntPtr,System.Int32,System.Char)
		void Register_UnityEngine_AndroidJNI_SetCharArrayElement();
		Register_UnityEngine_AndroidJNI_SetCharArrayElement();

		//System.Void UnityEngine.AndroidJNI::SetCharField(System.IntPtr,System.IntPtr,System.Char)
		void Register_UnityEngine_AndroidJNI_SetCharField();
		Register_UnityEngine_AndroidJNI_SetCharField();

		//System.Void UnityEngine.AndroidJNI::SetDoubleArrayElement(System.IntPtr,System.Int32,System.Double)
		void Register_UnityEngine_AndroidJNI_SetDoubleArrayElement();
		Register_UnityEngine_AndroidJNI_SetDoubleArrayElement();

		//System.Void UnityEngine.AndroidJNI::SetDoubleField(System.IntPtr,System.IntPtr,System.Double)
		void Register_UnityEngine_AndroidJNI_SetDoubleField();
		Register_UnityEngine_AndroidJNI_SetDoubleField();

		//System.Void UnityEngine.AndroidJNI::SetFloatArrayElement(System.IntPtr,System.Int32,System.Single)
		void Register_UnityEngine_AndroidJNI_SetFloatArrayElement();
		Register_UnityEngine_AndroidJNI_SetFloatArrayElement();

		//System.Void UnityEngine.AndroidJNI::SetFloatField(System.IntPtr,System.IntPtr,System.Single)
		void Register_UnityEngine_AndroidJNI_SetFloatField();
		Register_UnityEngine_AndroidJNI_SetFloatField();

		//System.Void UnityEngine.AndroidJNI::SetIntArrayElement(System.IntPtr,System.Int32,System.Int32)
		void Register_UnityEngine_AndroidJNI_SetIntArrayElement();
		Register_UnityEngine_AndroidJNI_SetIntArrayElement();

		//System.Void UnityEngine.AndroidJNI::SetIntField(System.IntPtr,System.IntPtr,System.Int32)
		void Register_UnityEngine_AndroidJNI_SetIntField();
		Register_UnityEngine_AndroidJNI_SetIntField();

		//System.Void UnityEngine.AndroidJNI::SetLongArrayElement(System.IntPtr,System.Int32,System.Int64)
		void Register_UnityEngine_AndroidJNI_SetLongArrayElement();
		Register_UnityEngine_AndroidJNI_SetLongArrayElement();

		//System.Void UnityEngine.AndroidJNI::SetLongField(System.IntPtr,System.IntPtr,System.Int64)
		void Register_UnityEngine_AndroidJNI_SetLongField();
		Register_UnityEngine_AndroidJNI_SetLongField();

		//System.Void UnityEngine.AndroidJNI::SetObjectArrayElement(System.IntPtr,System.Int32,System.IntPtr)
		void Register_UnityEngine_AndroidJNI_SetObjectArrayElement();
		Register_UnityEngine_AndroidJNI_SetObjectArrayElement();

		//System.Void UnityEngine.AndroidJNI::SetObjectField(System.IntPtr,System.IntPtr,System.IntPtr)
		void Register_UnityEngine_AndroidJNI_SetObjectField();
		Register_UnityEngine_AndroidJNI_SetObjectField();

		//System.Void UnityEngine.AndroidJNI::SetShortArrayElement(System.IntPtr,System.Int32,System.Int16)
		void Register_UnityEngine_AndroidJNI_SetShortArrayElement();
		Register_UnityEngine_AndroidJNI_SetShortArrayElement();

		//System.Void UnityEngine.AndroidJNI::SetShortField(System.IntPtr,System.IntPtr,System.Int16)
		void Register_UnityEngine_AndroidJNI_SetShortField();
		Register_UnityEngine_AndroidJNI_SetShortField();

		//System.Void UnityEngine.AndroidJNI::SetStaticBooleanField(System.IntPtr,System.IntPtr,System.Boolean)
		void Register_UnityEngine_AndroidJNI_SetStaticBooleanField();
		Register_UnityEngine_AndroidJNI_SetStaticBooleanField();

		//System.Void UnityEngine.AndroidJNI::SetStaticByteField(System.IntPtr,System.IntPtr,System.Byte)
		void Register_UnityEngine_AndroidJNI_SetStaticByteField();
		Register_UnityEngine_AndroidJNI_SetStaticByteField();

		//System.Void UnityEngine.AndroidJNI::SetStaticCharField(System.IntPtr,System.IntPtr,System.Char)
		void Register_UnityEngine_AndroidJNI_SetStaticCharField();
		Register_UnityEngine_AndroidJNI_SetStaticCharField();

		//System.Void UnityEngine.AndroidJNI::SetStaticDoubleField(System.IntPtr,System.IntPtr,System.Double)
		void Register_UnityEngine_AndroidJNI_SetStaticDoubleField();
		Register_UnityEngine_AndroidJNI_SetStaticDoubleField();

		//System.Void UnityEngine.AndroidJNI::SetStaticFloatField(System.IntPtr,System.IntPtr,System.Single)
		void Register_UnityEngine_AndroidJNI_SetStaticFloatField();
		Register_UnityEngine_AndroidJNI_SetStaticFloatField();

		//System.Void UnityEngine.AndroidJNI::SetStaticIntField(System.IntPtr,System.IntPtr,System.Int32)
		void Register_UnityEngine_AndroidJNI_SetStaticIntField();
		Register_UnityEngine_AndroidJNI_SetStaticIntField();

		//System.Void UnityEngine.AndroidJNI::SetStaticLongField(System.IntPtr,System.IntPtr,System.Int64)
		void Register_UnityEngine_AndroidJNI_SetStaticLongField();
		Register_UnityEngine_AndroidJNI_SetStaticLongField();

		//System.Void UnityEngine.AndroidJNI::SetStaticObjectField(System.IntPtr,System.IntPtr,System.IntPtr)
		void Register_UnityEngine_AndroidJNI_SetStaticObjectField();
		Register_UnityEngine_AndroidJNI_SetStaticObjectField();

		//System.Void UnityEngine.AndroidJNI::SetStaticShortField(System.IntPtr,System.IntPtr,System.Int16)
		void Register_UnityEngine_AndroidJNI_SetStaticShortField();
		Register_UnityEngine_AndroidJNI_SetStaticShortField();

		//System.Void UnityEngine.AndroidJNI::SetStaticStringField(System.IntPtr,System.IntPtr,System.String)
		void Register_UnityEngine_AndroidJNI_SetStaticStringField();
		Register_UnityEngine_AndroidJNI_SetStaticStringField();

		//System.Void UnityEngine.AndroidJNI::SetStringField(System.IntPtr,System.IntPtr,System.String)
		void Register_UnityEngine_AndroidJNI_SetStringField();
		Register_UnityEngine_AndroidJNI_SetStringField();

	//End Registrations for type : UnityEngine.AndroidJNI

	//Start Registrations for type : UnityEngine.AndroidJNIHelper

		//System.Boolean UnityEngine.AndroidJNIHelper::get_debug()
		void Register_UnityEngine_AndroidJNIHelper_get_debug();
		Register_UnityEngine_AndroidJNIHelper_get_debug();

		//System.Void UnityEngine.AndroidJNIHelper::INTERNAL_CALL_CreateJavaProxy(UnityEngine.AndroidJavaProxy,System.IntPtr&)
		void Register_UnityEngine_AndroidJNIHelper_INTERNAL_CALL_CreateJavaProxy();
		Register_UnityEngine_AndroidJNIHelper_INTERNAL_CALL_CreateJavaProxy();

		//System.Void UnityEngine.AndroidJNIHelper::set_debug(System.Boolean)
		void Register_UnityEngine_AndroidJNIHelper_set_debug();
		Register_UnityEngine_AndroidJNIHelper_set_debug();

	//End Registrations for type : UnityEngine.AndroidJNIHelper

	//Start Registrations for type : UnityEngine.Animation

		//System.Boolean UnityEngine.Animation::IsPlaying(System.String)
		void Register_UnityEngine_Animation_IsPlaying();
		Register_UnityEngine_Animation_IsPlaying();

		//System.Boolean UnityEngine.Animation::Play(System.String,UnityEngine.PlayMode)
		void Register_UnityEngine_Animation_Play();
		Register_UnityEngine_Animation_Play();

		//System.Boolean UnityEngine.Animation::PlayDefaultAnimation(UnityEngine.PlayMode)
		void Register_UnityEngine_Animation_PlayDefaultAnimation();
		Register_UnityEngine_Animation_PlayDefaultAnimation();

		//System.Boolean UnityEngine.Animation::get_animateOnlyIfVisible()
		void Register_UnityEngine_Animation_get_animateOnlyIfVisible();
		Register_UnityEngine_Animation_get_animateOnlyIfVisible();

		//System.Boolean UnityEngine.Animation::get_animatePhysics()
		void Register_UnityEngine_Animation_get_animatePhysics();
		Register_UnityEngine_Animation_get_animatePhysics();

		//System.Boolean UnityEngine.Animation::get_isPlaying()
		void Register_UnityEngine_Animation_get_isPlaying();
		Register_UnityEngine_Animation_get_isPlaying();

		//System.Boolean UnityEngine.Animation::get_playAutomatically()
		void Register_UnityEngine_Animation_get_playAutomatically();
		Register_UnityEngine_Animation_get_playAutomatically();

		//System.Int32 UnityEngine.Animation::GetClipCount()
		void Register_UnityEngine_Animation_GetClipCount();
		Register_UnityEngine_Animation_GetClipCount();

		//System.Int32 UnityEngine.Animation::GetStateCount()
		void Register_UnityEngine_Animation_GetStateCount();
		Register_UnityEngine_Animation_GetStateCount();

		//System.Void UnityEngine.Animation::AddClip(UnityEngine.AnimationClip,System.String,System.Int32,System.Int32,System.Boolean)
		void Register_UnityEngine_Animation_AddClip();
		Register_UnityEngine_Animation_AddClip();

		//System.Void UnityEngine.Animation::Blend(System.String,System.Single,System.Single)
		void Register_UnityEngine_Animation_Blend();
		Register_UnityEngine_Animation_Blend();

		//System.Void UnityEngine.Animation::CrossFade(System.String,System.Single,UnityEngine.PlayMode)
		void Register_UnityEngine_Animation_CrossFade();
		Register_UnityEngine_Animation_CrossFade();

		//System.Void UnityEngine.Animation::INTERNAL_CALL_Rewind(UnityEngine.Animation)
		void Register_UnityEngine_Animation_INTERNAL_CALL_Rewind();
		Register_UnityEngine_Animation_INTERNAL_CALL_Rewind();

		//System.Void UnityEngine.Animation::INTERNAL_CALL_Sample(UnityEngine.Animation)
		void Register_UnityEngine_Animation_INTERNAL_CALL_Sample();
		Register_UnityEngine_Animation_INTERNAL_CALL_Sample();

		//System.Void UnityEngine.Animation::INTERNAL_CALL_Stop(UnityEngine.Animation)
		void Register_UnityEngine_Animation_INTERNAL_CALL_Stop();
		Register_UnityEngine_Animation_INTERNAL_CALL_Stop();

		//System.Void UnityEngine.Animation::INTERNAL_CALL_SyncLayer(UnityEngine.Animation,System.Int32)
		void Register_UnityEngine_Animation_INTERNAL_CALL_SyncLayer();
		Register_UnityEngine_Animation_INTERNAL_CALL_SyncLayer();

		//System.Void UnityEngine.Animation::INTERNAL_get_localBounds(UnityEngine.Bounds&)
		void Register_UnityEngine_Animation_INTERNAL_get_localBounds();
		Register_UnityEngine_Animation_INTERNAL_get_localBounds();

		//System.Void UnityEngine.Animation::INTERNAL_set_localBounds(UnityEngine.Bounds&)
		void Register_UnityEngine_Animation_INTERNAL_set_localBounds();
		Register_UnityEngine_Animation_INTERNAL_set_localBounds();

		//System.Void UnityEngine.Animation::Internal_RewindByName(System.String)
		void Register_UnityEngine_Animation_Internal_RewindByName();
		Register_UnityEngine_Animation_Internal_RewindByName();

		//System.Void UnityEngine.Animation::Internal_StopByName(System.String)
		void Register_UnityEngine_Animation_Internal_StopByName();
		Register_UnityEngine_Animation_Internal_StopByName();

		//System.Void UnityEngine.Animation::RemoveClip(UnityEngine.AnimationClip)
		void Register_UnityEngine_Animation_RemoveClip();
		Register_UnityEngine_Animation_RemoveClip();

		//System.Void UnityEngine.Animation::RemoveClip2(System.String)
		void Register_UnityEngine_Animation_RemoveClip2();
		Register_UnityEngine_Animation_RemoveClip2();

		//System.Void UnityEngine.Animation::set_animateOnlyIfVisible(System.Boolean)
		void Register_UnityEngine_Animation_set_animateOnlyIfVisible();
		Register_UnityEngine_Animation_set_animateOnlyIfVisible();

		//System.Void UnityEngine.Animation::set_animatePhysics(System.Boolean)
		void Register_UnityEngine_Animation_set_animatePhysics();
		Register_UnityEngine_Animation_set_animatePhysics();

		//System.Void UnityEngine.Animation::set_clip(UnityEngine.AnimationClip)
		void Register_UnityEngine_Animation_set_clip();
		Register_UnityEngine_Animation_set_clip();

		//System.Void UnityEngine.Animation::set_cullingType(UnityEngine.AnimationCullingType)
		void Register_UnityEngine_Animation_set_cullingType();
		Register_UnityEngine_Animation_set_cullingType();

		//System.Void UnityEngine.Animation::set_playAutomatically(System.Boolean)
		void Register_UnityEngine_Animation_set_playAutomatically();
		Register_UnityEngine_Animation_set_playAutomatically();

		//System.Void UnityEngine.Animation::set_wrapMode(UnityEngine.WrapMode)
		void Register_UnityEngine_Animation_set_wrapMode();
		Register_UnityEngine_Animation_set_wrapMode();

		//UnityEngine.AnimationClip UnityEngine.Animation::get_clip()
		void Register_UnityEngine_Animation_get_clip();
		Register_UnityEngine_Animation_get_clip();

		//UnityEngine.AnimationCullingType UnityEngine.Animation::get_cullingType()
		void Register_UnityEngine_Animation_get_cullingType();
		Register_UnityEngine_Animation_get_cullingType();

		//UnityEngine.AnimationState UnityEngine.Animation::CrossFadeQueued(System.String,System.Single,UnityEngine.QueueMode,UnityEngine.PlayMode)
		void Register_UnityEngine_Animation_CrossFadeQueued();
		Register_UnityEngine_Animation_CrossFadeQueued();

		//UnityEngine.AnimationState UnityEngine.Animation::GetState(System.String)
		void Register_UnityEngine_Animation_GetState();
		Register_UnityEngine_Animation_GetState();

		//UnityEngine.AnimationState UnityEngine.Animation::GetStateAtIndex(System.Int32)
		void Register_UnityEngine_Animation_GetStateAtIndex();
		Register_UnityEngine_Animation_GetStateAtIndex();

		//UnityEngine.AnimationState UnityEngine.Animation::PlayQueued(System.String,UnityEngine.QueueMode,UnityEngine.PlayMode)
		void Register_UnityEngine_Animation_PlayQueued();
		Register_UnityEngine_Animation_PlayQueued();

		//UnityEngine.WrapMode UnityEngine.Animation::get_wrapMode()
		void Register_UnityEngine_Animation_get_wrapMode();
		Register_UnityEngine_Animation_get_wrapMode();

	//End Registrations for type : UnityEngine.Animation

	//Start Registrations for type : UnityEngine.AnimationClip

		//System.Array UnityEngine.AnimationClip::GetEventsInternal()
		void Register_UnityEngine_AnimationClip_GetEventsInternal();
		Register_UnityEngine_AnimationClip_GetEventsInternal();

		//System.Boolean UnityEngine.AnimationClip::get_humanMotion()
		void Register_UnityEngine_AnimationClip_get_humanMotion();
		Register_UnityEngine_AnimationClip_get_humanMotion();

		//System.Boolean UnityEngine.AnimationClip::get_legacy()
		void Register_UnityEngine_AnimationClip_get_legacy();
		Register_UnityEngine_AnimationClip_get_legacy();

		//System.Single UnityEngine.AnimationClip::get_frameRate()
		void Register_UnityEngine_AnimationClip_get_frameRate();
		Register_UnityEngine_AnimationClip_get_frameRate();

		//System.Single UnityEngine.AnimationClip::get_length()
		void Register_UnityEngine_AnimationClip_get_length();
		Register_UnityEngine_AnimationClip_get_length();

		//System.Single UnityEngine.AnimationClip::get_startTime()
		void Register_UnityEngine_AnimationClip_get_startTime();
		Register_UnityEngine_AnimationClip_get_startTime();

		//System.Single UnityEngine.AnimationClip::get_stopTime()
		void Register_UnityEngine_AnimationClip_get_stopTime();
		Register_UnityEngine_AnimationClip_get_stopTime();

		//System.Void UnityEngine.AnimationClip::AddEventInternal(System.Object)
		void Register_UnityEngine_AnimationClip_AddEventInternal();
		Register_UnityEngine_AnimationClip_AddEventInternal();

		//System.Void UnityEngine.AnimationClip::INTERNAL_CALL_ClearCurves(UnityEngine.AnimationClip)
		void Register_UnityEngine_AnimationClip_INTERNAL_CALL_ClearCurves();
		Register_UnityEngine_AnimationClip_INTERNAL_CALL_ClearCurves();

		//System.Void UnityEngine.AnimationClip::INTERNAL_CALL_EnsureQuaternionContinuity(UnityEngine.AnimationClip)
		void Register_UnityEngine_AnimationClip_INTERNAL_CALL_EnsureQuaternionContinuity();
		Register_UnityEngine_AnimationClip_INTERNAL_CALL_EnsureQuaternionContinuity();

		//System.Void UnityEngine.AnimationClip::INTERNAL_get_localBounds(UnityEngine.Bounds&)
		void Register_UnityEngine_AnimationClip_INTERNAL_get_localBounds();
		Register_UnityEngine_AnimationClip_INTERNAL_get_localBounds();

		//System.Void UnityEngine.AnimationClip::INTERNAL_set_localBounds(UnityEngine.Bounds&)
		void Register_UnityEngine_AnimationClip_INTERNAL_set_localBounds();
		Register_UnityEngine_AnimationClip_INTERNAL_set_localBounds();

		//System.Void UnityEngine.AnimationClip::Internal_CreateAnimationClip(UnityEngine.AnimationClip)
		void Register_UnityEngine_AnimationClip_Internal_CreateAnimationClip();
		Register_UnityEngine_AnimationClip_Internal_CreateAnimationClip();

		//System.Void UnityEngine.AnimationClip::SampleAnimation(UnityEngine.GameObject,System.Single)
		void Register_UnityEngine_AnimationClip_SampleAnimation();
		Register_UnityEngine_AnimationClip_SampleAnimation();

		//System.Void UnityEngine.AnimationClip::SetCurve(System.String,System.Type,System.String,UnityEngine.AnimationCurve)
		void Register_UnityEngine_AnimationClip_SetCurve();
		Register_UnityEngine_AnimationClip_SetCurve();

		//System.Void UnityEngine.AnimationClip::SetEventsInternal(System.Array)
		void Register_UnityEngine_AnimationClip_SetEventsInternal();
		Register_UnityEngine_AnimationClip_SetEventsInternal();

		//System.Void UnityEngine.AnimationClip::set_frameRate(System.Single)
		void Register_UnityEngine_AnimationClip_set_frameRate();
		Register_UnityEngine_AnimationClip_set_frameRate();

		//System.Void UnityEngine.AnimationClip::set_legacy(System.Boolean)
		void Register_UnityEngine_AnimationClip_set_legacy();
		Register_UnityEngine_AnimationClip_set_legacy();

		//System.Void UnityEngine.AnimationClip::set_wrapMode(UnityEngine.WrapMode)
		void Register_UnityEngine_AnimationClip_set_wrapMode();
		Register_UnityEngine_AnimationClip_set_wrapMode();

		//UnityEngine.WrapMode UnityEngine.AnimationClip::get_wrapMode()
		void Register_UnityEngine_AnimationClip_get_wrapMode();
		Register_UnityEngine_AnimationClip_get_wrapMode();

	//End Registrations for type : UnityEngine.AnimationClip

	//Start Registrations for type : UnityEngine.AnimationCurve

		//System.Int32 UnityEngine.AnimationCurve::AddKey(System.Single,System.Single)
		void Register_UnityEngine_AnimationCurve_AddKey();
		Register_UnityEngine_AnimationCurve_AddKey();

		//System.Int32 UnityEngine.AnimationCurve::INTERNAL_CALL_AddKey_Internal(UnityEngine.AnimationCurve,UnityEngine.Keyframe&)
		void Register_UnityEngine_AnimationCurve_INTERNAL_CALL_AddKey_Internal();
		Register_UnityEngine_AnimationCurve_INTERNAL_CALL_AddKey_Internal();

		//System.Int32 UnityEngine.AnimationCurve::INTERNAL_CALL_MoveKey(UnityEngine.AnimationCurve,System.Int32,UnityEngine.Keyframe&)
		void Register_UnityEngine_AnimationCurve_INTERNAL_CALL_MoveKey();
		Register_UnityEngine_AnimationCurve_INTERNAL_CALL_MoveKey();

		//System.Int32 UnityEngine.AnimationCurve::get_length()
		void Register_UnityEngine_AnimationCurve_get_length();
		Register_UnityEngine_AnimationCurve_get_length();

		//System.Single UnityEngine.AnimationCurve::Evaluate(System.Single)
		void Register_UnityEngine_AnimationCurve_Evaluate();
		Register_UnityEngine_AnimationCurve_Evaluate();

		//System.Void UnityEngine.AnimationCurve::Cleanup()
		void Register_UnityEngine_AnimationCurve_Cleanup();
		Register_UnityEngine_AnimationCurve_Cleanup();

		//System.Void UnityEngine.AnimationCurve::INTERNAL_CALL_GetKey_Internal(UnityEngine.AnimationCurve,System.Int32,UnityEngine.Keyframe&)
		void Register_UnityEngine_AnimationCurve_INTERNAL_CALL_GetKey_Internal();
		Register_UnityEngine_AnimationCurve_INTERNAL_CALL_GetKey_Internal();

		//System.Void UnityEngine.AnimationCurve::Init(UnityEngine.Keyframe[])
		void Register_UnityEngine_AnimationCurve_Init();
		Register_UnityEngine_AnimationCurve_Init();

		//System.Void UnityEngine.AnimationCurve::RemoveKey(System.Int32)
		void Register_UnityEngine_AnimationCurve_RemoveKey();
		Register_UnityEngine_AnimationCurve_RemoveKey();

		//System.Void UnityEngine.AnimationCurve::SetKeys(UnityEngine.Keyframe[])
		void Register_UnityEngine_AnimationCurve_SetKeys();
		Register_UnityEngine_AnimationCurve_SetKeys();

		//System.Void UnityEngine.AnimationCurve::SmoothTangents(System.Int32,System.Single)
		void Register_UnityEngine_AnimationCurve_SmoothTangents();
		Register_UnityEngine_AnimationCurve_SmoothTangents();

		//System.Void UnityEngine.AnimationCurve::set_postWrapMode(UnityEngine.WrapMode)
		void Register_UnityEngine_AnimationCurve_set_postWrapMode();
		Register_UnityEngine_AnimationCurve_set_postWrapMode();

		//System.Void UnityEngine.AnimationCurve::set_preWrapMode(UnityEngine.WrapMode)
		void Register_UnityEngine_AnimationCurve_set_preWrapMode();
		Register_UnityEngine_AnimationCurve_set_preWrapMode();

		//UnityEngine.Keyframe[] UnityEngine.AnimationCurve::GetKeys()
		void Register_UnityEngine_AnimationCurve_GetKeys();
		Register_UnityEngine_AnimationCurve_GetKeys();

		//UnityEngine.WrapMode UnityEngine.AnimationCurve::get_postWrapMode()
		void Register_UnityEngine_AnimationCurve_get_postWrapMode();
		Register_UnityEngine_AnimationCurve_get_postWrapMode();

		//UnityEngine.WrapMode UnityEngine.AnimationCurve::get_preWrapMode()
		void Register_UnityEngine_AnimationCurve_get_preWrapMode();
		Register_UnityEngine_AnimationCurve_get_preWrapMode();

	//End Registrations for type : UnityEngine.AnimationCurve

	//Start Registrations for type : UnityEngine.AnimationState

		//UnityEngine.AnimationClip UnityEngine.AnimationState::get_clip()
		void Register_UnityEngine_AnimationState_get_clip();
		Register_UnityEngine_AnimationState_get_clip();

	//End Registrations for type : UnityEngine.AnimationState

	//Start Registrations for type : UnityEngine.Animator

		//System.Boolean UnityEngine.Animator::GetBoolID(System.Int32)
		void Register_UnityEngine_Animator_GetBoolID();
		Register_UnityEngine_Animator_GetBoolID();

		//System.Boolean UnityEngine.Animator::IsInTransition(System.Int32)
		void Register_UnityEngine_Animator_IsInTransition();
		Register_UnityEngine_Animator_IsInTransition();

		//System.Int32 UnityEngine.Animator::GetIntegerID(System.Int32)
		void Register_UnityEngine_Animator_GetIntegerID();
		Register_UnityEngine_Animator_GetIntegerID();

		//System.Int32 UnityEngine.Animator::StringToHash(System.String)
		void Register_UnityEngine_Animator_StringToHash();
		Register_UnityEngine_Animator_StringToHash();

		//System.Single UnityEngine.Animator::GetFloatID(System.Int32)
		void Register_UnityEngine_Animator_GetFloatID();
		Register_UnityEngine_Animator_GetFloatID();

		//System.Void UnityEngine.Animator::Play(System.Int32,System.Int32,System.Single)
		void Register_UnityEngine_Animator_Play();
		Register_UnityEngine_Animator_Play();

		//System.Void UnityEngine.Animator::ResetTriggerString(System.String)
		void Register_UnityEngine_Animator_ResetTriggerString();
		Register_UnityEngine_Animator_ResetTriggerString();

		//System.Void UnityEngine.Animator::SetBoolID(System.Int32,System.Boolean)
		void Register_UnityEngine_Animator_SetBoolID();
		Register_UnityEngine_Animator_SetBoolID();

		//System.Void UnityEngine.Animator::SetFloatID(System.Int32,System.Single)
		void Register_UnityEngine_Animator_SetFloatID();
		Register_UnityEngine_Animator_SetFloatID();

		//System.Void UnityEngine.Animator::SetIntegerID(System.Int32,System.Int32)
		void Register_UnityEngine_Animator_SetIntegerID();
		Register_UnityEngine_Animator_SetIntegerID();

		//System.Void UnityEngine.Animator::SetTriggerID(System.Int32)
		void Register_UnityEngine_Animator_SetTriggerID();
		Register_UnityEngine_Animator_SetTriggerID();

		//System.Void UnityEngine.Animator::SetTriggerString(System.String)
		void Register_UnityEngine_Animator_SetTriggerString();
		Register_UnityEngine_Animator_SetTriggerString();

		//UnityEngine.AnimatorControllerParameter[] UnityEngine.Animator::get_parameters()
		void Register_UnityEngine_Animator_get_parameters();
		Register_UnityEngine_Animator_get_parameters();

		//UnityEngine.AnimatorStateInfo UnityEngine.Animator::GetCurrentAnimatorStateInfo(System.Int32)
		void Register_UnityEngine_Animator_GetCurrentAnimatorStateInfo();
		Register_UnityEngine_Animator_GetCurrentAnimatorStateInfo();

		//UnityEngine.AnimatorStateInfo UnityEngine.Animator::GetNextAnimatorStateInfo(System.Int32)
		void Register_UnityEngine_Animator_GetNextAnimatorStateInfo();
		Register_UnityEngine_Animator_GetNextAnimatorStateInfo();

		//UnityEngine.AnimatorTransitionInfo UnityEngine.Animator::GetAnimatorTransitionInfo(System.Int32)
		void Register_UnityEngine_Animator_GetAnimatorTransitionInfo();
		Register_UnityEngine_Animator_GetAnimatorTransitionInfo();

		//UnityEngine.RuntimeAnimatorController UnityEngine.Animator::get_runtimeAnimatorController()
		void Register_UnityEngine_Animator_get_runtimeAnimatorController();
		Register_UnityEngine_Animator_get_runtimeAnimatorController();

	//End Registrations for type : UnityEngine.Animator

	//Start Registrations for type : UnityEngine.AnimatorClipInfo

		//UnityEngine.AnimationClip UnityEngine.AnimatorClipInfo::ClipInstanceToScriptingObject(System.Int32)
		void Register_UnityEngine_AnimatorClipInfo_ClipInstanceToScriptingObject();
		Register_UnityEngine_AnimatorClipInfo_ClipInstanceToScriptingObject();

	//End Registrations for type : UnityEngine.AnimatorClipInfo

	//Start Registrations for type : UnityEngine.Application

		//System.Boolean UnityEngine.Application::CanStreamedLevelBeLoaded(System.Int32)
		void Register_UnityEngine_Application_CanStreamedLevelBeLoaded();
		Register_UnityEngine_Application_CanStreamedLevelBeLoaded();

		//System.Boolean UnityEngine.Application::CanStreamedLevelBeLoadedByName(System.String)
		void Register_UnityEngine_Application_CanStreamedLevelBeLoadedByName();
		Register_UnityEngine_Application_CanStreamedLevelBeLoadedByName();

		//System.Boolean UnityEngine.Application::HasARGV(System.String)
		void Register_UnityEngine_Application_HasARGV();
		Register_UnityEngine_Application_HasARGV();

		//System.Boolean UnityEngine.Application::HasAdvancedLicense()
		void Register_UnityEngine_Application_HasAdvancedLicense();
		Register_UnityEngine_Application_HasAdvancedLicense();

		//System.Boolean UnityEngine.Application::HasProLicense()
		void Register_UnityEngine_Application_HasProLicense();
		Register_UnityEngine_Application_HasProLicense();

		//System.Boolean UnityEngine.Application::HasUserAuthorization(UnityEngine.UserAuthorization)
		void Register_UnityEngine_Application_HasUserAuthorization();
		Register_UnityEngine_Application_HasUserAuthorization();

		//System.Boolean UnityEngine.Application::RequestAdvertisingIdentifierAsync(UnityEngine.Application/AdvertisingIdentifierCallback)
		void Register_UnityEngine_Application_RequestAdvertisingIdentifierAsync();
		Register_UnityEngine_Application_RequestAdvertisingIdentifierAsync();

		//System.Boolean UnityEngine.Application::get_genuine()
		void Register_UnityEngine_Application_get_genuine();
		Register_UnityEngine_Application_get_genuine();

		//System.Boolean UnityEngine.Application::get_genuineCheckAvailable()
		void Register_UnityEngine_Application_get_genuineCheckAvailable();
		Register_UnityEngine_Application_get_genuineCheckAvailable();

		//System.Boolean UnityEngine.Application::get_isBatchmode()
		void Register_UnityEngine_Application_get_isBatchmode();
		Register_UnityEngine_Application_get_isBatchmode();

		//System.Boolean UnityEngine.Application::get_isEditor()
		void Register_UnityEngine_Application_get_isEditor();
		Register_UnityEngine_Application_get_isEditor();

		//System.Boolean UnityEngine.Application::get_isHumanControllingUs()
		void Register_UnityEngine_Application_get_isHumanControllingUs();
		Register_UnityEngine_Application_get_isHumanControllingUs();

		//System.Boolean UnityEngine.Application::get_isLoadingLevel()
		void Register_UnityEngine_Application_get_isLoadingLevel();
		Register_UnityEngine_Application_get_isLoadingLevel();

		//System.Boolean UnityEngine.Application::get_isPlaying()
		void Register_UnityEngine_Application_get_isPlaying();
		Register_UnityEngine_Application_get_isPlaying();

		//System.Boolean UnityEngine.Application::get_isTestRun()
		void Register_UnityEngine_Application_get_isTestRun();
		Register_UnityEngine_Application_get_isTestRun();

		//System.Boolean UnityEngine.Application::get_isWebPlayer()
		void Register_UnityEngine_Application_get_isWebPlayer();
		Register_UnityEngine_Application_get_isWebPlayer();

		//System.Boolean UnityEngine.Application::get_runInBackground()
		void Register_UnityEngine_Application_get_runInBackground();
		Register_UnityEngine_Application_get_runInBackground();

		//System.Boolean UnityEngine.Application::get_submitAnalytics()
		void Register_UnityEngine_Application_get_submitAnalytics();
		Register_UnityEngine_Application_get_submitAnalytics();

		//System.Boolean UnityEngine.Application::get_webSecurityEnabled()
		void Register_UnityEngine_Application_get_webSecurityEnabled();
		Register_UnityEngine_Application_get_webSecurityEnabled();

		//System.Int32 UnityEngine.Application::GetUserAuthorizationRequestMode_Internal()
		void Register_UnityEngine_Application_GetUserAuthorizationRequestMode_Internal();
		Register_UnityEngine_Application_GetUserAuthorizationRequestMode_Internal();

		//System.Int32 UnityEngine.Application::get_streamedBytes()
		void Register_UnityEngine_Application_get_streamedBytes();
		Register_UnityEngine_Application_get_streamedBytes();

		//System.Int32 UnityEngine.Application::get_targetFrameRate()
		void Register_UnityEngine_Application_get_targetFrameRate();
		Register_UnityEngine_Application_get_targetFrameRate();

		//System.Single UnityEngine.Application::GetStreamProgressForLevel(System.Int32)
		void Register_UnityEngine_Application_GetStreamProgressForLevel();
		Register_UnityEngine_Application_GetStreamProgressForLevel();

		//System.Single UnityEngine.Application::GetStreamProgressForLevelByName(System.String)
		void Register_UnityEngine_Application_GetStreamProgressForLevelByName();
		Register_UnityEngine_Application_GetStreamProgressForLevelByName();

		//System.String UnityEngine.Application::GetValueForARGV(System.String)
		void Register_UnityEngine_Application_GetValueForARGV();
		Register_UnityEngine_Application_GetValueForARGV();

		//System.String UnityEngine.Application::get_absoluteURL()
		void Register_UnityEngine_Application_get_absoluteURL();
		Register_UnityEngine_Application_get_absoluteURL();

		//System.String UnityEngine.Application::get_bundleIdentifier()
		void Register_UnityEngine_Application_get_bundleIdentifier();
		Register_UnityEngine_Application_get_bundleIdentifier();

		//System.String UnityEngine.Application::get_cloudProjectId()
		void Register_UnityEngine_Application_get_cloudProjectId();
		Register_UnityEngine_Application_get_cloudProjectId();

		//System.String UnityEngine.Application::get_companyName()
		void Register_UnityEngine_Application_get_companyName();
		Register_UnityEngine_Application_get_companyName();

		//System.String UnityEngine.Application::get_dataPath()
		void Register_UnityEngine_Application_get_dataPath();
		Register_UnityEngine_Application_get_dataPath();

		//System.String UnityEngine.Application::get_installerName()
		void Register_UnityEngine_Application_get_installerName();
		Register_UnityEngine_Application_get_installerName();

		//System.String UnityEngine.Application::get_persistentDataPath()
		void Register_UnityEngine_Application_get_persistentDataPath();
		Register_UnityEngine_Application_get_persistentDataPath();

		//System.String UnityEngine.Application::get_productName()
		void Register_UnityEngine_Application_get_productName();
		Register_UnityEngine_Application_get_productName();

		//System.String UnityEngine.Application::get_srcValue()
		void Register_UnityEngine_Application_get_srcValue();
		Register_UnityEngine_Application_get_srcValue();

		//System.String UnityEngine.Application::get_streamingAssetsPath()
		void Register_UnityEngine_Application_get_streamingAssetsPath();
		Register_UnityEngine_Application_get_streamingAssetsPath();

		//System.String UnityEngine.Application::get_temporaryCachePath()
		void Register_UnityEngine_Application_get_temporaryCachePath();
		Register_UnityEngine_Application_get_temporaryCachePath();

		//System.String UnityEngine.Application::get_unityVersion()
		void Register_UnityEngine_Application_get_unityVersion();
		Register_UnityEngine_Application_get_unityVersion();

		//System.String UnityEngine.Application::get_version()
		void Register_UnityEngine_Application_get_version();
		Register_UnityEngine_Application_get_version();

		//System.String UnityEngine.Application::get_webSecurityHostUrl()
		void Register_UnityEngine_Application_get_webSecurityHostUrl();
		Register_UnityEngine_Application_get_webSecurityHostUrl();

		//System.Void UnityEngine.Application::CancelQuit()
		void Register_UnityEngine_Application_CancelQuit();
		Register_UnityEngine_Application_CancelQuit();

		//System.Void UnityEngine.Application::CaptureScreenshot(System.String,System.Int32)
		void Register_UnityEngine_Application_CaptureScreenshot();
		Register_UnityEngine_Application_CaptureScreenshot();

		//System.Void UnityEngine.Application::DontDestroyOnLoad(UnityEngine.Object)
		void Register_UnityEngine_Application_DontDestroyOnLoad();
		Register_UnityEngine_Application_DontDestroyOnLoad();

		//System.Void UnityEngine.Application::ForceCrash(System.Int32)
		void Register_UnityEngine_Application_ForceCrash();
		Register_UnityEngine_Application_ForceCrash();

		//System.Void UnityEngine.Application::Internal_ExternalCall(System.String)
		void Register_UnityEngine_Application_Internal_ExternalCall();
		Register_UnityEngine_Application_Internal_ExternalCall();

		//System.Void UnityEngine.Application::OpenURL(System.String)
		void Register_UnityEngine_Application_OpenURL();
		Register_UnityEngine_Application_OpenURL();

		//System.Void UnityEngine.Application::Quit()
		void Register_UnityEngine_Application_Quit();
		Register_UnityEngine_Application_Quit();

		//System.Void UnityEngine.Application::ReplyToUserAuthorizationRequest(System.Boolean,System.Boolean)
		void Register_UnityEngine_Application_ReplyToUserAuthorizationRequest();
		Register_UnityEngine_Application_ReplyToUserAuthorizationRequest();

		//System.Void UnityEngine.Application::SetLogCallbackDefined(System.Boolean)
		void Register_UnityEngine_Application_SetLogCallbackDefined();
		Register_UnityEngine_Application_SetLogCallbackDefined();

		//System.Void UnityEngine.Application::SetStackTraceLogType(UnityEngine.LogType,UnityEngine.StackTraceLogType)
		void Register_UnityEngine_Application_SetStackTraceLogType();
		Register_UnityEngine_Application_SetStackTraceLogType();

		//System.Void UnityEngine.Application::Unload()
		void Register_UnityEngine_Application_Unload();
		Register_UnityEngine_Application_Unload();

		//System.Void UnityEngine.Application::set_backgroundLoadingPriority(UnityEngine.ThreadPriority)
		void Register_UnityEngine_Application_set_backgroundLoadingPriority();
		Register_UnityEngine_Application_set_backgroundLoadingPriority();

		//System.Void UnityEngine.Application::set_runInBackground(System.Boolean)
		void Register_UnityEngine_Application_set_runInBackground();
		Register_UnityEngine_Application_set_runInBackground();

		//System.Void UnityEngine.Application::set_stackTraceLogType(UnityEngine.StackTraceLogType)
		void Register_UnityEngine_Application_set_stackTraceLogType();
		Register_UnityEngine_Application_set_stackTraceLogType();

		//System.Void UnityEngine.Application::set_targetFrameRate(System.Int32)
		void Register_UnityEngine_Application_set_targetFrameRate();
		Register_UnityEngine_Application_set_targetFrameRate();

		//UnityEngine.ApplicationInstallMode UnityEngine.Application::get_installMode()
		void Register_UnityEngine_Application_get_installMode();
		Register_UnityEngine_Application_get_installMode();

		//UnityEngine.ApplicationSandboxType UnityEngine.Application::get_sandboxType()
		void Register_UnityEngine_Application_get_sandboxType();
		Register_UnityEngine_Application_get_sandboxType();

		//UnityEngine.AsyncOperation UnityEngine.Application::RequestUserAuthorization(UnityEngine.UserAuthorization)
		void Register_UnityEngine_Application_RequestUserAuthorization();
		Register_UnityEngine_Application_RequestUserAuthorization();

		//UnityEngine.NetworkReachability UnityEngine.Application::get_internetReachability()
		void Register_UnityEngine_Application_get_internetReachability();
		Register_UnityEngine_Application_get_internetReachability();

		//UnityEngine.RuntimePlatform UnityEngine.Application::get_platform()
		void Register_UnityEngine_Application_get_platform();
		Register_UnityEngine_Application_get_platform();

		//UnityEngine.StackTraceLogType UnityEngine.Application::GetStackTraceLogType(UnityEngine.LogType)
		void Register_UnityEngine_Application_GetStackTraceLogType();
		Register_UnityEngine_Application_GetStackTraceLogType();

		//UnityEngine.StackTraceLogType UnityEngine.Application::get_stackTraceLogType()
		void Register_UnityEngine_Application_get_stackTraceLogType();
		Register_UnityEngine_Application_get_stackTraceLogType();

		//UnityEngine.SystemLanguage UnityEngine.Application::get_systemLanguage()
		void Register_UnityEngine_Application_get_systemLanguage();
		Register_UnityEngine_Application_get_systemLanguage();

		//UnityEngine.ThreadPriority UnityEngine.Application::get_backgroundLoadingPriority()
		void Register_UnityEngine_Application_get_backgroundLoadingPriority();
		Register_UnityEngine_Application_get_backgroundLoadingPriority();

	//End Registrations for type : UnityEngine.Application

	//Start Registrations for type : UnityEngine.AssetBundle

		//System.Boolean UnityEngine.AssetBundle::Contains(System.String)
		void Register_UnityEngine_AssetBundle_Contains();
		Register_UnityEngine_AssetBundle_Contains();

		//System.Boolean UnityEngine.AssetBundle::get_isStreamedSceneAssetBundle()
		void Register_UnityEngine_AssetBundle_get_isStreamedSceneAssetBundle();
		Register_UnityEngine_AssetBundle_get_isStreamedSceneAssetBundle();

		//System.String[] UnityEngine.AssetBundle::GetAllAssetNames()
		void Register_UnityEngine_AssetBundle_GetAllAssetNames();
		Register_UnityEngine_AssetBundle_GetAllAssetNames();

		//System.String[] UnityEngine.AssetBundle::GetAllScenePaths()
		void Register_UnityEngine_AssetBundle_GetAllScenePaths();
		Register_UnityEngine_AssetBundle_GetAllScenePaths();

		//System.Void UnityEngine.AssetBundle::Unload(System.Boolean)
		void Register_UnityEngine_AssetBundle_Unload();
		Register_UnityEngine_AssetBundle_Unload();

		//UnityEngine.AssetBundle UnityEngine.AssetBundle::LoadFromFile(System.String,System.UInt32,System.UInt64)
		void Register_UnityEngine_AssetBundle_LoadFromFile();
		Register_UnityEngine_AssetBundle_LoadFromFile();

		//UnityEngine.AssetBundle UnityEngine.AssetBundle::LoadFromMemory(System.Byte[],System.UInt32)
		void Register_UnityEngine_AssetBundle_LoadFromMemory();
		Register_UnityEngine_AssetBundle_LoadFromMemory();

		//UnityEngine.AssetBundleCreateRequest UnityEngine.AssetBundle::LoadFromFileAsync(System.String,System.UInt32,System.UInt64)
		void Register_UnityEngine_AssetBundle_LoadFromFileAsync();
		Register_UnityEngine_AssetBundle_LoadFromFileAsync();

		//UnityEngine.AssetBundleCreateRequest UnityEngine.AssetBundle::LoadFromMemoryAsync(System.Byte[],System.UInt32)
		void Register_UnityEngine_AssetBundle_LoadFromMemoryAsync();
		Register_UnityEngine_AssetBundle_LoadFromMemoryAsync();

		//UnityEngine.AssetBundleRequest UnityEngine.AssetBundle::LoadAssetAsync_Internal(System.String,System.Type)
		void Register_UnityEngine_AssetBundle_LoadAssetAsync_Internal();
		Register_UnityEngine_AssetBundle_LoadAssetAsync_Internal();

		//UnityEngine.AssetBundleRequest UnityEngine.AssetBundle::LoadAssetWithSubAssetsAsync_Internal(System.String,System.Type)
		void Register_UnityEngine_AssetBundle_LoadAssetWithSubAssetsAsync_Internal();
		Register_UnityEngine_AssetBundle_LoadAssetWithSubAssetsAsync_Internal();

		//UnityEngine.AssetBundleRequest UnityEngine.AssetBundle::LoadAsync(System.String,System.Type)
		void Register_UnityEngine_AssetBundle_LoadAsync();
		Register_UnityEngine_AssetBundle_LoadAsync();

		//UnityEngine.Object UnityEngine.AssetBundle::Load(System.String,System.Type)
		void Register_UnityEngine_AssetBundle_Load();
		Register_UnityEngine_AssetBundle_Load();

		//UnityEngine.Object UnityEngine.AssetBundle::LoadAsset_Internal(System.String,System.Type)
		void Register_UnityEngine_AssetBundle_LoadAsset_Internal();
		Register_UnityEngine_AssetBundle_LoadAsset_Internal();

		//UnityEngine.Object UnityEngine.AssetBundle::get_mainAsset()
		void Register_UnityEngine_AssetBundle_get_mainAsset();
		Register_UnityEngine_AssetBundle_get_mainAsset();

		//UnityEngine.Object[] UnityEngine.AssetBundle::LoadAll(System.Type)
		void Register_UnityEngine_AssetBundle_LoadAll();
		Register_UnityEngine_AssetBundle_LoadAll();

		//UnityEngine.Object[] UnityEngine.AssetBundle::LoadAssetWithSubAssets_Internal(System.String,System.Type)
		void Register_UnityEngine_AssetBundle_LoadAssetWithSubAssets_Internal();
		Register_UnityEngine_AssetBundle_LoadAssetWithSubAssets_Internal();

	//End Registrations for type : UnityEngine.AssetBundle

	//Start Registrations for type : UnityEngine.AssetBundleCreateRequest

		//System.Void UnityEngine.AssetBundleCreateRequest::DisableCompatibilityChecks()
		void Register_UnityEngine_AssetBundleCreateRequest_DisableCompatibilityChecks();
		Register_UnityEngine_AssetBundleCreateRequest_DisableCompatibilityChecks();

		//UnityEngine.AssetBundle UnityEngine.AssetBundleCreateRequest::get_assetBundle()
		void Register_UnityEngine_AssetBundleCreateRequest_get_assetBundle();
		Register_UnityEngine_AssetBundleCreateRequest_get_assetBundle();

	//End Registrations for type : UnityEngine.AssetBundleCreateRequest

	//Start Registrations for type : UnityEngine.AssetBundleRequest

		//UnityEngine.Object UnityEngine.AssetBundleRequest::get_asset()
		void Register_UnityEngine_AssetBundleRequest_get_asset();
		Register_UnityEngine_AssetBundleRequest_get_asset();

		//UnityEngine.Object[] UnityEngine.AssetBundleRequest::get_allAssets()
		void Register_UnityEngine_AssetBundleRequest_get_allAssets();
		Register_UnityEngine_AssetBundleRequest_get_allAssets();

	//End Registrations for type : UnityEngine.AssetBundleRequest

	//Start Registrations for type : UnityEngine.AsyncOperation

		//System.Boolean UnityEngine.AsyncOperation::get_allowSceneActivation()
		void Register_UnityEngine_AsyncOperation_get_allowSceneActivation();
		Register_UnityEngine_AsyncOperation_get_allowSceneActivation();

		//System.Boolean UnityEngine.AsyncOperation::get_isDone()
		void Register_UnityEngine_AsyncOperation_get_isDone();
		Register_UnityEngine_AsyncOperation_get_isDone();

		//System.Int32 UnityEngine.AsyncOperation::get_priority()
		void Register_UnityEngine_AsyncOperation_get_priority();
		Register_UnityEngine_AsyncOperation_get_priority();

		//System.Single UnityEngine.AsyncOperation::get_progress()
		void Register_UnityEngine_AsyncOperation_get_progress();
		Register_UnityEngine_AsyncOperation_get_progress();

		//System.Void UnityEngine.AsyncOperation::InternalDestroy()
		void Register_UnityEngine_AsyncOperation_InternalDestroy();
		Register_UnityEngine_AsyncOperation_InternalDestroy();

		//System.Void UnityEngine.AsyncOperation::set_allowSceneActivation(System.Boolean)
		void Register_UnityEngine_AsyncOperation_set_allowSceneActivation();
		Register_UnityEngine_AsyncOperation_set_allowSceneActivation();

		//System.Void UnityEngine.AsyncOperation::set_priority(System.Int32)
		void Register_UnityEngine_AsyncOperation_set_priority();
		Register_UnityEngine_AsyncOperation_set_priority();

	//End Registrations for type : UnityEngine.AsyncOperation

	//Start Registrations for type : UnityEngine.AudioClip

		//System.Boolean UnityEngine.AudioClip::GetData(System.Single[],System.Int32)
		void Register_UnityEngine_AudioClip_GetData();
		Register_UnityEngine_AudioClip_GetData();

		//System.Boolean UnityEngine.AudioClip::LoadAudioData()
		void Register_UnityEngine_AudioClip_LoadAudioData();
		Register_UnityEngine_AudioClip_LoadAudioData();

		//System.Boolean UnityEngine.AudioClip::SetData(System.Single[],System.Int32)
		void Register_UnityEngine_AudioClip_SetData();
		Register_UnityEngine_AudioClip_SetData();

		//System.Boolean UnityEngine.AudioClip::UnloadAudioData()
		void Register_UnityEngine_AudioClip_UnloadAudioData();
		Register_UnityEngine_AudioClip_UnloadAudioData();

		//System.Boolean UnityEngine.AudioClip::get_isReadyToPlay()
		void Register_UnityEngine_AudioClip_get_isReadyToPlay();
		Register_UnityEngine_AudioClip_get_isReadyToPlay();

		//System.Boolean UnityEngine.AudioClip::get_loadInBackground()
		void Register_UnityEngine_AudioClip_get_loadInBackground();
		Register_UnityEngine_AudioClip_get_loadInBackground();

		//System.Boolean UnityEngine.AudioClip::get_preloadAudioData()
		void Register_UnityEngine_AudioClip_get_preloadAudioData();
		Register_UnityEngine_AudioClip_get_preloadAudioData();

		//System.Int32 UnityEngine.AudioClip::get_channels()
		void Register_UnityEngine_AudioClip_get_channels();
		Register_UnityEngine_AudioClip_get_channels();

		//System.Int32 UnityEngine.AudioClip::get_frequency()
		void Register_UnityEngine_AudioClip_get_frequency();
		Register_UnityEngine_AudioClip_get_frequency();

		//System.Int32 UnityEngine.AudioClip::get_samples()
		void Register_UnityEngine_AudioClip_get_samples();
		Register_UnityEngine_AudioClip_get_samples();

		//System.Single UnityEngine.AudioClip::get_length()
		void Register_UnityEngine_AudioClip_get_length();
		Register_UnityEngine_AudioClip_get_length();

		//System.Void UnityEngine.AudioClip::Init_Internal(System.String,System.Int32,System.Int32,System.Int32,System.Boolean)
		void Register_UnityEngine_AudioClip_Init_Internal();
		Register_UnityEngine_AudioClip_Init_Internal();

		//UnityEngine.AudioClip UnityEngine.AudioClip::Construct_Internal()
		void Register_UnityEngine_AudioClip_Construct_Internal();
		Register_UnityEngine_AudioClip_Construct_Internal();

		//UnityEngine.AudioClipLoadType UnityEngine.AudioClip::get_loadType()
		void Register_UnityEngine_AudioClip_get_loadType();
		Register_UnityEngine_AudioClip_get_loadType();

		//UnityEngine.AudioDataLoadState UnityEngine.AudioClip::get_loadState()
		void Register_UnityEngine_AudioClip_get_loadState();
		Register_UnityEngine_AudioClip_get_loadState();

	//End Registrations for type : UnityEngine.AudioClip

	//Start Registrations for type : UnityEngine.AudioSettings

		//System.Boolean UnityEngine.AudioSettings::INTERNAL_CALL_Reset(UnityEngine.AudioConfiguration&)
		void Register_UnityEngine_AudioSettings_INTERNAL_CALL_Reset();
		Register_UnityEngine_AudioSettings_INTERNAL_CALL_Reset();

		//System.Boolean UnityEngine.AudioSettings::get_unityAudioDisabled()
		void Register_UnityEngine_AudioSettings_get_unityAudioDisabled();
		Register_UnityEngine_AudioSettings_get_unityAudioDisabled();

		//System.Double UnityEngine.AudioSettings::get_dspTime()
		void Register_UnityEngine_AudioSettings_get_dspTime();
		Register_UnityEngine_AudioSettings_get_dspTime();

		//System.Int32 UnityEngine.AudioSettings::get_outputSampleRate()
		void Register_UnityEngine_AudioSettings_get_outputSampleRate();
		Register_UnityEngine_AudioSettings_get_outputSampleRate();

		//System.Int32 UnityEngine.AudioSettings::get_profilerCaptureFlags()
		void Register_UnityEngine_AudioSettings_get_profilerCaptureFlags();
		Register_UnityEngine_AudioSettings_get_profilerCaptureFlags();

		//System.Void UnityEngine.AudioSettings::GetDSPBufferSize(System.Int32&,System.Int32&)
		void Register_UnityEngine_AudioSettings_GetDSPBufferSize();
		Register_UnityEngine_AudioSettings_GetDSPBufferSize();

		//System.Void UnityEngine.AudioSettings::INTERNAL_CALL_GetConfiguration(UnityEngine.AudioConfiguration&)
		void Register_UnityEngine_AudioSettings_INTERNAL_CALL_GetConfiguration();
		Register_UnityEngine_AudioSettings_INTERNAL_CALL_GetConfiguration();

		//System.Void UnityEngine.AudioSettings::SetDSPBufferSize(System.Int32,System.Int32)
		void Register_UnityEngine_AudioSettings_SetDSPBufferSize();
		Register_UnityEngine_AudioSettings_SetDSPBufferSize();

		//System.Void UnityEngine.AudioSettings::set_outputSampleRate(System.Int32)
		void Register_UnityEngine_AudioSettings_set_outputSampleRate();
		Register_UnityEngine_AudioSettings_set_outputSampleRate();

		//System.Void UnityEngine.AudioSettings::set_speakerMode(UnityEngine.AudioSpeakerMode)
		void Register_UnityEngine_AudioSettings_set_speakerMode();
		Register_UnityEngine_AudioSettings_set_speakerMode();

		//UnityEngine.AudioSpeakerMode UnityEngine.AudioSettings::get_driverCapabilities()
		void Register_UnityEngine_AudioSettings_get_driverCapabilities();
		Register_UnityEngine_AudioSettings_get_driverCapabilities();

		//UnityEngine.AudioSpeakerMode UnityEngine.AudioSettings::get_speakerMode()
		void Register_UnityEngine_AudioSettings_get_speakerMode();
		Register_UnityEngine_AudioSettings_get_speakerMode();

	//End Registrations for type : UnityEngine.AudioSettings

	//Start Registrations for type : UnityEngine.AudioSource

		//System.Boolean UnityEngine.AudioSource::get_isPlaying()
		void Register_UnityEngine_AudioSource_get_isPlaying();
		Register_UnityEngine_AudioSource_get_isPlaying();

		//System.Void UnityEngine.AudioSource::Play(System.UInt64)
		void Register_UnityEngine_AudioSource_Play();
		Register_UnityEngine_AudioSource_Play();

		//System.Void UnityEngine.AudioSource::Stop()
		void Register_UnityEngine_AudioSource_Stop();
		Register_UnityEngine_AudioSource_Stop();

		//System.Void UnityEngine.AudioSource::set_clip(UnityEngine.AudioClip)
		void Register_UnityEngine_AudioSource_set_clip();
		Register_UnityEngine_AudioSource_set_clip();

		//System.Void UnityEngine.AudioSource::set_loop(System.Boolean)
		void Register_UnityEngine_AudioSource_set_loop();
		Register_UnityEngine_AudioSource_set_loop();

		//System.Void UnityEngine.AudioSource::set_minDistance(System.Single)
		void Register_UnityEngine_AudioSource_set_minDistance();
		Register_UnityEngine_AudioSource_set_minDistance();

		//System.Void UnityEngine.AudioSource::set_pitch(System.Single)
		void Register_UnityEngine_AudioSource_set_pitch();
		Register_UnityEngine_AudioSource_set_pitch();

		//System.Void UnityEngine.AudioSource::set_spatialBlend(System.Single)
		void Register_UnityEngine_AudioSource_set_spatialBlend();
		Register_UnityEngine_AudioSource_set_spatialBlend();

		//System.Void UnityEngine.AudioSource::set_volume(System.Single)
		void Register_UnityEngine_AudioSource_set_volume();
		Register_UnityEngine_AudioSource_set_volume();

	//End Registrations for type : UnityEngine.AudioSource

	//Start Registrations for type : UnityEngine.Behaviour

		//System.Boolean UnityEngine.Behaviour::get_enabled()
		void Register_UnityEngine_Behaviour_get_enabled();
		Register_UnityEngine_Behaviour_get_enabled();

		//System.Boolean UnityEngine.Behaviour::get_isActiveAndEnabled()
		void Register_UnityEngine_Behaviour_get_isActiveAndEnabled();
		Register_UnityEngine_Behaviour_get_isActiveAndEnabled();

		//System.Void UnityEngine.Behaviour::set_enabled(System.Boolean)
		void Register_UnityEngine_Behaviour_set_enabled();
		Register_UnityEngine_Behaviour_set_enabled();

	//End Registrations for type : UnityEngine.Behaviour

	//Start Registrations for type : UnityEngine.BitStream

		//System.Boolean UnityEngine.BitStream::get_isReading()
		void Register_UnityEngine_BitStream_get_isReading();
		Register_UnityEngine_BitStream_get_isReading();

		//System.Boolean UnityEngine.BitStream::get_isWriting()
		void Register_UnityEngine_BitStream_get_isWriting();
		Register_UnityEngine_BitStream_get_isWriting();

		//System.Void UnityEngine.BitStream::INTERNAL_CALL_Serializen(UnityEngine.BitStream,UnityEngine.NetworkViewID&)
		void Register_UnityEngine_BitStream_INTERNAL_CALL_Serializen();
		Register_UnityEngine_BitStream_INTERNAL_CALL_Serializen();

		//System.Void UnityEngine.BitStream::INTERNAL_CALL_Serializeq(UnityEngine.BitStream,UnityEngine.Quaternion&,System.Single)
		void Register_UnityEngine_BitStream_INTERNAL_CALL_Serializeq();
		Register_UnityEngine_BitStream_INTERNAL_CALL_Serializeq();

		//System.Void UnityEngine.BitStream::INTERNAL_CALL_Serializev(UnityEngine.BitStream,UnityEngine.Vector3&,System.Single)
		void Register_UnityEngine_BitStream_INTERNAL_CALL_Serializev();
		Register_UnityEngine_BitStream_INTERNAL_CALL_Serializev();

		//System.Void UnityEngine.BitStream::Serialize(System.String&)
		void Register_UnityEngine_BitStream_Serialize();
		Register_UnityEngine_BitStream_Serialize();

		//System.Void UnityEngine.BitStream::Serializeb(System.Int32&)
		void Register_UnityEngine_BitStream_Serializeb();
		Register_UnityEngine_BitStream_Serializeb();

		//System.Void UnityEngine.BitStream::Serializec(System.Char&)
		void Register_UnityEngine_BitStream_Serializec();
		Register_UnityEngine_BitStream_Serializec();

		//System.Void UnityEngine.BitStream::Serializef(System.Single&,System.Single)
		void Register_UnityEngine_BitStream_Serializef();
		Register_UnityEngine_BitStream_Serializef();

		//System.Void UnityEngine.BitStream::Serializei(System.Int32&)
		void Register_UnityEngine_BitStream_Serializei();
		Register_UnityEngine_BitStream_Serializei();

		//System.Void UnityEngine.BitStream::Serializes(System.Int16&)
		void Register_UnityEngine_BitStream_Serializes();
		Register_UnityEngine_BitStream_Serializes();

	//End Registrations for type : UnityEngine.BitStream

	//Start Registrations for type : UnityEngine.Camera

		//System.Boolean UnityEngine.Camera::Internal_RenderToCubemapRT(UnityEngine.RenderTexture,System.Int32)
		void Register_UnityEngine_Camera_Internal_RenderToCubemapRT();
		Register_UnityEngine_Camera_Internal_RenderToCubemapRT();

		//System.Boolean UnityEngine.Camera::Internal_RenderToCubemapTexture(UnityEngine.Cubemap,System.Int32)
		void Register_UnityEngine_Camera_Internal_RenderToCubemapTexture();
		Register_UnityEngine_Camera_Internal_RenderToCubemapTexture();

		//System.Boolean UnityEngine.Camera::IsFiltered(UnityEngine.GameObject)
		void Register_UnityEngine_Camera_IsFiltered();
		Register_UnityEngine_Camera_IsFiltered();

		//System.Boolean UnityEngine.Camera::get_clearStencilAfterLightingPass()
		void Register_UnityEngine_Camera_get_clearStencilAfterLightingPass();
		Register_UnityEngine_Camera_get_clearStencilAfterLightingPass();

		//System.Boolean UnityEngine.Camera::get_hdr()
		void Register_UnityEngine_Camera_get_hdr();
		Register_UnityEngine_Camera_get_hdr();

		//System.Boolean UnityEngine.Camera::get_layerCullSpherical()
		void Register_UnityEngine_Camera_get_layerCullSpherical();
		Register_UnityEngine_Camera_get_layerCullSpherical();

		//System.Boolean UnityEngine.Camera::get_orthographic()
		void Register_UnityEngine_Camera_get_orthographic();
		Register_UnityEngine_Camera_get_orthographic();

		//System.Boolean UnityEngine.Camera::get_stereoEnabled()
		void Register_UnityEngine_Camera_get_stereoEnabled();
		Register_UnityEngine_Camera_get_stereoEnabled();

		//System.Boolean UnityEngine.Camera::get_stereoMirrorMode()
		void Register_UnityEngine_Camera_get_stereoMirrorMode();
		Register_UnityEngine_Camera_get_stereoMirrorMode();

		//System.Boolean UnityEngine.Camera::get_useJitteredProjectionMatrixForTransparentRendering()
		void Register_UnityEngine_Camera_get_useJitteredProjectionMatrixForTransparentRendering();
		Register_UnityEngine_Camera_get_useJitteredProjectionMatrixForTransparentRendering();

		//System.Boolean UnityEngine.Camera::get_useOcclusionCulling()
		void Register_UnityEngine_Camera_get_useOcclusionCulling();
		Register_UnityEngine_Camera_get_useOcclusionCulling();

		//System.Int32 UnityEngine.Camera::GetAllCameras(UnityEngine.Camera[])
		void Register_UnityEngine_Camera_GetAllCameras();
		Register_UnityEngine_Camera_GetAllCameras();

		//System.Int32 UnityEngine.Camera::get_PreviewCullingLayer()
		void Register_UnityEngine_Camera_get_PreviewCullingLayer();
		Register_UnityEngine_Camera_get_PreviewCullingLayer();

		//System.Int32 UnityEngine.Camera::get_allCamerasCount()
		void Register_UnityEngine_Camera_get_allCamerasCount();
		Register_UnityEngine_Camera_get_allCamerasCount();

		//System.Int32 UnityEngine.Camera::get_commandBufferCount()
		void Register_UnityEngine_Camera_get_commandBufferCount();
		Register_UnityEngine_Camera_get_commandBufferCount();

		//System.Int32 UnityEngine.Camera::get_cullingMask()
		void Register_UnityEngine_Camera_get_cullingMask();
		Register_UnityEngine_Camera_get_cullingMask();

		//System.Int32 UnityEngine.Camera::get_eventMask()
		void Register_UnityEngine_Camera_get_eventMask();
		Register_UnityEngine_Camera_get_eventMask();

		//System.Int32 UnityEngine.Camera::get_pixelHeight()
		void Register_UnityEngine_Camera_get_pixelHeight();
		Register_UnityEngine_Camera_get_pixelHeight();

		//System.Int32 UnityEngine.Camera::get_pixelWidth()
		void Register_UnityEngine_Camera_get_pixelWidth();
		Register_UnityEngine_Camera_get_pixelWidth();

		//System.Int32 UnityEngine.Camera::get_targetDisplay()
		void Register_UnityEngine_Camera_get_targetDisplay();
		Register_UnityEngine_Camera_get_targetDisplay();

		//System.Single UnityEngine.Camera::get_aspect()
		void Register_UnityEngine_Camera_get_aspect();
		Register_UnityEngine_Camera_get_aspect();

		//System.Single UnityEngine.Camera::get_depth()
		void Register_UnityEngine_Camera_get_depth();
		Register_UnityEngine_Camera_get_depth();

		//System.Single UnityEngine.Camera::get_farClipPlane()
		void Register_UnityEngine_Camera_get_farClipPlane();
		Register_UnityEngine_Camera_get_farClipPlane();

		//System.Single UnityEngine.Camera::get_fieldOfView()
		void Register_UnityEngine_Camera_get_fieldOfView();
		Register_UnityEngine_Camera_get_fieldOfView();

		//System.Single UnityEngine.Camera::get_nearClipPlane()
		void Register_UnityEngine_Camera_get_nearClipPlane();
		Register_UnityEngine_Camera_get_nearClipPlane();

		//System.Single UnityEngine.Camera::get_orthographicSize()
		void Register_UnityEngine_Camera_get_orthographicSize();
		Register_UnityEngine_Camera_get_orthographicSize();

		//System.Single UnityEngine.Camera::get_stereoConvergence()
		void Register_UnityEngine_Camera_get_stereoConvergence();
		Register_UnityEngine_Camera_get_stereoConvergence();

		//System.Single UnityEngine.Camera::get_stereoSeparation()
		void Register_UnityEngine_Camera_get_stereoSeparation();
		Register_UnityEngine_Camera_get_stereoSeparation();

		//System.Single[] UnityEngine.Camera::get_layerCullDistances()
		void Register_UnityEngine_Camera_get_layerCullDistances();
		Register_UnityEngine_Camera_get_layerCullDistances();

		//System.String[] UnityEngine.Camera::GetHDRWarnings()
		void Register_UnityEngine_Camera_GetHDRWarnings();
		Register_UnityEngine_Camera_GetHDRWarnings();

		//System.Void UnityEngine.Camera::AddCommandBuffer(UnityEngine.Rendering.CameraEvent,UnityEngine.Rendering.CommandBuffer)
		void Register_UnityEngine_Camera_AddCommandBuffer();
		Register_UnityEngine_Camera_AddCommandBuffer();

		//System.Void UnityEngine.Camera::CopyFrom(UnityEngine.Camera)
		void Register_UnityEngine_Camera_CopyFrom();
		Register_UnityEngine_Camera_CopyFrom();

		//System.Void UnityEngine.Camera::INTERNAL_CALL_CalculateFrustumCornersInternal(UnityEngine.Camera,UnityEngine.Rect&,System.Single,UnityEngine.Camera/MonoOrStereoscopicEye,UnityEngine.Vector3[])
		void Register_UnityEngine_Camera_INTERNAL_CALL_CalculateFrustumCornersInternal();
		Register_UnityEngine_Camera_INTERNAL_CALL_CalculateFrustumCornersInternal();

		//System.Void UnityEngine.Camera::INTERNAL_CALL_CalculateObliqueMatrix(UnityEngine.Camera,UnityEngine.Vector4&,UnityEngine.Matrix4x4&)
		void Register_UnityEngine_Camera_INTERNAL_CALL_CalculateObliqueMatrix();
		Register_UnityEngine_Camera_INTERNAL_CALL_CalculateObliqueMatrix();

		//System.Void UnityEngine.Camera::INTERNAL_CALL_GetStereoProjectionMatrix(UnityEngine.Camera,UnityEngine.Camera/StereoscopicEye,UnityEngine.Matrix4x4&)
		void Register_UnityEngine_Camera_INTERNAL_CALL_GetStereoProjectionMatrix();
		Register_UnityEngine_Camera_INTERNAL_CALL_GetStereoProjectionMatrix();

		//System.Void UnityEngine.Camera::INTERNAL_CALL_GetStereoViewMatrix(UnityEngine.Camera,UnityEngine.Camera/StereoscopicEye,UnityEngine.Matrix4x4&)
		void Register_UnityEngine_Camera_INTERNAL_CALL_GetStereoViewMatrix();
		Register_UnityEngine_Camera_INTERNAL_CALL_GetStereoViewMatrix();

		//System.Void UnityEngine.Camera::INTERNAL_CALL_ResetAspect(UnityEngine.Camera)
		void Register_UnityEngine_Camera_INTERNAL_CALL_ResetAspect();
		Register_UnityEngine_Camera_INTERNAL_CALL_ResetAspect();

		//System.Void UnityEngine.Camera::INTERNAL_CALL_ResetCullingMatrix(UnityEngine.Camera)
		void Register_UnityEngine_Camera_INTERNAL_CALL_ResetCullingMatrix();
		Register_UnityEngine_Camera_INTERNAL_CALL_ResetCullingMatrix();

		//System.Void UnityEngine.Camera::INTERNAL_CALL_ResetFieldOfView(UnityEngine.Camera)
		void Register_UnityEngine_Camera_INTERNAL_CALL_ResetFieldOfView();
		Register_UnityEngine_Camera_INTERNAL_CALL_ResetFieldOfView();

		//System.Void UnityEngine.Camera::INTERNAL_CALL_ResetProjectionMatrix(UnityEngine.Camera)
		void Register_UnityEngine_Camera_INTERNAL_CALL_ResetProjectionMatrix();
		Register_UnityEngine_Camera_INTERNAL_CALL_ResetProjectionMatrix();

		//System.Void UnityEngine.Camera::INTERNAL_CALL_ResetReplacementShader(UnityEngine.Camera)
		void Register_UnityEngine_Camera_INTERNAL_CALL_ResetReplacementShader();
		Register_UnityEngine_Camera_INTERNAL_CALL_ResetReplacementShader();

		//System.Void UnityEngine.Camera::INTERNAL_CALL_ResetWorldToCameraMatrix(UnityEngine.Camera)
		void Register_UnityEngine_Camera_INTERNAL_CALL_ResetWorldToCameraMatrix();
		Register_UnityEngine_Camera_INTERNAL_CALL_ResetWorldToCameraMatrix();

		//System.Void UnityEngine.Camera::INTERNAL_CALL_ScreenPointToRay(UnityEngine.Camera,UnityEngine.Vector3&,UnityEngine.Ray&)
		void Register_UnityEngine_Camera_INTERNAL_CALL_ScreenPointToRay();
		Register_UnityEngine_Camera_INTERNAL_CALL_ScreenPointToRay();

		//System.Void UnityEngine.Camera::INTERNAL_CALL_ScreenToViewportPoint(UnityEngine.Camera,UnityEngine.Vector3&,UnityEngine.Vector3&)
		void Register_UnityEngine_Camera_INTERNAL_CALL_ScreenToViewportPoint();
		Register_UnityEngine_Camera_INTERNAL_CALL_ScreenToViewportPoint();

		//System.Void UnityEngine.Camera::INTERNAL_CALL_ScreenToWorldPoint(UnityEngine.Camera,UnityEngine.Vector3&,UnityEngine.Vector3&)
		void Register_UnityEngine_Camera_INTERNAL_CALL_ScreenToWorldPoint();
		Register_UnityEngine_Camera_INTERNAL_CALL_ScreenToWorldPoint();

		//System.Void UnityEngine.Camera::INTERNAL_CALL_SetStereoProjectionMatrices(UnityEngine.Camera,UnityEngine.Matrix4x4&,UnityEngine.Matrix4x4&)
		void Register_UnityEngine_Camera_INTERNAL_CALL_SetStereoProjectionMatrices();
		Register_UnityEngine_Camera_INTERNAL_CALL_SetStereoProjectionMatrices();

		//System.Void UnityEngine.Camera::INTERNAL_CALL_SetStereoProjectionMatrix(UnityEngine.Camera,UnityEngine.Camera/StereoscopicEye,UnityEngine.Matrix4x4&)
		void Register_UnityEngine_Camera_INTERNAL_CALL_SetStereoProjectionMatrix();
		Register_UnityEngine_Camera_INTERNAL_CALL_SetStereoProjectionMatrix();

		//System.Void UnityEngine.Camera::INTERNAL_CALL_SetStereoViewMatrices(UnityEngine.Camera,UnityEngine.Matrix4x4&,UnityEngine.Matrix4x4&)
		void Register_UnityEngine_Camera_INTERNAL_CALL_SetStereoViewMatrices();
		Register_UnityEngine_Camera_INTERNAL_CALL_SetStereoViewMatrices();

		//System.Void UnityEngine.Camera::INTERNAL_CALL_SetStereoViewMatrix(UnityEngine.Camera,UnityEngine.Camera/StereoscopicEye,UnityEngine.Matrix4x4&)
		void Register_UnityEngine_Camera_INTERNAL_CALL_SetStereoViewMatrix();
		Register_UnityEngine_Camera_INTERNAL_CALL_SetStereoViewMatrix();

		//System.Void UnityEngine.Camera::INTERNAL_CALL_ViewportPointToRay(UnityEngine.Camera,UnityEngine.Vector3&,UnityEngine.Ray&)
		void Register_UnityEngine_Camera_INTERNAL_CALL_ViewportPointToRay();
		Register_UnityEngine_Camera_INTERNAL_CALL_ViewportPointToRay();

		//System.Void UnityEngine.Camera::INTERNAL_CALL_ViewportToScreenPoint(UnityEngine.Camera,UnityEngine.Vector3&,UnityEngine.Vector3&)
		void Register_UnityEngine_Camera_INTERNAL_CALL_ViewportToScreenPoint();
		Register_UnityEngine_Camera_INTERNAL_CALL_ViewportToScreenPoint();

		//System.Void UnityEngine.Camera::INTERNAL_CALL_ViewportToWorldPoint(UnityEngine.Camera,UnityEngine.Vector3&,UnityEngine.Vector3&)
		void Register_UnityEngine_Camera_INTERNAL_CALL_ViewportToWorldPoint();
		Register_UnityEngine_Camera_INTERNAL_CALL_ViewportToWorldPoint();

		//System.Void UnityEngine.Camera::INTERNAL_CALL_WorldToScreenPoint(UnityEngine.Camera,UnityEngine.Vector3&,UnityEngine.Vector3&)
		void Register_UnityEngine_Camera_INTERNAL_CALL_WorldToScreenPoint();
		Register_UnityEngine_Camera_INTERNAL_CALL_WorldToScreenPoint();

		//System.Void UnityEngine.Camera::INTERNAL_CALL_WorldToViewportPoint(UnityEngine.Camera,UnityEngine.Vector3&,UnityEngine.Vector3&)
		void Register_UnityEngine_Camera_INTERNAL_CALL_WorldToViewportPoint();
		Register_UnityEngine_Camera_INTERNAL_CALL_WorldToViewportPoint();

		//System.Void UnityEngine.Camera::INTERNAL_get_backgroundColor(UnityEngine.Color&)
		void Register_UnityEngine_Camera_INTERNAL_get_backgroundColor();
		Register_UnityEngine_Camera_INTERNAL_get_backgroundColor();

		//System.Void UnityEngine.Camera::INTERNAL_get_cameraToWorldMatrix(UnityEngine.Matrix4x4&)
		void Register_UnityEngine_Camera_INTERNAL_get_cameraToWorldMatrix();
		Register_UnityEngine_Camera_INTERNAL_get_cameraToWorldMatrix();

		//System.Void UnityEngine.Camera::INTERNAL_get_cullingMatrix(UnityEngine.Matrix4x4&)
		void Register_UnityEngine_Camera_INTERNAL_get_cullingMatrix();
		Register_UnityEngine_Camera_INTERNAL_get_cullingMatrix();

		//System.Void UnityEngine.Camera::INTERNAL_get_nonJitteredProjectionMatrix(UnityEngine.Matrix4x4&)
		void Register_UnityEngine_Camera_INTERNAL_get_nonJitteredProjectionMatrix();
		Register_UnityEngine_Camera_INTERNAL_get_nonJitteredProjectionMatrix();

		//System.Void UnityEngine.Camera::INTERNAL_get_pixelRect(UnityEngine.Rect&)
		void Register_UnityEngine_Camera_INTERNAL_get_pixelRect();
		Register_UnityEngine_Camera_INTERNAL_get_pixelRect();

		//System.Void UnityEngine.Camera::INTERNAL_get_projectionMatrix(UnityEngine.Matrix4x4&)
		void Register_UnityEngine_Camera_INTERNAL_get_projectionMatrix();
		Register_UnityEngine_Camera_INTERNAL_get_projectionMatrix();

		//System.Void UnityEngine.Camera::INTERNAL_get_rect(UnityEngine.Rect&)
		void Register_UnityEngine_Camera_INTERNAL_get_rect();
		Register_UnityEngine_Camera_INTERNAL_get_rect();

		//System.Void UnityEngine.Camera::INTERNAL_get_velocity(UnityEngine.Vector3&)
		void Register_UnityEngine_Camera_INTERNAL_get_velocity();
		Register_UnityEngine_Camera_INTERNAL_get_velocity();

		//System.Void UnityEngine.Camera::INTERNAL_get_worldToCameraMatrix(UnityEngine.Matrix4x4&)
		void Register_UnityEngine_Camera_INTERNAL_get_worldToCameraMatrix();
		Register_UnityEngine_Camera_INTERNAL_get_worldToCameraMatrix();

		//System.Void UnityEngine.Camera::INTERNAL_set_backgroundColor(UnityEngine.Color&)
		void Register_UnityEngine_Camera_INTERNAL_set_backgroundColor();
		Register_UnityEngine_Camera_INTERNAL_set_backgroundColor();

		//System.Void UnityEngine.Camera::INTERNAL_set_cullingMatrix(UnityEngine.Matrix4x4&)
		void Register_UnityEngine_Camera_INTERNAL_set_cullingMatrix();
		Register_UnityEngine_Camera_INTERNAL_set_cullingMatrix();

		//System.Void UnityEngine.Camera::INTERNAL_set_nonJitteredProjectionMatrix(UnityEngine.Matrix4x4&)
		void Register_UnityEngine_Camera_INTERNAL_set_nonJitteredProjectionMatrix();
		Register_UnityEngine_Camera_INTERNAL_set_nonJitteredProjectionMatrix();

		//System.Void UnityEngine.Camera::INTERNAL_set_pixelRect(UnityEngine.Rect&)
		void Register_UnityEngine_Camera_INTERNAL_set_pixelRect();
		Register_UnityEngine_Camera_INTERNAL_set_pixelRect();

		//System.Void UnityEngine.Camera::INTERNAL_set_projectionMatrix(UnityEngine.Matrix4x4&)
		void Register_UnityEngine_Camera_INTERNAL_set_projectionMatrix();
		Register_UnityEngine_Camera_INTERNAL_set_projectionMatrix();

		//System.Void UnityEngine.Camera::INTERNAL_set_rect(UnityEngine.Rect&)
		void Register_UnityEngine_Camera_INTERNAL_set_rect();
		Register_UnityEngine_Camera_INTERNAL_set_rect();

		//System.Void UnityEngine.Camera::INTERNAL_set_worldToCameraMatrix(UnityEngine.Matrix4x4&)
		void Register_UnityEngine_Camera_INTERNAL_set_worldToCameraMatrix();
		Register_UnityEngine_Camera_INTERNAL_set_worldToCameraMatrix();

		//System.Void UnityEngine.Camera::RemoveAllCommandBuffers()
		void Register_UnityEngine_Camera_RemoveAllCommandBuffers();
		Register_UnityEngine_Camera_RemoveAllCommandBuffers();

		//System.Void UnityEngine.Camera::RemoveCommandBuffer(UnityEngine.Rendering.CameraEvent,UnityEngine.Rendering.CommandBuffer)
		void Register_UnityEngine_Camera_RemoveCommandBuffer();
		Register_UnityEngine_Camera_RemoveCommandBuffer();

		//System.Void UnityEngine.Camera::RemoveCommandBuffers(UnityEngine.Rendering.CameraEvent)
		void Register_UnityEngine_Camera_RemoveCommandBuffers();
		Register_UnityEngine_Camera_RemoveCommandBuffers();

		//System.Void UnityEngine.Camera::Render()
		void Register_UnityEngine_Camera_Render();
		Register_UnityEngine_Camera_Render();

		//System.Void UnityEngine.Camera::RenderDontRestore()
		void Register_UnityEngine_Camera_RenderDontRestore();
		Register_UnityEngine_Camera_RenderDontRestore();

		//System.Void UnityEngine.Camera::RenderWithShader(UnityEngine.Shader,System.String)
		void Register_UnityEngine_Camera_RenderWithShader();
		Register_UnityEngine_Camera_RenderWithShader();

		//System.Void UnityEngine.Camera::ResetStereoProjectionMatrices()
		void Register_UnityEngine_Camera_ResetStereoProjectionMatrices();
		Register_UnityEngine_Camera_ResetStereoProjectionMatrices();

		//System.Void UnityEngine.Camera::ResetStereoViewMatrices()
		void Register_UnityEngine_Camera_ResetStereoViewMatrices();
		Register_UnityEngine_Camera_ResetStereoViewMatrices();

		//System.Void UnityEngine.Camera::SetReplacementShader(UnityEngine.Shader,System.String)
		void Register_UnityEngine_Camera_SetReplacementShader();
		Register_UnityEngine_Camera_SetReplacementShader();

		//System.Void UnityEngine.Camera::SetTargetBuffersImpl(UnityEngine.RenderBuffer&,UnityEngine.RenderBuffer&)
		void Register_UnityEngine_Camera_SetTargetBuffersImpl();
		Register_UnityEngine_Camera_SetTargetBuffersImpl();

		//System.Void UnityEngine.Camera::SetTargetBuffersMRTImpl(UnityEngine.RenderBuffer[],UnityEngine.RenderBuffer&)
		void Register_UnityEngine_Camera_SetTargetBuffersMRTImpl();
		Register_UnityEngine_Camera_SetTargetBuffersMRTImpl();

		//System.Void UnityEngine.Camera::SetupCurrent(UnityEngine.Camera)
		void Register_UnityEngine_Camera_SetupCurrent();
		Register_UnityEngine_Camera_SetupCurrent();

		//System.Void UnityEngine.Camera::set_aspect(System.Single)
		void Register_UnityEngine_Camera_set_aspect();
		Register_UnityEngine_Camera_set_aspect();

		//System.Void UnityEngine.Camera::set_cameraType(UnityEngine.CameraType)
		void Register_UnityEngine_Camera_set_cameraType();
		Register_UnityEngine_Camera_set_cameraType();

		//System.Void UnityEngine.Camera::set_clearFlags(UnityEngine.CameraClearFlags)
		void Register_UnityEngine_Camera_set_clearFlags();
		Register_UnityEngine_Camera_set_clearFlags();

		//System.Void UnityEngine.Camera::set_clearStencilAfterLightingPass(System.Boolean)
		void Register_UnityEngine_Camera_set_clearStencilAfterLightingPass();
		Register_UnityEngine_Camera_set_clearStencilAfterLightingPass();

		//System.Void UnityEngine.Camera::set_cullingMask(System.Int32)
		void Register_UnityEngine_Camera_set_cullingMask();
		Register_UnityEngine_Camera_set_cullingMask();

		//System.Void UnityEngine.Camera::set_depth(System.Single)
		void Register_UnityEngine_Camera_set_depth();
		Register_UnityEngine_Camera_set_depth();

		//System.Void UnityEngine.Camera::set_depthTextureMode(UnityEngine.DepthTextureMode)
		void Register_UnityEngine_Camera_set_depthTextureMode();
		Register_UnityEngine_Camera_set_depthTextureMode();

		//System.Void UnityEngine.Camera::set_eventMask(System.Int32)
		void Register_UnityEngine_Camera_set_eventMask();
		Register_UnityEngine_Camera_set_eventMask();

		//System.Void UnityEngine.Camera::set_farClipPlane(System.Single)
		void Register_UnityEngine_Camera_set_farClipPlane();
		Register_UnityEngine_Camera_set_farClipPlane();

		//System.Void UnityEngine.Camera::set_fieldOfView(System.Single)
		void Register_UnityEngine_Camera_set_fieldOfView();
		Register_UnityEngine_Camera_set_fieldOfView();

		//System.Void UnityEngine.Camera::set_hdr(System.Boolean)
		void Register_UnityEngine_Camera_set_hdr();
		Register_UnityEngine_Camera_set_hdr();

		//System.Void UnityEngine.Camera::set_layerCullDistances(System.Single[])
		void Register_UnityEngine_Camera_set_layerCullDistances();
		Register_UnityEngine_Camera_set_layerCullDistances();

		//System.Void UnityEngine.Camera::set_layerCullSpherical(System.Boolean)
		void Register_UnityEngine_Camera_set_layerCullSpherical();
		Register_UnityEngine_Camera_set_layerCullSpherical();

		//System.Void UnityEngine.Camera::set_nearClipPlane(System.Single)
		void Register_UnityEngine_Camera_set_nearClipPlane();
		Register_UnityEngine_Camera_set_nearClipPlane();

		//System.Void UnityEngine.Camera::set_opaqueSortMode(UnityEngine.Rendering.OpaqueSortMode)
		void Register_UnityEngine_Camera_set_opaqueSortMode();
		Register_UnityEngine_Camera_set_opaqueSortMode();

		//System.Void UnityEngine.Camera::set_orthographic(System.Boolean)
		void Register_UnityEngine_Camera_set_orthographic();
		Register_UnityEngine_Camera_set_orthographic();

		//System.Void UnityEngine.Camera::set_orthographicSize(System.Single)
		void Register_UnityEngine_Camera_set_orthographicSize();
		Register_UnityEngine_Camera_set_orthographicSize();

		//System.Void UnityEngine.Camera::set_renderingPath(UnityEngine.RenderingPath)
		void Register_UnityEngine_Camera_set_renderingPath();
		Register_UnityEngine_Camera_set_renderingPath();

		//System.Void UnityEngine.Camera::set_stereoConvergence(System.Single)
		void Register_UnityEngine_Camera_set_stereoConvergence();
		Register_UnityEngine_Camera_set_stereoConvergence();

		//System.Void UnityEngine.Camera::set_stereoMirrorMode(System.Boolean)
		void Register_UnityEngine_Camera_set_stereoMirrorMode();
		Register_UnityEngine_Camera_set_stereoMirrorMode();

		//System.Void UnityEngine.Camera::set_stereoSeparation(System.Single)
		void Register_UnityEngine_Camera_set_stereoSeparation();
		Register_UnityEngine_Camera_set_stereoSeparation();

		//System.Void UnityEngine.Camera::set_stereoTargetEye(UnityEngine.StereoTargetEyeMask)
		void Register_UnityEngine_Camera_set_stereoTargetEye();
		Register_UnityEngine_Camera_set_stereoTargetEye();

		//System.Void UnityEngine.Camera::set_targetDisplay(System.Int32)
		void Register_UnityEngine_Camera_set_targetDisplay();
		Register_UnityEngine_Camera_set_targetDisplay();

		//System.Void UnityEngine.Camera::set_targetTexture(UnityEngine.RenderTexture)
		void Register_UnityEngine_Camera_set_targetTexture();
		Register_UnityEngine_Camera_set_targetTexture();

		//System.Void UnityEngine.Camera::set_transparencySortMode(UnityEngine.TransparencySortMode)
		void Register_UnityEngine_Camera_set_transparencySortMode();
		Register_UnityEngine_Camera_set_transparencySortMode();

		//System.Void UnityEngine.Camera::set_useJitteredProjectionMatrixForTransparentRendering(System.Boolean)
		void Register_UnityEngine_Camera_set_useJitteredProjectionMatrixForTransparentRendering();
		Register_UnityEngine_Camera_set_useJitteredProjectionMatrixForTransparentRendering();

		//System.Void UnityEngine.Camera::set_useOcclusionCulling(System.Boolean)
		void Register_UnityEngine_Camera_set_useOcclusionCulling();
		Register_UnityEngine_Camera_set_useOcclusionCulling();

		//UnityEngine.Camera UnityEngine.Camera::get_current()
		void Register_UnityEngine_Camera_get_current();
		Register_UnityEngine_Camera_get_current();

		//UnityEngine.Camera UnityEngine.Camera::get_main()
		void Register_UnityEngine_Camera_get_main();
		Register_UnityEngine_Camera_get_main();

		//UnityEngine.Camera/MonoOrStereoscopicEye UnityEngine.Camera::get_stereoActiveEye()
		void Register_UnityEngine_Camera_get_stereoActiveEye();
		Register_UnityEngine_Camera_get_stereoActiveEye();

		//UnityEngine.CameraClearFlags UnityEngine.Camera::get_clearFlags()
		void Register_UnityEngine_Camera_get_clearFlags();
		Register_UnityEngine_Camera_get_clearFlags();

		//UnityEngine.CameraType UnityEngine.Camera::get_cameraType()
		void Register_UnityEngine_Camera_get_cameraType();
		Register_UnityEngine_Camera_get_cameraType();

		//UnityEngine.Camera[] UnityEngine.Camera::get_allCameras()
		void Register_UnityEngine_Camera_get_allCameras();
		Register_UnityEngine_Camera_get_allCameras();

		//UnityEngine.DepthTextureMode UnityEngine.Camera::get_depthTextureMode()
		void Register_UnityEngine_Camera_get_depthTextureMode();
		Register_UnityEngine_Camera_get_depthTextureMode();

		//UnityEngine.GameObject UnityEngine.Camera::INTERNAL_CALL_RaycastTry(UnityEngine.Camera,UnityEngine.Ray&,System.Single,System.Int32,UnityEngine.QueryTriggerInteraction)
		void Register_UnityEngine_Camera_INTERNAL_CALL_RaycastTry();
		Register_UnityEngine_Camera_INTERNAL_CALL_RaycastTry();

		//UnityEngine.GameObject UnityEngine.Camera::INTERNAL_CALL_RaycastTry2D(UnityEngine.Camera,UnityEngine.Ray&,System.Single,System.Int32)
		void Register_UnityEngine_Camera_INTERNAL_CALL_RaycastTry2D();
		Register_UnityEngine_Camera_INTERNAL_CALL_RaycastTry2D();

		//UnityEngine.Matrix4x4[] UnityEngine.Camera::GetStereoProjectionMatrices()
		void Register_UnityEngine_Camera_GetStereoProjectionMatrices();
		Register_UnityEngine_Camera_GetStereoProjectionMatrices();

		//UnityEngine.Matrix4x4[] UnityEngine.Camera::GetStereoViewMatrices()
		void Register_UnityEngine_Camera_GetStereoViewMatrices();
		Register_UnityEngine_Camera_GetStereoViewMatrices();

		//UnityEngine.RenderTexture UnityEngine.Camera::get_targetTexture()
		void Register_UnityEngine_Camera_get_targetTexture();
		Register_UnityEngine_Camera_get_targetTexture();

		//UnityEngine.Rendering.CommandBuffer[] UnityEngine.Camera::GetCommandBuffers(UnityEngine.Rendering.CameraEvent)
		void Register_UnityEngine_Camera_GetCommandBuffers();
		Register_UnityEngine_Camera_GetCommandBuffers();

		//UnityEngine.Rendering.OpaqueSortMode UnityEngine.Camera::get_opaqueSortMode()
		void Register_UnityEngine_Camera_get_opaqueSortMode();
		Register_UnityEngine_Camera_get_opaqueSortMode();

		//UnityEngine.RenderingPath UnityEngine.Camera::get_actualRenderingPath()
		void Register_UnityEngine_Camera_get_actualRenderingPath();
		Register_UnityEngine_Camera_get_actualRenderingPath();

		//UnityEngine.RenderingPath UnityEngine.Camera::get_renderingPath()
		void Register_UnityEngine_Camera_get_renderingPath();
		Register_UnityEngine_Camera_get_renderingPath();

		//UnityEngine.StereoTargetEyeMask UnityEngine.Camera::get_stereoTargetEye()
		void Register_UnityEngine_Camera_get_stereoTargetEye();
		Register_UnityEngine_Camera_get_stereoTargetEye();

		//UnityEngine.TransparencySortMode UnityEngine.Camera::get_transparencySortMode()
		void Register_UnityEngine_Camera_get_transparencySortMode();
		Register_UnityEngine_Camera_get_transparencySortMode();

	//End Registrations for type : UnityEngine.Camera

	//Start Registrations for type : UnityEngine.Canvas

		//System.Boolean UnityEngine.Canvas::get_isRootCanvas()
		void Register_UnityEngine_Canvas_get_isRootCanvas();
		Register_UnityEngine_Canvas_get_isRootCanvas();

		//System.Boolean UnityEngine.Canvas::get_overridePixelPerfect()
		void Register_UnityEngine_Canvas_get_overridePixelPerfect();
		Register_UnityEngine_Canvas_get_overridePixelPerfect();

		//System.Boolean UnityEngine.Canvas::get_overrideSorting()
		void Register_UnityEngine_Canvas_get_overrideSorting();
		Register_UnityEngine_Canvas_get_overrideSorting();

		//System.Boolean UnityEngine.Canvas::get_pixelPerfect()
		void Register_UnityEngine_Canvas_get_pixelPerfect();
		Register_UnityEngine_Canvas_get_pixelPerfect();

		//System.Int32 UnityEngine.Canvas::get_cachedSortingLayerValue()
		void Register_UnityEngine_Canvas_get_cachedSortingLayerValue();
		Register_UnityEngine_Canvas_get_cachedSortingLayerValue();

		//System.Int32 UnityEngine.Canvas::get_renderOrder()
		void Register_UnityEngine_Canvas_get_renderOrder();
		Register_UnityEngine_Canvas_get_renderOrder();

		//System.Int32 UnityEngine.Canvas::get_sortingGridNormalizedSize()
		void Register_UnityEngine_Canvas_get_sortingGridNormalizedSize();
		Register_UnityEngine_Canvas_get_sortingGridNormalizedSize();

		//System.Int32 UnityEngine.Canvas::get_sortingLayerID()
		void Register_UnityEngine_Canvas_get_sortingLayerID();
		Register_UnityEngine_Canvas_get_sortingLayerID();

		//System.Int32 UnityEngine.Canvas::get_sortingOrder()
		void Register_UnityEngine_Canvas_get_sortingOrder();
		Register_UnityEngine_Canvas_get_sortingOrder();

		//System.Int32 UnityEngine.Canvas::get_targetDisplay()
		void Register_UnityEngine_Canvas_get_targetDisplay();
		Register_UnityEngine_Canvas_get_targetDisplay();

		//System.Single UnityEngine.Canvas::get_normalizedSortingGridSize()
		void Register_UnityEngine_Canvas_get_normalizedSortingGridSize();
		Register_UnityEngine_Canvas_get_normalizedSortingGridSize();

		//System.Single UnityEngine.Canvas::get_planeDistance()
		void Register_UnityEngine_Canvas_get_planeDistance();
		Register_UnityEngine_Canvas_get_planeDistance();

		//System.Single UnityEngine.Canvas::get_referencePixelsPerUnit()
		void Register_UnityEngine_Canvas_get_referencePixelsPerUnit();
		Register_UnityEngine_Canvas_get_referencePixelsPerUnit();

		//System.Single UnityEngine.Canvas::get_scaleFactor()
		void Register_UnityEngine_Canvas_get_scaleFactor();
		Register_UnityEngine_Canvas_get_scaleFactor();

		//System.String UnityEngine.Canvas::get_sortingLayerName()
		void Register_UnityEngine_Canvas_get_sortingLayerName();
		Register_UnityEngine_Canvas_get_sortingLayerName();

		//System.Void UnityEngine.Canvas::INTERNAL_get_pixelRect(UnityEngine.Rect&)
		void Register_UnityEngine_Canvas_INTERNAL_get_pixelRect();
		Register_UnityEngine_Canvas_INTERNAL_get_pixelRect();

		//System.Void UnityEngine.Canvas::set_normalizedSortingGridSize(System.Single)
		void Register_UnityEngine_Canvas_set_normalizedSortingGridSize();
		Register_UnityEngine_Canvas_set_normalizedSortingGridSize();

		//System.Void UnityEngine.Canvas::set_overridePixelPerfect(System.Boolean)
		void Register_UnityEngine_Canvas_set_overridePixelPerfect();
		Register_UnityEngine_Canvas_set_overridePixelPerfect();

		//System.Void UnityEngine.Canvas::set_overrideSorting(System.Boolean)
		void Register_UnityEngine_Canvas_set_overrideSorting();
		Register_UnityEngine_Canvas_set_overrideSorting();

		//System.Void UnityEngine.Canvas::set_pixelPerfect(System.Boolean)
		void Register_UnityEngine_Canvas_set_pixelPerfect();
		Register_UnityEngine_Canvas_set_pixelPerfect();

		//System.Void UnityEngine.Canvas::set_planeDistance(System.Single)
		void Register_UnityEngine_Canvas_set_planeDistance();
		Register_UnityEngine_Canvas_set_planeDistance();

		//System.Void UnityEngine.Canvas::set_referencePixelsPerUnit(System.Single)
		void Register_UnityEngine_Canvas_set_referencePixelsPerUnit();
		Register_UnityEngine_Canvas_set_referencePixelsPerUnit();

		//System.Void UnityEngine.Canvas::set_renderMode(UnityEngine.RenderMode)
		void Register_UnityEngine_Canvas_set_renderMode();
		Register_UnityEngine_Canvas_set_renderMode();

		//System.Void UnityEngine.Canvas::set_scaleFactor(System.Single)
		void Register_UnityEngine_Canvas_set_scaleFactor();
		Register_UnityEngine_Canvas_set_scaleFactor();

		//System.Void UnityEngine.Canvas::set_sortingGridNormalizedSize(System.Int32)
		void Register_UnityEngine_Canvas_set_sortingGridNormalizedSize();
		Register_UnityEngine_Canvas_set_sortingGridNormalizedSize();

		//System.Void UnityEngine.Canvas::set_sortingLayerID(System.Int32)
		void Register_UnityEngine_Canvas_set_sortingLayerID();
		Register_UnityEngine_Canvas_set_sortingLayerID();

		//System.Void UnityEngine.Canvas::set_sortingLayerName(System.String)
		void Register_UnityEngine_Canvas_set_sortingLayerName();
		Register_UnityEngine_Canvas_set_sortingLayerName();

		//System.Void UnityEngine.Canvas::set_sortingOrder(System.Int32)
		void Register_UnityEngine_Canvas_set_sortingOrder();
		Register_UnityEngine_Canvas_set_sortingOrder();

		//System.Void UnityEngine.Canvas::set_targetDisplay(System.Int32)
		void Register_UnityEngine_Canvas_set_targetDisplay();
		Register_UnityEngine_Canvas_set_targetDisplay();

		//System.Void UnityEngine.Canvas::set_worldCamera(UnityEngine.Camera)
		void Register_UnityEngine_Canvas_set_worldCamera();
		Register_UnityEngine_Canvas_set_worldCamera();

		//UnityEngine.Camera UnityEngine.Canvas::get_worldCamera()
		void Register_UnityEngine_Canvas_get_worldCamera();
		Register_UnityEngine_Canvas_get_worldCamera();

		//UnityEngine.Canvas UnityEngine.Canvas::get_rootCanvas()
		void Register_UnityEngine_Canvas_get_rootCanvas();
		Register_UnityEngine_Canvas_get_rootCanvas();

		//UnityEngine.Material UnityEngine.Canvas::GetDefaultCanvasMaterial()
		void Register_UnityEngine_Canvas_GetDefaultCanvasMaterial();
		Register_UnityEngine_Canvas_GetDefaultCanvasMaterial();

		//UnityEngine.Material UnityEngine.Canvas::GetDefaultCanvasTextMaterial()
		void Register_UnityEngine_Canvas_GetDefaultCanvasTextMaterial();
		Register_UnityEngine_Canvas_GetDefaultCanvasTextMaterial();

		//UnityEngine.Material UnityEngine.Canvas::GetETC1SupportedCanvasMaterial()
		void Register_UnityEngine_Canvas_GetETC1SupportedCanvasMaterial();
		Register_UnityEngine_Canvas_GetETC1SupportedCanvasMaterial();

		//UnityEngine.RenderMode UnityEngine.Canvas::get_renderMode()
		void Register_UnityEngine_Canvas_get_renderMode();
		Register_UnityEngine_Canvas_get_renderMode();

	//End Registrations for type : UnityEngine.Canvas

	//Start Registrations for type : UnityEngine.CanvasGroup

		//System.Boolean UnityEngine.CanvasGroup::get_blocksRaycasts()
		void Register_UnityEngine_CanvasGroup_get_blocksRaycasts();
		Register_UnityEngine_CanvasGroup_get_blocksRaycasts();

		//System.Boolean UnityEngine.CanvasGroup::get_ignoreParentGroups()
		void Register_UnityEngine_CanvasGroup_get_ignoreParentGroups();
		Register_UnityEngine_CanvasGroup_get_ignoreParentGroups();

		//System.Boolean UnityEngine.CanvasGroup::get_interactable()
		void Register_UnityEngine_CanvasGroup_get_interactable();
		Register_UnityEngine_CanvasGroup_get_interactable();

		//System.Single UnityEngine.CanvasGroup::get_alpha()
		void Register_UnityEngine_CanvasGroup_get_alpha();
		Register_UnityEngine_CanvasGroup_get_alpha();

		//System.Void UnityEngine.CanvasGroup::set_alpha(System.Single)
		void Register_UnityEngine_CanvasGroup_set_alpha();
		Register_UnityEngine_CanvasGroup_set_alpha();

	//End Registrations for type : UnityEngine.CanvasGroup

	//Start Registrations for type : UnityEngine.CanvasRenderer

		//System.Boolean UnityEngine.CanvasRenderer::get_cull()
		void Register_UnityEngine_CanvasRenderer_get_cull();
		Register_UnityEngine_CanvasRenderer_get_cull();

		//System.Boolean UnityEngine.CanvasRenderer::get_hasMoved()
		void Register_UnityEngine_CanvasRenderer_get_hasMoved();
		Register_UnityEngine_CanvasRenderer_get_hasMoved();

		//System.Int32 UnityEngine.CanvasRenderer::get_absoluteDepth()
		void Register_UnityEngine_CanvasRenderer_get_absoluteDepth();
		Register_UnityEngine_CanvasRenderer_get_absoluteDepth();

		//System.Int32 UnityEngine.CanvasRenderer::get_materialCount()
		void Register_UnityEngine_CanvasRenderer_get_materialCount();
		Register_UnityEngine_CanvasRenderer_get_materialCount();

		//System.Void UnityEngine.CanvasRenderer::Clear()
		void Register_UnityEngine_CanvasRenderer_Clear();
		Register_UnityEngine_CanvasRenderer_Clear();

		//System.Void UnityEngine.CanvasRenderer::CreateUIVertexStreamInternal(System.Object,System.Object,System.Object,System.Object,System.Object,System.Object,System.Object,System.Object)
		void Register_UnityEngine_CanvasRenderer_CreateUIVertexStreamInternal();
		Register_UnityEngine_CanvasRenderer_CreateUIVertexStreamInternal();

		//System.Void UnityEngine.CanvasRenderer::DisableRectClipping()
		void Register_UnityEngine_CanvasRenderer_DisableRectClipping();
		Register_UnityEngine_CanvasRenderer_DisableRectClipping();

		//System.Void UnityEngine.CanvasRenderer::INTERNAL_CALL_EnableRectClipping(UnityEngine.CanvasRenderer,UnityEngine.Rect&)
		void Register_UnityEngine_CanvasRenderer_INTERNAL_CALL_EnableRectClipping();
		Register_UnityEngine_CanvasRenderer_INTERNAL_CALL_EnableRectClipping();

		//System.Void UnityEngine.CanvasRenderer::INTERNAL_CALL_GetColor(UnityEngine.CanvasRenderer,UnityEngine.Color&)
		void Register_UnityEngine_CanvasRenderer_INTERNAL_CALL_GetColor();
		Register_UnityEngine_CanvasRenderer_INTERNAL_CALL_GetColor();

		//System.Void UnityEngine.CanvasRenderer::INTERNAL_CALL_SetColor(UnityEngine.CanvasRenderer,UnityEngine.Color&)
		void Register_UnityEngine_CanvasRenderer_INTERNAL_CALL_SetColor();
		Register_UnityEngine_CanvasRenderer_INTERNAL_CALL_SetColor();

		//System.Void UnityEngine.CanvasRenderer::SetAlphaTexture(UnityEngine.Texture)
		void Register_UnityEngine_CanvasRenderer_SetAlphaTexture();
		Register_UnityEngine_CanvasRenderer_SetAlphaTexture();

		//System.Void UnityEngine.CanvasRenderer::SetMaterial(UnityEngine.Material,System.Int32)
		void Register_UnityEngine_CanvasRenderer_SetMaterial();
		Register_UnityEngine_CanvasRenderer_SetMaterial();

		//System.Void UnityEngine.CanvasRenderer::SetMesh(UnityEngine.Mesh)
		void Register_UnityEngine_CanvasRenderer_SetMesh();
		Register_UnityEngine_CanvasRenderer_SetMesh();

		//System.Void UnityEngine.CanvasRenderer::SetPopMaterial(UnityEngine.Material,System.Int32)
		void Register_UnityEngine_CanvasRenderer_SetPopMaterial();
		Register_UnityEngine_CanvasRenderer_SetPopMaterial();

		//System.Void UnityEngine.CanvasRenderer::SetTexture(UnityEngine.Texture)
		void Register_UnityEngine_CanvasRenderer_SetTexture();
		Register_UnityEngine_CanvasRenderer_SetTexture();

		//System.Void UnityEngine.CanvasRenderer::SplitIndiciesStreamsInternal(System.Object,System.Object)
		void Register_UnityEngine_CanvasRenderer_SplitIndiciesStreamsInternal();
		Register_UnityEngine_CanvasRenderer_SplitIndiciesStreamsInternal();

		//System.Void UnityEngine.CanvasRenderer::SplitUIVertexStreamsInternal(System.Object,System.Object,System.Object,System.Object,System.Object,System.Object,System.Object)
		void Register_UnityEngine_CanvasRenderer_SplitUIVertexStreamsInternal();
		Register_UnityEngine_CanvasRenderer_SplitUIVertexStreamsInternal();

		//System.Void UnityEngine.CanvasRenderer::set_cull(System.Boolean)
		void Register_UnityEngine_CanvasRenderer_set_cull();
		Register_UnityEngine_CanvasRenderer_set_cull();

		//System.Void UnityEngine.CanvasRenderer::set_hasPopInstruction(System.Boolean)
		void Register_UnityEngine_CanvasRenderer_set_hasPopInstruction();
		Register_UnityEngine_CanvasRenderer_set_hasPopInstruction();

		//System.Void UnityEngine.CanvasRenderer::set_materialCount(System.Int32)
		void Register_UnityEngine_CanvasRenderer_set_materialCount();
		Register_UnityEngine_CanvasRenderer_set_materialCount();

		//System.Void UnityEngine.CanvasRenderer::set_popMaterialCount(System.Int32)
		void Register_UnityEngine_CanvasRenderer_set_popMaterialCount();
		Register_UnityEngine_CanvasRenderer_set_popMaterialCount();

	//End Registrations for type : UnityEngine.CanvasRenderer

	//Start Registrations for type : UnityEngine.CharacterController

		//System.Void UnityEngine.CharacterController::INTERNAL_get_velocity(UnityEngine.Vector3&)
		void Register_UnityEngine_CharacterController_INTERNAL_get_velocity();
		Register_UnityEngine_CharacterController_INTERNAL_get_velocity();

		//UnityEngine.CollisionFlags UnityEngine.CharacterController::INTERNAL_CALL_Move(UnityEngine.CharacterController,UnityEngine.Vector3&)
		void Register_UnityEngine_CharacterController_INTERNAL_CALL_Move();
		Register_UnityEngine_CharacterController_INTERNAL_CALL_Move();

	//End Registrations for type : UnityEngine.CharacterController

	//Start Registrations for type : UnityEngine.Collider

		//UnityEngine.Rigidbody UnityEngine.Collider::get_attachedRigidbody()
		void Register_UnityEngine_Collider_get_attachedRigidbody();
		Register_UnityEngine_Collider_get_attachedRigidbody();

	//End Registrations for type : UnityEngine.Collider

	//Start Registrations for type : UnityEngine.Component

		//System.Boolean UnityEngine.Component::CompareTag(System.String)
		void Register_UnityEngine_Component_CompareTag();
		Register_UnityEngine_Component_CompareTag();

		//System.Void UnityEngine.Component::BroadcastMessage(System.String,System.Object,UnityEngine.SendMessageOptions)
		void Register_UnityEngine_Component_BroadcastMessage();
		Register_UnityEngine_Component_BroadcastMessage();

		//System.Void UnityEngine.Component::GetComponentFastPath(System.Type,System.IntPtr)
		void Register_UnityEngine_Component_GetComponentFastPath();
		Register_UnityEngine_Component_GetComponentFastPath();

		//System.Void UnityEngine.Component::GetComponentsForListInternal(System.Type,System.Object)
		void Register_UnityEngine_Component_GetComponentsForListInternal();
		Register_UnityEngine_Component_GetComponentsForListInternal();

		//System.Void UnityEngine.Component::SendMessage(System.String,System.Object,UnityEngine.SendMessageOptions)
		void Register_UnityEngine_Component_SendMessage();
		Register_UnityEngine_Component_SendMessage();

		//System.Void UnityEngine.Component::SendMessageUpwards(System.String,System.Object,UnityEngine.SendMessageOptions)
		void Register_UnityEngine_Component_SendMessageUpwards();
		Register_UnityEngine_Component_SendMessageUpwards();

		//UnityEngine.Component UnityEngine.Component::GetComponent(System.String)
		void Register_UnityEngine_Component_GetComponent();
		Register_UnityEngine_Component_GetComponent();

		//UnityEngine.GameObject UnityEngine.Component::get_gameObject()
		void Register_UnityEngine_Component_get_gameObject();
		Register_UnityEngine_Component_get_gameObject();

		//UnityEngine.Transform UnityEngine.Component::get_transform()
		void Register_UnityEngine_Component_get_transform();
		Register_UnityEngine_Component_get_transform();

	//End Registrations for type : UnityEngine.Component

	//Start Registrations for type : UnityEngine.Coroutine

		//System.Void UnityEngine.Coroutine::ReleaseCoroutine()
		void Register_UnityEngine_Coroutine_ReleaseCoroutine();
		Register_UnityEngine_Coroutine_ReleaseCoroutine();

	//End Registrations for type : UnityEngine.Coroutine

	//Start Registrations for type : UnityEngine.CullingGroup

		//System.Boolean UnityEngine.CullingGroup::IsVisible(System.Int32)
		void Register_UnityEngine_CullingGroup_IsVisible();
		Register_UnityEngine_CullingGroup_IsVisible();

		//System.Boolean UnityEngine.CullingGroup::get_enabled()
		void Register_UnityEngine_CullingGroup_get_enabled();
		Register_UnityEngine_CullingGroup_get_enabled();

		//System.Int32 UnityEngine.CullingGroup::GetDistance(System.Int32)
		void Register_UnityEngine_CullingGroup_GetDistance();
		Register_UnityEngine_CullingGroup_GetDistance();

		//System.Int32 UnityEngine.CullingGroup::QueryIndices(System.Boolean,System.Int32,UnityEngine.CullingQueryOptions,System.Int32[],System.Int32)
		void Register_UnityEngine_CullingGroup_QueryIndices();
		Register_UnityEngine_CullingGroup_QueryIndices();

		//System.Void UnityEngine.CullingGroup::Dispose()
		void Register_UnityEngine_CullingGroup_Dispose();
		Register_UnityEngine_CullingGroup_Dispose();

		//System.Void UnityEngine.CullingGroup::EraseSwapBack(System.Int32)
		void Register_UnityEngine_CullingGroup_EraseSwapBack();
		Register_UnityEngine_CullingGroup_EraseSwapBack();

		//System.Void UnityEngine.CullingGroup::FinalizerFailure()
		void Register_UnityEngine_CullingGroup_FinalizerFailure();
		Register_UnityEngine_CullingGroup_FinalizerFailure();

		//System.Void UnityEngine.CullingGroup::INTERNAL_CALL_SetDistanceReferencePoint(UnityEngine.CullingGroup,UnityEngine.Vector3&)
		void Register_UnityEngine_CullingGroup_INTERNAL_CALL_SetDistanceReferencePoint();
		Register_UnityEngine_CullingGroup_INTERNAL_CALL_SetDistanceReferencePoint();

		//System.Void UnityEngine.CullingGroup::Init()
		void Register_UnityEngine_CullingGroup_Init();
		Register_UnityEngine_CullingGroup_Init();

		//System.Void UnityEngine.CullingGroup::SetBoundingDistances(System.Single[])
		void Register_UnityEngine_CullingGroup_SetBoundingDistances();
		Register_UnityEngine_CullingGroup_SetBoundingDistances();

		//System.Void UnityEngine.CullingGroup::SetBoundingSphereCount(System.Int32)
		void Register_UnityEngine_CullingGroup_SetBoundingSphereCount();
		Register_UnityEngine_CullingGroup_SetBoundingSphereCount();

		//System.Void UnityEngine.CullingGroup::SetBoundingSpheres(UnityEngine.BoundingSphere[])
		void Register_UnityEngine_CullingGroup_SetBoundingSpheres();
		Register_UnityEngine_CullingGroup_SetBoundingSpheres();

		//System.Void UnityEngine.CullingGroup::SetDistanceReferencePoint(UnityEngine.Transform)
		void Register_UnityEngine_CullingGroup_SetDistanceReferencePoint();
		Register_UnityEngine_CullingGroup_SetDistanceReferencePoint();

		//System.Void UnityEngine.CullingGroup::set_enabled(System.Boolean)
		void Register_UnityEngine_CullingGroup_set_enabled();
		Register_UnityEngine_CullingGroup_set_enabled();

		//System.Void UnityEngine.CullingGroup::set_targetCamera(UnityEngine.Camera)
		void Register_UnityEngine_CullingGroup_set_targetCamera();
		Register_UnityEngine_CullingGroup_set_targetCamera();

		//UnityEngine.Camera UnityEngine.CullingGroup::get_targetCamera()
		void Register_UnityEngine_CullingGroup_get_targetCamera();
		Register_UnityEngine_CullingGroup_get_targetCamera();

	//End Registrations for type : UnityEngine.CullingGroup

	//Start Registrations for type : UnityEngine.Cursor

		//UnityEngine.CursorLockMode UnityEngine.Cursor::get_lockState()
		void Register_UnityEngine_Cursor_get_lockState();
		Register_UnityEngine_Cursor_get_lockState();

	//End Registrations for type : UnityEngine.Cursor

	//Start Registrations for type : UnityEngine.DebugLogHandler

		//System.Void UnityEngine.DebugLogHandler::Internal_Log(UnityEngine.LogType,System.String,UnityEngine.Object)
		void Register_UnityEngine_DebugLogHandler_Internal_Log();
		Register_UnityEngine_DebugLogHandler_Internal_Log();

		//System.Void UnityEngine.DebugLogHandler::Internal_LogException(System.Exception,UnityEngine.Object)
		void Register_UnityEngine_DebugLogHandler_Internal_LogException();
		Register_UnityEngine_DebugLogHandler_Internal_LogException();

	//End Registrations for type : UnityEngine.DebugLogHandler

	//Start Registrations for type : UnityEngine.Display

		//System.Int32 UnityEngine.Display::RelativeMouseAtImpl(System.Int32,System.Int32,System.Int32&,System.Int32&)
		void Register_UnityEngine_Display_RelativeMouseAtImpl();
		Register_UnityEngine_Display_RelativeMouseAtImpl();

		//System.Void UnityEngine.Display::ActivateDisplayImpl(System.IntPtr,System.Int32,System.Int32,System.Int32)
		void Register_UnityEngine_Display_ActivateDisplayImpl();
		Register_UnityEngine_Display_ActivateDisplayImpl();

		//System.Void UnityEngine.Display::GetRenderingBuffersImpl(System.IntPtr,UnityEngine.RenderBuffer&,UnityEngine.RenderBuffer&)
		void Register_UnityEngine_Display_GetRenderingBuffersImpl();
		Register_UnityEngine_Display_GetRenderingBuffersImpl();

		//System.Void UnityEngine.Display::GetRenderingExtImpl(System.IntPtr,System.Int32&,System.Int32&)
		void Register_UnityEngine_Display_GetRenderingExtImpl();
		Register_UnityEngine_Display_GetRenderingExtImpl();

		//System.Void UnityEngine.Display::GetSystemExtImpl(System.IntPtr,System.Int32&,System.Int32&)
		void Register_UnityEngine_Display_GetSystemExtImpl();
		Register_UnityEngine_Display_GetSystemExtImpl();

		//System.Void UnityEngine.Display::SetParamsImpl(System.IntPtr,System.Int32,System.Int32,System.Int32,System.Int32)
		void Register_UnityEngine_Display_SetParamsImpl();
		Register_UnityEngine_Display_SetParamsImpl();

		//System.Void UnityEngine.Display::SetRenderingResolutionImpl(System.IntPtr,System.Int32,System.Int32)
		void Register_UnityEngine_Display_SetRenderingResolutionImpl();
		Register_UnityEngine_Display_SetRenderingResolutionImpl();

	//End Registrations for type : UnityEngine.Display

	//Start Registrations for type : UnityEngine.Event

		//System.Boolean UnityEngine.Event::PopEvent(UnityEngine.Event)
		void Register_UnityEngine_Event_PopEvent();
		Register_UnityEngine_Event_PopEvent();

		//System.Char UnityEngine.Event::get_character()
		void Register_UnityEngine_Event_get_character();
		Register_UnityEngine_Event_get_character();

		//System.Int32 UnityEngine.Event::GetEventCount()
		void Register_UnityEngine_Event_GetEventCount();
		Register_UnityEngine_Event_GetEventCount();

		//System.Int32 UnityEngine.Event::get_button()
		void Register_UnityEngine_Event_get_button();
		Register_UnityEngine_Event_get_button();

		//System.Int32 UnityEngine.Event::get_clickCount()
		void Register_UnityEngine_Event_get_clickCount();
		Register_UnityEngine_Event_get_clickCount();

		//System.Int32 UnityEngine.Event::get_displayIndex()
		void Register_UnityEngine_Event_get_displayIndex();
		Register_UnityEngine_Event_get_displayIndex();

		//System.Single UnityEngine.Event::get_pressure()
		void Register_UnityEngine_Event_get_pressure();
		Register_UnityEngine_Event_get_pressure();

		//System.String UnityEngine.Event::get_commandName()
		void Register_UnityEngine_Event_get_commandName();
		Register_UnityEngine_Event_get_commandName();

		//System.Void UnityEngine.Event::Cleanup()
		void Register_UnityEngine_Event_Cleanup();
		Register_UnityEngine_Event_Cleanup();

		//System.Void UnityEngine.Event::INTERNAL_CALL_Internal_SetMouseDelta(UnityEngine.Event,UnityEngine.Vector2&)
		void Register_UnityEngine_Event_INTERNAL_CALL_Internal_SetMouseDelta();
		Register_UnityEngine_Event_INTERNAL_CALL_Internal_SetMouseDelta();

		//System.Void UnityEngine.Event::INTERNAL_CALL_Internal_SetMousePosition(UnityEngine.Event,UnityEngine.Vector2&)
		void Register_UnityEngine_Event_INTERNAL_CALL_Internal_SetMousePosition();
		Register_UnityEngine_Event_INTERNAL_CALL_Internal_SetMousePosition();

		//System.Void UnityEngine.Event::Init(System.Int32)
		void Register_UnityEngine_Event_Init();
		Register_UnityEngine_Event_Init();

		//System.Void UnityEngine.Event::InitCopy(UnityEngine.Event)
		void Register_UnityEngine_Event_InitCopy();
		Register_UnityEngine_Event_InitCopy();

		//System.Void UnityEngine.Event::InitPtr(System.IntPtr)
		void Register_UnityEngine_Event_InitPtr();
		Register_UnityEngine_Event_InitPtr();

		//System.Void UnityEngine.Event::Internal_GetMouseDelta(UnityEngine.Vector2&)
		void Register_UnityEngine_Event_Internal_GetMouseDelta();
		Register_UnityEngine_Event_Internal_GetMouseDelta();

		//System.Void UnityEngine.Event::Internal_GetMousePosition(UnityEngine.Vector2&)
		void Register_UnityEngine_Event_Internal_GetMousePosition();
		Register_UnityEngine_Event_Internal_GetMousePosition();

		//System.Void UnityEngine.Event::Internal_SetNativeEvent(System.IntPtr)
		void Register_UnityEngine_Event_Internal_SetNativeEvent();
		Register_UnityEngine_Event_Internal_SetNativeEvent();

		//System.Void UnityEngine.Event::Internal_Use()
		void Register_UnityEngine_Event_Internal_Use();
		Register_UnityEngine_Event_Internal_Use();

		//System.Void UnityEngine.Event::set_button(System.Int32)
		void Register_UnityEngine_Event_set_button();
		Register_UnityEngine_Event_set_button();

		//System.Void UnityEngine.Event::set_character(System.Char)
		void Register_UnityEngine_Event_set_character();
		Register_UnityEngine_Event_set_character();

		//System.Void UnityEngine.Event::set_clickCount(System.Int32)
		void Register_UnityEngine_Event_set_clickCount();
		Register_UnityEngine_Event_set_clickCount();

		//System.Void UnityEngine.Event::set_commandName(System.String)
		void Register_UnityEngine_Event_set_commandName();
		Register_UnityEngine_Event_set_commandName();

		//System.Void UnityEngine.Event::set_displayIndex(System.Int32)
		void Register_UnityEngine_Event_set_displayIndex();
		Register_UnityEngine_Event_set_displayIndex();

		//System.Void UnityEngine.Event::set_keyCode(UnityEngine.KeyCode)
		void Register_UnityEngine_Event_set_keyCode();
		Register_UnityEngine_Event_set_keyCode();

		//System.Void UnityEngine.Event::set_modifiers(UnityEngine.EventModifiers)
		void Register_UnityEngine_Event_set_modifiers();
		Register_UnityEngine_Event_set_modifiers();

		//System.Void UnityEngine.Event::set_pressure(System.Single)
		void Register_UnityEngine_Event_set_pressure();
		Register_UnityEngine_Event_set_pressure();

		//System.Void UnityEngine.Event::set_type(UnityEngine.EventType)
		void Register_UnityEngine_Event_set_type();
		Register_UnityEngine_Event_set_type();

		//UnityEngine.EventModifiers UnityEngine.Event::get_modifiers()
		void Register_UnityEngine_Event_get_modifiers();
		Register_UnityEngine_Event_get_modifiers();

		//UnityEngine.EventType UnityEngine.Event::GetTypeForControl(System.Int32)
		void Register_UnityEngine_Event_GetTypeForControl();
		Register_UnityEngine_Event_GetTypeForControl();

		//UnityEngine.EventType UnityEngine.Event::get_rawType()
		void Register_UnityEngine_Event_get_rawType();
		Register_UnityEngine_Event_get_rawType();

		//UnityEngine.EventType UnityEngine.Event::get_type()
		void Register_UnityEngine_Event_get_type();
		Register_UnityEngine_Event_get_type();

		//UnityEngine.KeyCode UnityEngine.Event::get_keyCode()
		void Register_UnityEngine_Event_get_keyCode();
		Register_UnityEngine_Event_get_keyCode();

	//End Registrations for type : UnityEngine.Event

	//Start Registrations for type : UnityEngine.Experimental.Director.GenericMixerPlayable

		//System.Void UnityEngine.Experimental.Director.GenericMixerPlayable::InternalCreate(UnityEngine.Experimental.Director.GenericMixerPlayable&)
		void Register_UnityEngine_Experimental_Director_GenericMixerPlayable_InternalCreate();
		Register_UnityEngine_Experimental_Director_GenericMixerPlayable_InternalCreate();

	//End Registrations for type : UnityEngine.Experimental.Director.GenericMixerPlayable

	//Start Registrations for type : UnityEngine.Experimental.Director.Playable

		//System.Boolean UnityEngine.Experimental.Director.Playable::INTERNAL_CALL_CanChangeInputsInternal(UnityEngine.Experimental.Director.Playable&)
		void Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_CanChangeInputsInternal();
		Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_CanChangeInputsInternal();

		//System.Boolean UnityEngine.Experimental.Director.Playable::INTERNAL_CALL_CanDestroyInternal(UnityEngine.Experimental.Director.Playable&)
		void Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_CanDestroyInternal();
		Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_CanDestroyInternal();

		//System.Boolean UnityEngine.Experimental.Director.Playable::INTERNAL_CALL_CanSetWeightsInternal(UnityEngine.Experimental.Director.Playable&)
		void Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_CanSetWeightsInternal();
		Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_CanSetWeightsInternal();

		//System.Boolean UnityEngine.Experimental.Director.Playable::INTERNAL_CALL_IsValidInternal(UnityEngine.Experimental.Director.Playable&)
		void Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_IsValidInternal();
		Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_IsValidInternal();

		//System.Double UnityEngine.Experimental.Director.Playable::INTERNAL_CALL_GetDurationInternal(UnityEngine.Experimental.Director.Playable&)
		void Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_GetDurationInternal();
		Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_GetDurationInternal();

		//System.Double UnityEngine.Experimental.Director.Playable::INTERNAL_CALL_GetTimeInternal(UnityEngine.Experimental.Director.Playable&)
		void Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_GetTimeInternal();
		Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_GetTimeInternal();

		//System.Int32 UnityEngine.Experimental.Director.Playable::INTERNAL_CALL_GetInputCountInternal(UnityEngine.Experimental.Director.Playable&)
		void Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_GetInputCountInternal();
		Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_GetInputCountInternal();

		//System.Int32 UnityEngine.Experimental.Director.Playable::INTERNAL_CALL_GetOutputCountInternal(UnityEngine.Experimental.Director.Playable&)
		void Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_GetOutputCountInternal();
		Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_GetOutputCountInternal();

		//System.Object UnityEngine.Experimental.Director.Playable::InternalCreate(System.Type)
		void Register_UnityEngine_Experimental_Director_Playable_InternalCreate();
		Register_UnityEngine_Experimental_Director_Playable_InternalCreate();

		//System.Single UnityEngine.Experimental.Director.Playable::INTERNAL_CALL_GetInputWeightInternal(UnityEngine.Experimental.Director.Playable&,System.Int32)
		void Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_GetInputWeightInternal();
		Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_GetInputWeightInternal();

		//System.Void UnityEngine.Experimental.Director.Playable::INTERNAL_CALL_GetInputInternal(UnityEngine.Experimental.Director.Playable&,System.Int32,UnityEngine.Experimental.Director.Playable&)
		void Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_GetInputInternal();
		Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_GetInputInternal();

		//System.Void UnityEngine.Experimental.Director.Playable::INTERNAL_CALL_GetOutputInternal(UnityEngine.Experimental.Director.Playable&,System.Int32,UnityEngine.Experimental.Director.Playable&)
		void Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_GetOutputInternal();
		Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_GetOutputInternal();

		//System.Void UnityEngine.Experimental.Director.Playable::INTERNAL_CALL_SetDurationInternal(UnityEngine.Experimental.Director.Playable&,System.Double)
		void Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_SetDurationInternal();
		Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_SetDurationInternal();

		//System.Void UnityEngine.Experimental.Director.Playable::INTERNAL_CALL_SetInputWeightFromIndexInternal(UnityEngine.Experimental.Director.Playable&,System.Int32,System.Single)
		void Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_SetInputWeightFromIndexInternal();
		Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_SetInputWeightFromIndexInternal();

		//System.Void UnityEngine.Experimental.Director.Playable::INTERNAL_CALL_SetInputWeightInternal(UnityEngine.Experimental.Director.Playable&,UnityEngine.Experimental.Director.Playable&,System.Single)
		void Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_SetInputWeightInternal();
		Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_SetInputWeightInternal();

		//System.Void UnityEngine.Experimental.Director.Playable::INTERNAL_CALL_SetPlayStateInternal(UnityEngine.Experimental.Director.Playable&,UnityEngine.Experimental.Director.PlayState)
		void Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_SetPlayStateInternal();
		Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_SetPlayStateInternal();

		//System.Void UnityEngine.Experimental.Director.Playable::INTERNAL_CALL_SetTimeInternal(UnityEngine.Experimental.Director.Playable&,System.Double)
		void Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_SetTimeInternal();
		Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_SetTimeInternal();

		//UnityEngine.Experimental.Director.PlayState UnityEngine.Experimental.Director.Playable::INTERNAL_CALL_GetPlayStateInternal(UnityEngine.Experimental.Director.Playable&)
		void Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_GetPlayStateInternal();
		Register_UnityEngine_Experimental_Director_Playable_INTERNAL_CALL_GetPlayStateInternal();

	//End Registrations for type : UnityEngine.Experimental.Director.Playable

	//Start Registrations for type : UnityEngine.Experimental.Director.Playables

		//System.Boolean UnityEngine.Experimental.Director.Playables::INTERNAL_CALL_ConnectInternal(UnityEngine.Experimental.Director.Playable&,UnityEngine.Experimental.Director.Playable&,System.Int32,System.Int32)
		void Register_UnityEngine_Experimental_Director_Playables_INTERNAL_CALL_ConnectInternal();
		Register_UnityEngine_Experimental_Director_Playables_INTERNAL_CALL_ConnectInternal();

		//System.Object UnityEngine.Experimental.Director.Playables::CastToInternal(System.Type,System.IntPtr,System.Int32)
		void Register_UnityEngine_Experimental_Director_Playables_CastToInternal();
		Register_UnityEngine_Experimental_Director_Playables_CastToInternal();

		//System.Type UnityEngine.Experimental.Director.Playables::GetTypeOfInternal(System.IntPtr,System.Int32)
		void Register_UnityEngine_Experimental_Director_Playables_GetTypeOfInternal();
		Register_UnityEngine_Experimental_Director_Playables_GetTypeOfInternal();

		//System.Void UnityEngine.Experimental.Director.Playables::INTERNAL_CALL_DisconnectInternal(UnityEngine.Experimental.Director.Playable&,System.Int32)
		void Register_UnityEngine_Experimental_Director_Playables_INTERNAL_CALL_DisconnectInternal();
		Register_UnityEngine_Experimental_Director_Playables_INTERNAL_CALL_DisconnectInternal();

		//System.Void UnityEngine.Experimental.Director.Playables::INTERNAL_CALL_InternalDestroy(UnityEngine.Experimental.Director.Playable&)
		void Register_UnityEngine_Experimental_Director_Playables_INTERNAL_CALL_InternalDestroy();
		Register_UnityEngine_Experimental_Director_Playables_INTERNAL_CALL_InternalDestroy();

	//End Registrations for type : UnityEngine.Experimental.Director.Playables

	//Start Registrations for type : UnityEngine.Font

		//System.Boolean UnityEngine.Font::GetCharacterInfo(System.Char,UnityEngine.CharacterInfo&,System.Int32,UnityEngine.FontStyle)
		void Register_UnityEngine_Font_GetCharacterInfo();
		Register_UnityEngine_Font_GetCharacterInfo();

		//System.Boolean UnityEngine.Font::HasCharacter(System.Char)
		void Register_UnityEngine_Font_HasCharacter();
		Register_UnityEngine_Font_HasCharacter();

		//System.Boolean UnityEngine.Font::get_dynamic()
		void Register_UnityEngine_Font_get_dynamic();
		Register_UnityEngine_Font_get_dynamic();

		//System.Int32 UnityEngine.Font::get_ascent()
		void Register_UnityEngine_Font_get_ascent();
		Register_UnityEngine_Font_get_ascent();

		//System.Int32 UnityEngine.Font::get_fontSize()
		void Register_UnityEngine_Font_get_fontSize();
		Register_UnityEngine_Font_get_fontSize();

		//System.Int32 UnityEngine.Font::get_lineHeight()
		void Register_UnityEngine_Font_get_lineHeight();
		Register_UnityEngine_Font_get_lineHeight();

		//System.String[] UnityEngine.Font::GetOSInstalledFontNames()
		void Register_UnityEngine_Font_GetOSInstalledFontNames();
		Register_UnityEngine_Font_GetOSInstalledFontNames();

		//System.String[] UnityEngine.Font::get_fontNames()
		void Register_UnityEngine_Font_get_fontNames();
		Register_UnityEngine_Font_get_fontNames();

		//System.Void UnityEngine.Font::Internal_CreateDynamicFont(UnityEngine.Font,System.String[],System.Int32)
		void Register_UnityEngine_Font_Internal_CreateDynamicFont();
		Register_UnityEngine_Font_Internal_CreateDynamicFont();

		//System.Void UnityEngine.Font::Internal_CreateFont(UnityEngine.Font,System.String)
		void Register_UnityEngine_Font_Internal_CreateFont();
		Register_UnityEngine_Font_Internal_CreateFont();

		//System.Void UnityEngine.Font::RequestCharactersInTexture(System.String,System.Int32,UnityEngine.FontStyle)
		void Register_UnityEngine_Font_RequestCharactersInTexture();
		Register_UnityEngine_Font_RequestCharactersInTexture();

		//System.Void UnityEngine.Font::set_characterInfo(UnityEngine.CharacterInfo[])
		void Register_UnityEngine_Font_set_characterInfo();
		Register_UnityEngine_Font_set_characterInfo();

		//System.Void UnityEngine.Font::set_fontNames(System.String[])
		void Register_UnityEngine_Font_set_fontNames();
		Register_UnityEngine_Font_set_fontNames();

		//System.Void UnityEngine.Font::set_material(UnityEngine.Material)
		void Register_UnityEngine_Font_set_material();
		Register_UnityEngine_Font_set_material();

		//UnityEngine.CharacterInfo[] UnityEngine.Font::get_characterInfo()
		void Register_UnityEngine_Font_get_characterInfo();
		Register_UnityEngine_Font_get_characterInfo();

		//UnityEngine.Material UnityEngine.Font::get_material()
		void Register_UnityEngine_Font_get_material();
		Register_UnityEngine_Font_get_material();

	//End Registrations for type : UnityEngine.Font

	//Start Registrations for type : UnityEngine.GameObject

		//System.Array UnityEngine.GameObject::GetComponentsInternal(System.Type,System.Boolean,System.Boolean,System.Boolean,System.Boolean,System.Object)
		void Register_UnityEngine_GameObject_GetComponentsInternal();
		Register_UnityEngine_GameObject_GetComponentsInternal();

		//System.Boolean UnityEngine.GameObject::CompareTag(System.String)
		void Register_UnityEngine_GameObject_CompareTag();
		Register_UnityEngine_GameObject_CompareTag();

		//System.Boolean UnityEngine.GameObject::get_active()
		void Register_UnityEngine_GameObject_get_active();
		Register_UnityEngine_GameObject_get_active();

		//System.Boolean UnityEngine.GameObject::get_activeInHierarchy()
		void Register_UnityEngine_GameObject_get_activeInHierarchy();
		Register_UnityEngine_GameObject_get_activeInHierarchy();

		//System.Boolean UnityEngine.GameObject::get_activeSelf()
		void Register_UnityEngine_GameObject_get_activeSelf();
		Register_UnityEngine_GameObject_get_activeSelf();

		//System.Boolean UnityEngine.GameObject::get_isStatic()
		void Register_UnityEngine_GameObject_get_isStatic();
		Register_UnityEngine_GameObject_get_isStatic();

		//System.Boolean UnityEngine.GameObject::get_isStaticBatchable()
		void Register_UnityEngine_GameObject_get_isStaticBatchable();
		Register_UnityEngine_GameObject_get_isStaticBatchable();

		//System.Int32 UnityEngine.GameObject::get_layer()
		void Register_UnityEngine_GameObject_get_layer();
		Register_UnityEngine_GameObject_get_layer();

		//System.String UnityEngine.GameObject::get_tag()
		void Register_UnityEngine_GameObject_get_tag();
		Register_UnityEngine_GameObject_get_tag();

		//System.Void UnityEngine.GameObject::BroadcastMessage(System.String,System.Object,UnityEngine.SendMessageOptions)
		void Register_UnityEngine_GameObject_BroadcastMessage();
		Register_UnityEngine_GameObject_BroadcastMessage();

		//System.Void UnityEngine.GameObject::GetComponentFastPath(System.Type,System.IntPtr)
		void Register_UnityEngine_GameObject_GetComponentFastPath();
		Register_UnityEngine_GameObject_GetComponentFastPath();

		//System.Void UnityEngine.GameObject::INTERNAL_get_scene(UnityEngine.SceneManagement.Scene&)
		void Register_UnityEngine_GameObject_INTERNAL_get_scene();
		Register_UnityEngine_GameObject_INTERNAL_get_scene();

		//System.Void UnityEngine.GameObject::Internal_CreateGameObject(UnityEngine.GameObject,System.String)
		void Register_UnityEngine_GameObject_Internal_CreateGameObject();
		Register_UnityEngine_GameObject_Internal_CreateGameObject();

		//System.Void UnityEngine.GameObject::SendMessage(System.String,System.Object,UnityEngine.SendMessageOptions)
		void Register_UnityEngine_GameObject_SendMessage();
		Register_UnityEngine_GameObject_SendMessage();

		//System.Void UnityEngine.GameObject::SendMessageUpwards(System.String,System.Object,UnityEngine.SendMessageOptions)
		void Register_UnityEngine_GameObject_SendMessageUpwards();
		Register_UnityEngine_GameObject_SendMessageUpwards();

		//System.Void UnityEngine.GameObject::SetActive(System.Boolean)
		void Register_UnityEngine_GameObject_SetActive();
		Register_UnityEngine_GameObject_SetActive();

		//System.Void UnityEngine.GameObject::SetActiveRecursively(System.Boolean)
		void Register_UnityEngine_GameObject_SetActiveRecursively();
		Register_UnityEngine_GameObject_SetActiveRecursively();

		//System.Void UnityEngine.GameObject::set_active(System.Boolean)
		void Register_UnityEngine_GameObject_set_active();
		Register_UnityEngine_GameObject_set_active();

		//System.Void UnityEngine.GameObject::set_isStatic(System.Boolean)
		void Register_UnityEngine_GameObject_set_isStatic();
		Register_UnityEngine_GameObject_set_isStatic();

		//System.Void UnityEngine.GameObject::set_layer(System.Int32)
		void Register_UnityEngine_GameObject_set_layer();
		Register_UnityEngine_GameObject_set_layer();

		//System.Void UnityEngine.GameObject::set_tag(System.String)
		void Register_UnityEngine_GameObject_set_tag();
		Register_UnityEngine_GameObject_set_tag();

		//UnityEngine.Component UnityEngine.GameObject::AddComponentInternal(System.String)
		void Register_UnityEngine_GameObject_AddComponentInternal();
		Register_UnityEngine_GameObject_AddComponentInternal();

		//UnityEngine.Component UnityEngine.GameObject::GetComponent(System.Type)
		void Register_UnityEngine_GameObject_GetComponent();
		Register_UnityEngine_GameObject_GetComponent();

		//UnityEngine.Component UnityEngine.GameObject::GetComponentByName(System.String)
		void Register_UnityEngine_GameObject_GetComponentByName();
		Register_UnityEngine_GameObject_GetComponentByName();

		//UnityEngine.Component UnityEngine.GameObject::GetComponentInChildren(System.Type,System.Boolean)
		void Register_UnityEngine_GameObject_GetComponentInChildren();
		Register_UnityEngine_GameObject_GetComponentInChildren();

		//UnityEngine.Component UnityEngine.GameObject::GetComponentInParent(System.Type)
		void Register_UnityEngine_GameObject_GetComponentInParent();
		Register_UnityEngine_GameObject_GetComponentInParent();

		//UnityEngine.Component UnityEngine.GameObject::Internal_AddComponentWithType(System.Type)
		void Register_UnityEngine_GameObject_Internal_AddComponentWithType();
		Register_UnityEngine_GameObject_Internal_AddComponentWithType();

		//UnityEngine.GameObject UnityEngine.GameObject::CreatePrimitive(UnityEngine.PrimitiveType)
		void Register_UnityEngine_GameObject_CreatePrimitive();
		Register_UnityEngine_GameObject_CreatePrimitive();

		//UnityEngine.GameObject UnityEngine.GameObject::Find(System.String)
		void Register_UnityEngine_GameObject_Find();
		Register_UnityEngine_GameObject_Find();

		//UnityEngine.GameObject UnityEngine.GameObject::FindGameObjectWithTag(System.String)
		void Register_UnityEngine_GameObject_FindGameObjectWithTag();
		Register_UnityEngine_GameObject_FindGameObjectWithTag();

		//UnityEngine.GameObject[] UnityEngine.GameObject::FindGameObjectsWithTag(System.String)
		void Register_UnityEngine_GameObject_FindGameObjectsWithTag();
		Register_UnityEngine_GameObject_FindGameObjectsWithTag();

		//UnityEngine.Transform UnityEngine.GameObject::get_transform()
		void Register_UnityEngine_GameObject_get_transform();
		Register_UnityEngine_GameObject_get_transform();

	//End Registrations for type : UnityEngine.GameObject

	//Start Registrations for type : UnityEngine.Gizmos

		//System.Void UnityEngine.Gizmos::INTERNAL_CALL_DrawLine(UnityEngine.Vector3&,UnityEngine.Vector3&)
		void Register_UnityEngine_Gizmos_INTERNAL_CALL_DrawLine();
		Register_UnityEngine_Gizmos_INTERNAL_CALL_DrawLine();

		//System.Void UnityEngine.Gizmos::INTERNAL_get_color(UnityEngine.Color&)
		void Register_UnityEngine_Gizmos_INTERNAL_get_color();
		Register_UnityEngine_Gizmos_INTERNAL_get_color();

		//System.Void UnityEngine.Gizmos::INTERNAL_set_color(UnityEngine.Color&)
		void Register_UnityEngine_Gizmos_INTERNAL_set_color();
		Register_UnityEngine_Gizmos_INTERNAL_set_color();

	//End Registrations for type : UnityEngine.Gizmos

	//Start Registrations for type : UnityEngine.GL

		//System.Void UnityEngine.GL::BeginInternal(System.Int32)
		void Register_UnityEngine_GL_BeginInternal();
		Register_UnityEngine_GL_BeginInternal();

		//System.Void UnityEngine.GL::End()
		void Register_UnityEngine_GL_End();
		Register_UnityEngine_GL_End();

		//System.Void UnityEngine.GL::INTERNAL_CALL_Color(UnityEngine.Color&)
		void Register_UnityEngine_GL_INTERNAL_CALL_Color();
		Register_UnityEngine_GL_INTERNAL_CALL_Color();

		//System.Void UnityEngine.GL::INTERNAL_CALL_Vertex(UnityEngine.Vector3&)
		void Register_UnityEngine_GL_INTERNAL_CALL_Vertex();
		Register_UnityEngine_GL_INTERNAL_CALL_Vertex();

		//System.Void UnityEngine.GL::LoadPixelMatrix()
		void Register_UnityEngine_GL_LoadPixelMatrix();
		Register_UnityEngine_GL_LoadPixelMatrix();

		//System.Void UnityEngine.GL::PopMatrix()
		void Register_UnityEngine_GL_PopMatrix();
		Register_UnityEngine_GL_PopMatrix();

		//System.Void UnityEngine.GL::PushMatrix()
		void Register_UnityEngine_GL_PushMatrix();
		Register_UnityEngine_GL_PushMatrix();

		//System.Void UnityEngine.GL::Vertex3(System.Single,System.Single,System.Single)
		void Register_UnityEngine_GL_Vertex3();
		Register_UnityEngine_GL_Vertex3();

	//End Registrations for type : UnityEngine.GL

	//Start Registrations for type : UnityEngine.Gradient

		//System.Void UnityEngine.Gradient::Cleanup()
		void Register_UnityEngine_Gradient_Cleanup();
		Register_UnityEngine_Gradient_Cleanup();

		//System.Void UnityEngine.Gradient::INTERNAL_CALL_Evaluate(UnityEngine.Gradient,System.Single,UnityEngine.Color&)
		void Register_UnityEngine_Gradient_INTERNAL_CALL_Evaluate();
		Register_UnityEngine_Gradient_INTERNAL_CALL_Evaluate();

		//System.Void UnityEngine.Gradient::Init()
		void Register_UnityEngine_Gradient_Init();
		Register_UnityEngine_Gradient_Init();

		//System.Void UnityEngine.Gradient::SetKeys(UnityEngine.GradientColorKey[],UnityEngine.GradientAlphaKey[])
		void Register_UnityEngine_Gradient_SetKeys();
		Register_UnityEngine_Gradient_SetKeys();

		//System.Void UnityEngine.Gradient::set_alphaKeys(UnityEngine.GradientAlphaKey[])
		void Register_UnityEngine_Gradient_set_alphaKeys();
		Register_UnityEngine_Gradient_set_alphaKeys();

		//System.Void UnityEngine.Gradient::set_colorKeys(UnityEngine.GradientColorKey[])
		void Register_UnityEngine_Gradient_set_colorKeys();
		Register_UnityEngine_Gradient_set_colorKeys();

		//System.Void UnityEngine.Gradient::set_mode(UnityEngine.GradientMode)
		void Register_UnityEngine_Gradient_set_mode();
		Register_UnityEngine_Gradient_set_mode();

		//UnityEngine.GradientAlphaKey[] UnityEngine.Gradient::get_alphaKeys()
		void Register_UnityEngine_Gradient_get_alphaKeys();
		Register_UnityEngine_Gradient_get_alphaKeys();

		//UnityEngine.GradientColorKey[] UnityEngine.Gradient::get_colorKeys()
		void Register_UnityEngine_Gradient_get_colorKeys();
		Register_UnityEngine_Gradient_get_colorKeys();

		//UnityEngine.GradientMode UnityEngine.Gradient::get_mode()
		void Register_UnityEngine_Gradient_get_mode();
		Register_UnityEngine_Gradient_get_mode();

	//End Registrations for type : UnityEngine.Gradient

	//Start Registrations for type : UnityEngine.Graphics

		//System.Int32 UnityEngine.Graphics::Internal_GetMaxDrawMeshInstanceCount()
		void Register_UnityEngine_Graphics_Internal_GetMaxDrawMeshInstanceCount();
		Register_UnityEngine_Graphics_Internal_GetMaxDrawMeshInstanceCount();

		//System.Void UnityEngine.Graphics::DrawTexture(UnityEngine.InternalDrawTextureArguments&)
		void Register_UnityEngine_Graphics_DrawTexture();
		Register_UnityEngine_Graphics_DrawTexture();

	//End Registrations for type : UnityEngine.Graphics

	//Start Registrations for type : UnityEngine.GUI

		//System.Boolean UnityEngine.GUI::INTERNAL_CALL_DoButton(UnityEngine.Rect&,UnityEngine.GUIContent,System.IntPtr)
		void Register_UnityEngine_GUI_INTERNAL_CALL_DoButton();
		Register_UnityEngine_GUI_INTERNAL_CALL_DoButton();

		//System.Boolean UnityEngine.GUI::INTERNAL_CALL_DoToggle(UnityEngine.Rect&,System.Int32,System.Boolean,UnityEngine.GUIContent,System.IntPtr)
		void Register_UnityEngine_GUI_INTERNAL_CALL_DoToggle();
		Register_UnityEngine_GUI_INTERNAL_CALL_DoToggle();

		//System.Boolean UnityEngine.GUI::get_changed()
		void Register_UnityEngine_GUI_get_changed();
		Register_UnityEngine_GUI_get_changed();

		//System.Boolean UnityEngine.GUI::get_enabled()
		void Register_UnityEngine_GUI_get_enabled();
		Register_UnityEngine_GUI_get_enabled();

		//System.Boolean UnityEngine.GUI::get_usePageScrollbars()
		void Register_UnityEngine_GUI_get_usePageScrollbars();
		Register_UnityEngine_GUI_get_usePageScrollbars();

		//System.Int32 UnityEngine.GUI::get_depth()
		void Register_UnityEngine_GUI_get_depth();
		Register_UnityEngine_GUI_get_depth();

		//System.String UnityEngine.GUI::GetNameOfFocusedControl()
		void Register_UnityEngine_GUI_GetNameOfFocusedControl();
		Register_UnityEngine_GUI_GetNameOfFocusedControl();

		//System.String UnityEngine.GUI::Internal_GetMouseTooltip()
		void Register_UnityEngine_GUI_Internal_GetMouseTooltip();
		Register_UnityEngine_GUI_Internal_GetMouseTooltip();

		//System.String UnityEngine.GUI::Internal_GetTooltip()
		void Register_UnityEngine_GUI_Internal_GetTooltip();
		Register_UnityEngine_GUI_Internal_GetTooltip();

		//System.Void UnityEngine.GUI::BringWindowToBack(System.Int32)
		void Register_UnityEngine_GUI_BringWindowToBack();
		Register_UnityEngine_GUI_BringWindowToBack();

		//System.Void UnityEngine.GUI::BringWindowToFront(System.Int32)
		void Register_UnityEngine_GUI_BringWindowToFront();
		Register_UnityEngine_GUI_BringWindowToFront();

		//System.Void UnityEngine.GUI::FocusControl(System.String)
		void Register_UnityEngine_GUI_FocusControl();
		Register_UnityEngine_GUI_FocusControl();

		//System.Void UnityEngine.GUI::FocusWindow(System.Int32)
		void Register_UnityEngine_GUI_FocusWindow();
		Register_UnityEngine_GUI_FocusWindow();

		//System.Void UnityEngine.GUI::INTERNAL_CALL_DoLabel(UnityEngine.Rect&,UnityEngine.GUIContent,System.IntPtr)
		void Register_UnityEngine_GUI_INTERNAL_CALL_DoLabel();
		Register_UnityEngine_GUI_INTERNAL_CALL_DoLabel();

		//System.Void UnityEngine.GUI::INTERNAL_CALL_DoModalWindow(System.Int32,UnityEngine.Rect&,UnityEngine.GUI/WindowFunction,UnityEngine.GUIContent,UnityEngine.GUIStyle,UnityEngine.GUISkin,UnityEngine.Rect&)
		void Register_UnityEngine_GUI_INTERNAL_CALL_DoModalWindow();
		Register_UnityEngine_GUI_INTERNAL_CALL_DoModalWindow();

		//System.Void UnityEngine.GUI::INTERNAL_CALL_DoWindow(System.Int32,UnityEngine.Rect&,UnityEngine.GUI/WindowFunction,UnityEngine.GUIContent,UnityEngine.GUIStyle,UnityEngine.GUISkin,System.Boolean,UnityEngine.Rect&)
		void Register_UnityEngine_GUI_INTERNAL_CALL_DoWindow();
		Register_UnityEngine_GUI_INTERNAL_CALL_DoWindow();

		//System.Void UnityEngine.GUI::INTERNAL_CALL_DragWindow(UnityEngine.Rect&)
		void Register_UnityEngine_GUI_INTERNAL_CALL_DragWindow();
		Register_UnityEngine_GUI_INTERNAL_CALL_DragWindow();

		//System.Void UnityEngine.GUI::INTERNAL_get_backgroundColor(UnityEngine.Color&)
		void Register_UnityEngine_GUI_INTERNAL_get_backgroundColor();
		Register_UnityEngine_GUI_INTERNAL_get_backgroundColor();

		//System.Void UnityEngine.GUI::INTERNAL_get_color(UnityEngine.Color&)
		void Register_UnityEngine_GUI_INTERNAL_get_color();
		Register_UnityEngine_GUI_INTERNAL_get_color();

		//System.Void UnityEngine.GUI::INTERNAL_get_contentColor(UnityEngine.Color&)
		void Register_UnityEngine_GUI_INTERNAL_get_contentColor();
		Register_UnityEngine_GUI_INTERNAL_get_contentColor();

		//System.Void UnityEngine.GUI::INTERNAL_set_backgroundColor(UnityEngine.Color&)
		void Register_UnityEngine_GUI_INTERNAL_set_backgroundColor();
		Register_UnityEngine_GUI_INTERNAL_set_backgroundColor();

		//System.Void UnityEngine.GUI::INTERNAL_set_color(UnityEngine.Color&)
		void Register_UnityEngine_GUI_INTERNAL_set_color();
		Register_UnityEngine_GUI_INTERNAL_set_color();

		//System.Void UnityEngine.GUI::INTERNAL_set_contentColor(UnityEngine.Color&)
		void Register_UnityEngine_GUI_INTERNAL_set_contentColor();
		Register_UnityEngine_GUI_INTERNAL_set_contentColor();

		//System.Void UnityEngine.GUI::InitializeGUIClipTexture()
		void Register_UnityEngine_GUI_InitializeGUIClipTexture();
		Register_UnityEngine_GUI_InitializeGUIClipTexture();

		//System.Void UnityEngine.GUI::InternalRepaintEditorWindow()
		void Register_UnityEngine_GUI_InternalRepaintEditorWindow();
		Register_UnityEngine_GUI_InternalRepaintEditorWindow();

		//System.Void UnityEngine.GUI::Internal_BeginWindows()
		void Register_UnityEngine_GUI_Internal_BeginWindows();
		Register_UnityEngine_GUI_Internal_BeginWindows();

		//System.Void UnityEngine.GUI::Internal_EndWindows()
		void Register_UnityEngine_GUI_Internal_EndWindows();
		Register_UnityEngine_GUI_Internal_EndWindows();

		//System.Void UnityEngine.GUI::Internal_SetTooltip(System.String)
		void Register_UnityEngine_GUI_Internal_SetTooltip();
		Register_UnityEngine_GUI_Internal_SetTooltip();

		//System.Void UnityEngine.GUI::SetNextControlName(System.String)
		void Register_UnityEngine_GUI_SetNextControlName();
		Register_UnityEngine_GUI_SetNextControlName();

		//System.Void UnityEngine.GUI::UnfocusWindow()
		void Register_UnityEngine_GUI_UnfocusWindow();
		Register_UnityEngine_GUI_UnfocusWindow();

		//System.Void UnityEngine.GUI::set_changed(System.Boolean)
		void Register_UnityEngine_GUI_set_changed();
		Register_UnityEngine_GUI_set_changed();

		//System.Void UnityEngine.GUI::set_depth(System.Int32)
		void Register_UnityEngine_GUI_set_depth();
		Register_UnityEngine_GUI_set_depth();

		//System.Void UnityEngine.GUI::set_enabled(System.Boolean)
		void Register_UnityEngine_GUI_set_enabled();
		Register_UnityEngine_GUI_set_enabled();

		//UnityEngine.Material UnityEngine.GUI::get_blendMaterial()
		void Register_UnityEngine_GUI_get_blendMaterial();
		Register_UnityEngine_GUI_get_blendMaterial();

		//UnityEngine.Material UnityEngine.GUI::get_blitMaterial()
		void Register_UnityEngine_GUI_get_blitMaterial();
		Register_UnityEngine_GUI_get_blitMaterial();

	//End Registrations for type : UnityEngine.GUI

	//Start Registrations for type : UnityEngine.GUIClip

		//System.Void UnityEngine.GUIClip::INTERNAL_CALL_Clip_Vector2(UnityEngine.Vector2&)
		void Register_UnityEngine_GUIClip_INTERNAL_CALL_Clip_Vector2();
		Register_UnityEngine_GUIClip_INTERNAL_CALL_Clip_Vector2();

		//System.Void UnityEngine.GUIClip::INTERNAL_CALL_GetMatrix(UnityEngine.Matrix4x4&)
		void Register_UnityEngine_GUIClip_INTERNAL_CALL_GetMatrix();
		Register_UnityEngine_GUIClip_INTERNAL_CALL_GetMatrix();

		//System.Void UnityEngine.GUIClip::INTERNAL_CALL_Push(UnityEngine.Rect&,UnityEngine.Vector2&,UnityEngine.Vector2&,System.Boolean)
		void Register_UnityEngine_GUIClip_INTERNAL_CALL_Push();
		Register_UnityEngine_GUIClip_INTERNAL_CALL_Push();

		//System.Void UnityEngine.GUIClip::INTERNAL_CALL_SetMatrix(UnityEngine.Matrix4x4&)
		void Register_UnityEngine_GUIClip_INTERNAL_CALL_SetMatrix();
		Register_UnityEngine_GUIClip_INTERNAL_CALL_SetMatrix();

		//System.Void UnityEngine.GUIClip::INTERNAL_CALL_Unclip_Vector2(UnityEngine.Vector2&)
		void Register_UnityEngine_GUIClip_INTERNAL_CALL_Unclip_Vector2();
		Register_UnityEngine_GUIClip_INTERNAL_CALL_Unclip_Vector2();

		//System.Void UnityEngine.GUIClip::Pop()
		void Register_UnityEngine_GUIClip_Pop();
		Register_UnityEngine_GUIClip_Pop();

	//End Registrations for type : UnityEngine.GUIClip

	//Start Registrations for type : UnityEngine.GUILayer

		//UnityEngine.GUIElement UnityEngine.GUILayer::INTERNAL_CALL_HitTest(UnityEngine.GUILayer,UnityEngine.Vector3&)
		void Register_UnityEngine_GUILayer_INTERNAL_CALL_HitTest();
		Register_UnityEngine_GUILayer_INTERNAL_CALL_HitTest();

	//End Registrations for type : UnityEngine.GUILayer

	//Start Registrations for type : UnityEngine.GUILayoutUtility

		//System.Void UnityEngine.GUILayoutUtility::INTERNAL_CALL_Internal_GetWindowRect(System.Int32,UnityEngine.Rect&)
		void Register_UnityEngine_GUILayoutUtility_INTERNAL_CALL_Internal_GetWindowRect();
		Register_UnityEngine_GUILayoutUtility_INTERNAL_CALL_Internal_GetWindowRect();

		//System.Void UnityEngine.GUILayoutUtility::INTERNAL_CALL_Internal_MoveWindow(System.Int32,UnityEngine.Rect&)
		void Register_UnityEngine_GUILayoutUtility_INTERNAL_CALL_Internal_MoveWindow();
		Register_UnityEngine_GUILayoutUtility_INTERNAL_CALL_Internal_MoveWindow();

	//End Registrations for type : UnityEngine.GUILayoutUtility

	//Start Registrations for type : UnityEngine.GUISettings

		//System.Single UnityEngine.GUISettings::Internal_GetCursorFlashSpeed()
		void Register_UnityEngine_GUISettings_Internal_GetCursorFlashSpeed();
		Register_UnityEngine_GUISettings_Internal_GetCursorFlashSpeed();

	//End Registrations for type : UnityEngine.GUISettings

	//Start Registrations for type : UnityEngine.GUIStyle

		//System.Boolean UnityEngine.GUIStyle::get_richText()
		void Register_UnityEngine_GUIStyle_get_richText();
		Register_UnityEngine_GUIStyle_get_richText();

		//System.Boolean UnityEngine.GUIStyle::get_stretchHeight()
		void Register_UnityEngine_GUIStyle_get_stretchHeight();
		Register_UnityEngine_GUIStyle_get_stretchHeight();

		//System.Boolean UnityEngine.GUIStyle::get_stretchWidth()
		void Register_UnityEngine_GUIStyle_get_stretchWidth();
		Register_UnityEngine_GUIStyle_get_stretchWidth();

		//System.Boolean UnityEngine.GUIStyle::get_wordWrap()
		void Register_UnityEngine_GUIStyle_get_wordWrap();
		Register_UnityEngine_GUIStyle_get_wordWrap();

		//System.Int32 UnityEngine.GUIStyle::INTERNAL_CALL_Internal_GetCursorStringIndex(System.IntPtr,UnityEngine.Rect&,UnityEngine.GUIContent,UnityEngine.Vector2&)
		void Register_UnityEngine_GUIStyle_INTERNAL_CALL_Internal_GetCursorStringIndex();
		Register_UnityEngine_GUIStyle_INTERNAL_CALL_Internal_GetCursorStringIndex();

		//System.Int32 UnityEngine.GUIStyle::Internal_GetNumCharactersThatFitWithinWidth(System.IntPtr,System.String,System.Single)
		void Register_UnityEngine_GUIStyle_Internal_GetNumCharactersThatFitWithinWidth();
		Register_UnityEngine_GUIStyle_Internal_GetNumCharactersThatFitWithinWidth();

		//System.Int32 UnityEngine.GUIStyle::get_fontSize()
		void Register_UnityEngine_GUIStyle_get_fontSize();
		Register_UnityEngine_GUIStyle_get_fontSize();

		//System.Single UnityEngine.GUIStyle::Internal_CalcHeight(System.IntPtr,UnityEngine.GUIContent,System.Single)
		void Register_UnityEngine_GUIStyle_Internal_CalcHeight();
		Register_UnityEngine_GUIStyle_Internal_CalcHeight();

		//System.Single UnityEngine.GUIStyle::Internal_GetCursorFlashOffset()
		void Register_UnityEngine_GUIStyle_Internal_GetCursorFlashOffset();
		Register_UnityEngine_GUIStyle_Internal_GetCursorFlashOffset();

		//System.Single UnityEngine.GUIStyle::Internal_GetLineHeight(System.IntPtr)
		void Register_UnityEngine_GUIStyle_Internal_GetLineHeight();
		Register_UnityEngine_GUIStyle_Internal_GetLineHeight();

		//System.Single UnityEngine.GUIStyle::get_fixedHeight()
		void Register_UnityEngine_GUIStyle_get_fixedHeight();
		Register_UnityEngine_GUIStyle_get_fixedHeight();

		//System.Single UnityEngine.GUIStyle::get_fixedWidth()
		void Register_UnityEngine_GUIStyle_get_fixedWidth();
		Register_UnityEngine_GUIStyle_get_fixedWidth();

		//System.String UnityEngine.GUIStyle::get_name()
		void Register_UnityEngine_GUIStyle_get_name();
		Register_UnityEngine_GUIStyle_get_name();

		//System.Void UnityEngine.GUIStyle::AssignRectOffset(System.Int32,System.IntPtr)
		void Register_UnityEngine_GUIStyle_AssignRectOffset();
		Register_UnityEngine_GUIStyle_AssignRectOffset();

		//System.Void UnityEngine.GUIStyle::AssignStyleState(System.Int32,System.IntPtr)
		void Register_UnityEngine_GUIStyle_AssignStyleState();
		Register_UnityEngine_GUIStyle_AssignStyleState();

		//System.Void UnityEngine.GUIStyle::Cleanup()
		void Register_UnityEngine_GUIStyle_Cleanup();
		Register_UnityEngine_GUIStyle_Cleanup();

		//System.Void UnityEngine.GUIStyle::INTERNAL_CALL_GetRectOffsetPtr(UnityEngine.GUIStyle,System.Int32,System.IntPtr&)
		void Register_UnityEngine_GUIStyle_INTERNAL_CALL_GetRectOffsetPtr();
		Register_UnityEngine_GUIStyle_INTERNAL_CALL_GetRectOffsetPtr();

		//System.Void UnityEngine.GUIStyle::INTERNAL_CALL_GetStyleStatePtr(UnityEngine.GUIStyle,System.Int32,System.IntPtr&)
		void Register_UnityEngine_GUIStyle_INTERNAL_CALL_GetStyleStatePtr();
		Register_UnityEngine_GUIStyle_INTERNAL_CALL_GetStyleStatePtr();

		//System.Void UnityEngine.GUIStyle::INTERNAL_CALL_Internal_CalcSizeWithConstraints(System.IntPtr,UnityEngine.GUIContent,UnityEngine.Vector2&,UnityEngine.Vector2&)
		void Register_UnityEngine_GUIStyle_INTERNAL_CALL_Internal_CalcSizeWithConstraints();
		Register_UnityEngine_GUIStyle_INTERNAL_CALL_Internal_CalcSizeWithConstraints();

		//System.Void UnityEngine.GUIStyle::INTERNAL_CALL_Internal_Draw2(System.IntPtr,UnityEngine.Rect&,UnityEngine.GUIContent,System.Int32,System.Boolean)
		void Register_UnityEngine_GUIStyle_INTERNAL_CALL_Internal_Draw2();
		Register_UnityEngine_GUIStyle_INTERNAL_CALL_Internal_Draw2();

		//System.Void UnityEngine.GUIStyle::INTERNAL_CALL_Internal_DrawCursor(System.IntPtr,UnityEngine.Rect&,UnityEngine.GUIContent,System.Int32,UnityEngine.Color&)
		void Register_UnityEngine_GUIStyle_INTERNAL_CALL_Internal_DrawCursor();
		Register_UnityEngine_GUIStyle_INTERNAL_CALL_Internal_DrawCursor();

		//System.Void UnityEngine.GUIStyle::INTERNAL_CALL_Internal_DrawPrefixLabel(System.IntPtr,UnityEngine.Rect&,UnityEngine.GUIContent,System.Int32,System.Boolean)
		void Register_UnityEngine_GUIStyle_INTERNAL_CALL_Internal_DrawPrefixLabel();
		Register_UnityEngine_GUIStyle_INTERNAL_CALL_Internal_DrawPrefixLabel();

		//System.Void UnityEngine.GUIStyle::INTERNAL_CALL_Internal_GetCursorPixelPosition(System.IntPtr,UnityEngine.Rect&,UnityEngine.GUIContent,System.Int32,UnityEngine.Vector2&)
		void Register_UnityEngine_GUIStyle_INTERNAL_CALL_Internal_GetCursorPixelPosition();
		Register_UnityEngine_GUIStyle_INTERNAL_CALL_Internal_GetCursorPixelPosition();

		//System.Void UnityEngine.GUIStyle::INTERNAL_CALL_SetMouseTooltip(UnityEngine.GUIStyle,System.String,UnityEngine.Rect&)
		void Register_UnityEngine_GUIStyle_INTERNAL_CALL_SetMouseTooltip();
		Register_UnityEngine_GUIStyle_INTERNAL_CALL_SetMouseTooltip();

		//System.Void UnityEngine.GUIStyle::INTERNAL_get_Internal_clipOffset(UnityEngine.Vector2&)
		void Register_UnityEngine_GUIStyle_INTERNAL_get_Internal_clipOffset();
		Register_UnityEngine_GUIStyle_INTERNAL_get_Internal_clipOffset();

		//System.Void UnityEngine.GUIStyle::INTERNAL_get_contentOffset(UnityEngine.Vector2&)
		void Register_UnityEngine_GUIStyle_INTERNAL_get_contentOffset();
		Register_UnityEngine_GUIStyle_INTERNAL_get_contentOffset();

		//System.Void UnityEngine.GUIStyle::INTERNAL_set_Internal_clipOffset(UnityEngine.Vector2&)
		void Register_UnityEngine_GUIStyle_INTERNAL_set_Internal_clipOffset();
		Register_UnityEngine_GUIStyle_INTERNAL_set_Internal_clipOffset();

		//System.Void UnityEngine.GUIStyle::INTERNAL_set_contentOffset(UnityEngine.Vector2&)
		void Register_UnityEngine_GUIStyle_INTERNAL_set_contentOffset();
		Register_UnityEngine_GUIStyle_INTERNAL_set_contentOffset();

		//System.Void UnityEngine.GUIStyle::Init()
		void Register_UnityEngine_GUIStyle_Init();
		Register_UnityEngine_GUIStyle_Init();

		//System.Void UnityEngine.GUIStyle::InitCopy(UnityEngine.GUIStyle)
		void Register_UnityEngine_GUIStyle_InitCopy();
		Register_UnityEngine_GUIStyle_InitCopy();

		//System.Void UnityEngine.GUIStyle::Internal_CalcMinMaxWidth(System.IntPtr,UnityEngine.GUIContent,System.Single&,System.Single&)
		void Register_UnityEngine_GUIStyle_Internal_CalcMinMaxWidth();
		Register_UnityEngine_GUIStyle_Internal_CalcMinMaxWidth();

		//System.Void UnityEngine.GUIStyle::Internal_CalcSize(System.IntPtr,UnityEngine.GUIContent,UnityEngine.Vector2&)
		void Register_UnityEngine_GUIStyle_Internal_CalcSize();
		Register_UnityEngine_GUIStyle_Internal_CalcSize();

		//System.Void UnityEngine.GUIStyle::Internal_Draw(UnityEngine.GUIContent,UnityEngine.Internal_DrawArguments&)
		void Register_UnityEngine_GUIStyle_Internal_Draw();
		Register_UnityEngine_GUIStyle_Internal_Draw();

		//System.Void UnityEngine.GUIStyle::Internal_DrawWithTextSelection(UnityEngine.GUIContent,UnityEngine.Internal_DrawWithTextSelectionArguments&)
		void Register_UnityEngine_GUIStyle_Internal_DrawWithTextSelection();
		Register_UnityEngine_GUIStyle_Internal_DrawWithTextSelection();

		//System.Void UnityEngine.GUIStyle::SetDefaultFont(UnityEngine.Font)
		void Register_UnityEngine_GUIStyle_SetDefaultFont();
		Register_UnityEngine_GUIStyle_SetDefaultFont();

		//System.Void UnityEngine.GUIStyle::SetFontInternal(UnityEngine.Font)
		void Register_UnityEngine_GUIStyle_SetFontInternal();
		Register_UnityEngine_GUIStyle_SetFontInternal();

		//System.Void UnityEngine.GUIStyle::set_alignment(UnityEngine.TextAnchor)
		void Register_UnityEngine_GUIStyle_set_alignment();
		Register_UnityEngine_GUIStyle_set_alignment();

		//System.Void UnityEngine.GUIStyle::set_clipping(UnityEngine.TextClipping)
		void Register_UnityEngine_GUIStyle_set_clipping();
		Register_UnityEngine_GUIStyle_set_clipping();

		//System.Void UnityEngine.GUIStyle::set_fixedHeight(System.Single)
		void Register_UnityEngine_GUIStyle_set_fixedHeight();
		Register_UnityEngine_GUIStyle_set_fixedHeight();

		//System.Void UnityEngine.GUIStyle::set_fixedWidth(System.Single)
		void Register_UnityEngine_GUIStyle_set_fixedWidth();
		Register_UnityEngine_GUIStyle_set_fixedWidth();

		//System.Void UnityEngine.GUIStyle::set_fontSize(System.Int32)
		void Register_UnityEngine_GUIStyle_set_fontSize();
		Register_UnityEngine_GUIStyle_set_fontSize();

		//System.Void UnityEngine.GUIStyle::set_fontStyle(UnityEngine.FontStyle)
		void Register_UnityEngine_GUIStyle_set_fontStyle();
		Register_UnityEngine_GUIStyle_set_fontStyle();

		//System.Void UnityEngine.GUIStyle::set_imagePosition(UnityEngine.ImagePosition)
		void Register_UnityEngine_GUIStyle_set_imagePosition();
		Register_UnityEngine_GUIStyle_set_imagePosition();

		//System.Void UnityEngine.GUIStyle::set_name(System.String)
		void Register_UnityEngine_GUIStyle_set_name();
		Register_UnityEngine_GUIStyle_set_name();

		//System.Void UnityEngine.GUIStyle::set_richText(System.Boolean)
		void Register_UnityEngine_GUIStyle_set_richText();
		Register_UnityEngine_GUIStyle_set_richText();

		//System.Void UnityEngine.GUIStyle::set_stretchHeight(System.Boolean)
		void Register_UnityEngine_GUIStyle_set_stretchHeight();
		Register_UnityEngine_GUIStyle_set_stretchHeight();

		//System.Void UnityEngine.GUIStyle::set_stretchWidth(System.Boolean)
		void Register_UnityEngine_GUIStyle_set_stretchWidth();
		Register_UnityEngine_GUIStyle_set_stretchWidth();

		//System.Void UnityEngine.GUIStyle::set_wordWrap(System.Boolean)
		void Register_UnityEngine_GUIStyle_set_wordWrap();
		Register_UnityEngine_GUIStyle_set_wordWrap();

		//UnityEngine.Font UnityEngine.GUIStyle::GetFontInternal()
		void Register_UnityEngine_GUIStyle_GetFontInternal();
		Register_UnityEngine_GUIStyle_GetFontInternal();

		//UnityEngine.Font UnityEngine.GUIStyle::GetFontInternalDuringLoadingThread()
		void Register_UnityEngine_GUIStyle_GetFontInternalDuringLoadingThread();
		Register_UnityEngine_GUIStyle_GetFontInternalDuringLoadingThread();

		//UnityEngine.FontStyle UnityEngine.GUIStyle::get_fontStyle()
		void Register_UnityEngine_GUIStyle_get_fontStyle();
		Register_UnityEngine_GUIStyle_get_fontStyle();

		//UnityEngine.ImagePosition UnityEngine.GUIStyle::get_imagePosition()
		void Register_UnityEngine_GUIStyle_get_imagePosition();
		Register_UnityEngine_GUIStyle_get_imagePosition();

		//UnityEngine.TextAnchor UnityEngine.GUIStyle::get_alignment()
		void Register_UnityEngine_GUIStyle_get_alignment();
		Register_UnityEngine_GUIStyle_get_alignment();

		//UnityEngine.TextClipping UnityEngine.GUIStyle::get_clipping()
		void Register_UnityEngine_GUIStyle_get_clipping();
		Register_UnityEngine_GUIStyle_get_clipping();

	//End Registrations for type : UnityEngine.GUIStyle

	//Start Registrations for type : UnityEngine.GUIStyleState

		//System.Void UnityEngine.GUIStyleState::Cleanup()
		void Register_UnityEngine_GUIStyleState_Cleanup();
		Register_UnityEngine_GUIStyleState_Cleanup();

		//System.Void UnityEngine.GUIStyleState::INTERNAL_get_textColor(UnityEngine.Color&)
		void Register_UnityEngine_GUIStyleState_INTERNAL_get_textColor();
		Register_UnityEngine_GUIStyleState_INTERNAL_get_textColor();

		//System.Void UnityEngine.GUIStyleState::INTERNAL_set_textColor(UnityEngine.Color&)
		void Register_UnityEngine_GUIStyleState_INTERNAL_set_textColor();
		Register_UnityEngine_GUIStyleState_INTERNAL_set_textColor();

		//System.Void UnityEngine.GUIStyleState::Init()
		void Register_UnityEngine_GUIStyleState_Init();
		Register_UnityEngine_GUIStyleState_Init();

		//System.Void UnityEngine.GUIStyleState::SetBackgroundInternal(UnityEngine.Texture2D)
		void Register_UnityEngine_GUIStyleState_SetBackgroundInternal();
		Register_UnityEngine_GUIStyleState_SetBackgroundInternal();

		//UnityEngine.Texture2D UnityEngine.GUIStyleState::GetBackgroundInternal()
		void Register_UnityEngine_GUIStyleState_GetBackgroundInternal();
		Register_UnityEngine_GUIStyleState_GetBackgroundInternal();

		//UnityEngine.Texture2D UnityEngine.GUIStyleState::GetBackgroundInternalFromDeserialization()
		void Register_UnityEngine_GUIStyleState_GetBackgroundInternalFromDeserialization();
		Register_UnityEngine_GUIStyleState_GetBackgroundInternalFromDeserialization();

	//End Registrations for type : UnityEngine.GUIStyleState

	//Start Registrations for type : UnityEngine.GUIUtility

		//System.Boolean UnityEngine.GUIUtility::GetChanged()
		void Register_UnityEngine_GUIUtility_GetChanged();
		Register_UnityEngine_GUIUtility_GetChanged();

		//System.Boolean UnityEngine.GUIUtility::HasMouseControl(System.Int32)
		void Register_UnityEngine_GUIUtility_HasMouseControl();
		Register_UnityEngine_GUIUtility_HasMouseControl();

		//System.Boolean UnityEngine.GUIUtility::get_hasModalWindow()
		void Register_UnityEngine_GUIUtility_get_hasModalWindow();
		Register_UnityEngine_GUIUtility_get_hasModalWindow();

		//System.Boolean UnityEngine.GUIUtility::get_mouseUsed()
		void Register_UnityEngine_GUIUtility_get_mouseUsed();
		Register_UnityEngine_GUIUtility_get_mouseUsed();

		//System.Boolean UnityEngine.GUIUtility::get_textFieldInput()
		void Register_UnityEngine_GUIUtility_get_textFieldInput();
		Register_UnityEngine_GUIUtility_get_textFieldInput();

		//System.Int32 UnityEngine.GUIUtility::GetControlID(System.Int32,UnityEngine.FocusType)
		void Register_UnityEngine_GUIUtility_GetControlID();
		Register_UnityEngine_GUIUtility_GetControlID();

		//System.Int32 UnityEngine.GUIUtility::GetPermanentControlID()
		void Register_UnityEngine_GUIUtility_GetPermanentControlID();
		Register_UnityEngine_GUIUtility_GetPermanentControlID();

		//System.Int32 UnityEngine.GUIUtility::INTERNAL_CALL_Internal_GetNextControlID2(System.Int32,UnityEngine.FocusType,UnityEngine.Rect&)
		void Register_UnityEngine_GUIUtility_INTERNAL_CALL_Internal_GetNextControlID2();
		Register_UnityEngine_GUIUtility_INTERNAL_CALL_Internal_GetNextControlID2();

		//System.Int32 UnityEngine.GUIUtility::Internal_GetGUIDepth()
		void Register_UnityEngine_GUIUtility_Internal_GetGUIDepth();
		Register_UnityEngine_GUIUtility_Internal_GetGUIDepth();

		//System.Int32 UnityEngine.GUIUtility::Internal_GetHotControl()
		void Register_UnityEngine_GUIUtility_Internal_GetHotControl();
		Register_UnityEngine_GUIUtility_Internal_GetHotControl();

		//System.Int32 UnityEngine.GUIUtility::get_keyboardControl()
		void Register_UnityEngine_GUIUtility_get_keyboardControl();
		Register_UnityEngine_GUIUtility_get_keyboardControl();

		//System.Single UnityEngine.GUIUtility::Internal_GetPixelsPerPoint()
		void Register_UnityEngine_GUIUtility_Internal_GetPixelsPerPoint();
		Register_UnityEngine_GUIUtility_Internal_GetPixelsPerPoint();

		//System.String UnityEngine.GUIUtility::get_systemCopyBuffer()
		void Register_UnityEngine_GUIUtility_get_systemCopyBuffer();
		Register_UnityEngine_GUIUtility_get_systemCopyBuffer();

		//System.Void UnityEngine.GUIUtility::GrabMouseControl(System.Int32)
		void Register_UnityEngine_GUIUtility_GrabMouseControl();
		Register_UnityEngine_GUIUtility_GrabMouseControl();

		//System.Void UnityEngine.GUIUtility::Internal_ExitGUI()
		void Register_UnityEngine_GUIUtility_Internal_ExitGUI();
		Register_UnityEngine_GUIUtility_Internal_ExitGUI();

		//System.Void UnityEngine.GUIUtility::Internal_SetHotControl(System.Int32)
		void Register_UnityEngine_GUIUtility_Internal_SetHotControl();
		Register_UnityEngine_GUIUtility_Internal_SetHotControl();

		//System.Void UnityEngine.GUIUtility::ReleaseMouseControl()
		void Register_UnityEngine_GUIUtility_ReleaseMouseControl();
		Register_UnityEngine_GUIUtility_ReleaseMouseControl();

		//System.Void UnityEngine.GUIUtility::SetChanged(System.Boolean)
		void Register_UnityEngine_GUIUtility_SetChanged();
		Register_UnityEngine_GUIUtility_SetChanged();

		//System.Void UnityEngine.GUIUtility::SetDidGUIWindowsEatLastEvent(System.Boolean)
		void Register_UnityEngine_GUIUtility_SetDidGUIWindowsEatLastEvent();
		Register_UnityEngine_GUIUtility_SetDidGUIWindowsEatLastEvent();

		//System.Void UnityEngine.GUIUtility::UpdateUndoName()
		void Register_UnityEngine_GUIUtility_UpdateUndoName();
		Register_UnityEngine_GUIUtility_UpdateUndoName();

		//System.Void UnityEngine.GUIUtility::set_keyboardControl(System.Int32)
		void Register_UnityEngine_GUIUtility_set_keyboardControl();
		Register_UnityEngine_GUIUtility_set_keyboardControl();

		//System.Void UnityEngine.GUIUtility::set_mouseUsed(System.Boolean)
		void Register_UnityEngine_GUIUtility_set_mouseUsed();
		Register_UnityEngine_GUIUtility_set_mouseUsed();

		//System.Void UnityEngine.GUIUtility::set_systemCopyBuffer(System.String)
		void Register_UnityEngine_GUIUtility_set_systemCopyBuffer();
		Register_UnityEngine_GUIUtility_set_systemCopyBuffer();

		//System.Void UnityEngine.GUIUtility::set_textFieldInput(System.Boolean)
		void Register_UnityEngine_GUIUtility_set_textFieldInput();
		Register_UnityEngine_GUIUtility_set_textFieldInput();

		//UnityEngine.GUISkin UnityEngine.GUIUtility::Internal_GetDefaultSkin(System.Int32)
		void Register_UnityEngine_GUIUtility_Internal_GetDefaultSkin();
		Register_UnityEngine_GUIUtility_Internal_GetDefaultSkin();

		//UnityEngine.Object UnityEngine.GUIUtility::Internal_GetBuiltinSkin(System.Int32)
		void Register_UnityEngine_GUIUtility_Internal_GetBuiltinSkin();
		Register_UnityEngine_GUIUtility_Internal_GetBuiltinSkin();

	//End Registrations for type : UnityEngine.GUIUtility

	//Start Registrations for type : UnityEngine.Hash128

		//System.String UnityEngine.Hash128::Internal_Hash128ToString(System.UInt32,System.UInt32,System.UInt32,System.UInt32)
		void Register_UnityEngine_Hash128_Internal_Hash128ToString();
		Register_UnityEngine_Hash128_Internal_Hash128ToString();

	//End Registrations for type : UnityEngine.Hash128

	//Start Registrations for type : UnityEngine.Input

		//System.Boolean UnityEngine.Input::GetButtonDown(System.String)
		void Register_UnityEngine_Input_GetButtonDown();
		Register_UnityEngine_Input_GetButtonDown();

		//System.Boolean UnityEngine.Input::GetKeyDownInt(System.Int32)
		void Register_UnityEngine_Input_GetKeyDownInt();
		Register_UnityEngine_Input_GetKeyDownInt();

		//System.Boolean UnityEngine.Input::GetKeyInt(System.Int32)
		void Register_UnityEngine_Input_GetKeyInt();
		Register_UnityEngine_Input_GetKeyInt();

		//System.Boolean UnityEngine.Input::GetMouseButton(System.Int32)
		void Register_UnityEngine_Input_GetMouseButton();
		Register_UnityEngine_Input_GetMouseButton();

		//System.Boolean UnityEngine.Input::GetMouseButtonDown(System.Int32)
		void Register_UnityEngine_Input_GetMouseButtonDown();
		Register_UnityEngine_Input_GetMouseButtonDown();

		//System.Boolean UnityEngine.Input::GetMouseButtonUp(System.Int32)
		void Register_UnityEngine_Input_GetMouseButtonUp();
		Register_UnityEngine_Input_GetMouseButtonUp();

		//System.Boolean UnityEngine.Input::get_anyKeyDown()
		void Register_UnityEngine_Input_get_anyKeyDown();
		Register_UnityEngine_Input_get_anyKeyDown();

		//System.Boolean UnityEngine.Input::get_mousePresent()
		void Register_UnityEngine_Input_get_mousePresent();
		Register_UnityEngine_Input_get_mousePresent();

		//System.Boolean UnityEngine.Input::get_touchSupported()
		void Register_UnityEngine_Input_get_touchSupported();
		Register_UnityEngine_Input_get_touchSupported();

		//System.Int32 UnityEngine.Input::get_touchCount()
		void Register_UnityEngine_Input_get_touchCount();
		Register_UnityEngine_Input_get_touchCount();

		//System.Single UnityEngine.Input::GetAxis(System.String)
		void Register_UnityEngine_Input_GetAxis();
		Register_UnityEngine_Input_GetAxis();

		//System.Single UnityEngine.Input::GetAxisRaw(System.String)
		void Register_UnityEngine_Input_GetAxisRaw();
		Register_UnityEngine_Input_GetAxisRaw();

		//System.String UnityEngine.Input::get_compositionString()
		void Register_UnityEngine_Input_get_compositionString();
		Register_UnityEngine_Input_get_compositionString();

		//System.Void UnityEngine.Input::INTERNAL_CALL_GetTouch(System.Int32,UnityEngine.Touch&)
		void Register_UnityEngine_Input_INTERNAL_CALL_GetTouch();
		Register_UnityEngine_Input_INTERNAL_CALL_GetTouch();

		//System.Void UnityEngine.Input::INTERNAL_get_compositionCursorPos(UnityEngine.Vector2&)
		void Register_UnityEngine_Input_INTERNAL_get_compositionCursorPos();
		Register_UnityEngine_Input_INTERNAL_get_compositionCursorPos();

		//System.Void UnityEngine.Input::INTERNAL_get_mousePosition(UnityEngine.Vector3&)
		void Register_UnityEngine_Input_INTERNAL_get_mousePosition();
		Register_UnityEngine_Input_INTERNAL_get_mousePosition();

		//System.Void UnityEngine.Input::INTERNAL_get_mouseScrollDelta(UnityEngine.Vector2&)
		void Register_UnityEngine_Input_INTERNAL_get_mouseScrollDelta();
		Register_UnityEngine_Input_INTERNAL_get_mouseScrollDelta();

		//System.Void UnityEngine.Input::INTERNAL_set_compositionCursorPos(UnityEngine.Vector2&)
		void Register_UnityEngine_Input_INTERNAL_set_compositionCursorPos();
		Register_UnityEngine_Input_INTERNAL_set_compositionCursorPos();

		//System.Void UnityEngine.Input::set_imeCompositionMode(UnityEngine.IMECompositionMode)
		void Register_UnityEngine_Input_set_imeCompositionMode();
		Register_UnityEngine_Input_set_imeCompositionMode();

		//UnityEngine.IMECompositionMode UnityEngine.Input::get_imeCompositionMode()
		void Register_UnityEngine_Input_get_imeCompositionMode();
		Register_UnityEngine_Input_get_imeCompositionMode();

	//End Registrations for type : UnityEngine.Input

	//Start Registrations for type : UnityEngine.iOS.LocalNotification

		//System.Boolean UnityEngine.iOS.LocalNotification::get_hasAction()
		void Register_UnityEngine_iOS_LocalNotification_get_hasAction();
		Register_UnityEngine_iOS_LocalNotification_get_hasAction();

		//System.Collections.IDictionary UnityEngine.iOS.LocalNotification::get_userInfo()
		void Register_UnityEngine_iOS_LocalNotification_get_userInfo();
		Register_UnityEngine_iOS_LocalNotification_get_userInfo();

		//System.Double UnityEngine.iOS.LocalNotification::GetFireDate()
		void Register_UnityEngine_iOS_LocalNotification_GetFireDate();
		Register_UnityEngine_iOS_LocalNotification_GetFireDate();

		//System.Int32 UnityEngine.iOS.LocalNotification::get_applicationIconBadgeNumber()
		void Register_UnityEngine_iOS_LocalNotification_get_applicationIconBadgeNumber();
		Register_UnityEngine_iOS_LocalNotification_get_applicationIconBadgeNumber();

		//System.String UnityEngine.iOS.LocalNotification::get_alertAction()
		void Register_UnityEngine_iOS_LocalNotification_get_alertAction();
		Register_UnityEngine_iOS_LocalNotification_get_alertAction();

		//System.String UnityEngine.iOS.LocalNotification::get_alertBody()
		void Register_UnityEngine_iOS_LocalNotification_get_alertBody();
		Register_UnityEngine_iOS_LocalNotification_get_alertBody();

		//System.String UnityEngine.iOS.LocalNotification::get_alertLaunchImage()
		void Register_UnityEngine_iOS_LocalNotification_get_alertLaunchImage();
		Register_UnityEngine_iOS_LocalNotification_get_alertLaunchImage();

		//System.String UnityEngine.iOS.LocalNotification::get_defaultSoundName()
		void Register_UnityEngine_iOS_LocalNotification_get_defaultSoundName();
		Register_UnityEngine_iOS_LocalNotification_get_defaultSoundName();

		//System.String UnityEngine.iOS.LocalNotification::get_soundName()
		void Register_UnityEngine_iOS_LocalNotification_get_soundName();
		Register_UnityEngine_iOS_LocalNotification_get_soundName();

		//System.String UnityEngine.iOS.LocalNotification::get_timeZone()
		void Register_UnityEngine_iOS_LocalNotification_get_timeZone();
		Register_UnityEngine_iOS_LocalNotification_get_timeZone();

		//System.Void UnityEngine.iOS.LocalNotification::Destroy()
		void Register_UnityEngine_iOS_LocalNotification_Destroy();
		Register_UnityEngine_iOS_LocalNotification_Destroy();

		//System.Void UnityEngine.iOS.LocalNotification::InitWrapper()
		void Register_UnityEngine_iOS_LocalNotification_InitWrapper();
		Register_UnityEngine_iOS_LocalNotification_InitWrapper();

		//System.Void UnityEngine.iOS.LocalNotification::SetFireDate(System.Double)
		void Register_UnityEngine_iOS_LocalNotification_SetFireDate();
		Register_UnityEngine_iOS_LocalNotification_SetFireDate();

		//System.Void UnityEngine.iOS.LocalNotification::set_alertAction(System.String)
		void Register_UnityEngine_iOS_LocalNotification_set_alertAction();
		Register_UnityEngine_iOS_LocalNotification_set_alertAction();

		//System.Void UnityEngine.iOS.LocalNotification::set_alertBody(System.String)
		void Register_UnityEngine_iOS_LocalNotification_set_alertBody();
		Register_UnityEngine_iOS_LocalNotification_set_alertBody();

		//System.Void UnityEngine.iOS.LocalNotification::set_alertLaunchImage(System.String)
		void Register_UnityEngine_iOS_LocalNotification_set_alertLaunchImage();
		Register_UnityEngine_iOS_LocalNotification_set_alertLaunchImage();

		//System.Void UnityEngine.iOS.LocalNotification::set_applicationIconBadgeNumber(System.Int32)
		void Register_UnityEngine_iOS_LocalNotification_set_applicationIconBadgeNumber();
		Register_UnityEngine_iOS_LocalNotification_set_applicationIconBadgeNumber();

		//System.Void UnityEngine.iOS.LocalNotification::set_hasAction(System.Boolean)
		void Register_UnityEngine_iOS_LocalNotification_set_hasAction();
		Register_UnityEngine_iOS_LocalNotification_set_hasAction();

		//System.Void UnityEngine.iOS.LocalNotification::set_repeatCalendar(UnityEngine.iOS.CalendarIdentifier)
		void Register_UnityEngine_iOS_LocalNotification_set_repeatCalendar();
		Register_UnityEngine_iOS_LocalNotification_set_repeatCalendar();

		//System.Void UnityEngine.iOS.LocalNotification::set_repeatInterval(UnityEngine.iOS.CalendarUnit)
		void Register_UnityEngine_iOS_LocalNotification_set_repeatInterval();
		Register_UnityEngine_iOS_LocalNotification_set_repeatInterval();

		//System.Void UnityEngine.iOS.LocalNotification::set_soundName(System.String)
		void Register_UnityEngine_iOS_LocalNotification_set_soundName();
		Register_UnityEngine_iOS_LocalNotification_set_soundName();

		//System.Void UnityEngine.iOS.LocalNotification::set_timeZone(System.String)
		void Register_UnityEngine_iOS_LocalNotification_set_timeZone();
		Register_UnityEngine_iOS_LocalNotification_set_timeZone();

		//System.Void UnityEngine.iOS.LocalNotification::set_userInfo(System.Collections.IDictionary)
		void Register_UnityEngine_iOS_LocalNotification_set_userInfo();
		Register_UnityEngine_iOS_LocalNotification_set_userInfo();

		//UnityEngine.iOS.CalendarIdentifier UnityEngine.iOS.LocalNotification::get_repeatCalendar()
		void Register_UnityEngine_iOS_LocalNotification_get_repeatCalendar();
		Register_UnityEngine_iOS_LocalNotification_get_repeatCalendar();

		//UnityEngine.iOS.CalendarUnit UnityEngine.iOS.LocalNotification::get_repeatInterval()
		void Register_UnityEngine_iOS_LocalNotification_get_repeatInterval();
		Register_UnityEngine_iOS_LocalNotification_get_repeatInterval();

	//End Registrations for type : UnityEngine.iOS.LocalNotification

	//Start Registrations for type : UnityEngine.iOS.RemoteNotification

		//System.Boolean UnityEngine.iOS.RemoteNotification::get_hasAction()
		void Register_UnityEngine_iOS_RemoteNotification_get_hasAction();
		Register_UnityEngine_iOS_RemoteNotification_get_hasAction();

		//System.Collections.IDictionary UnityEngine.iOS.RemoteNotification::get_userInfo()
		void Register_UnityEngine_iOS_RemoteNotification_get_userInfo();
		Register_UnityEngine_iOS_RemoteNotification_get_userInfo();

		//System.Int32 UnityEngine.iOS.RemoteNotification::get_applicationIconBadgeNumber()
		void Register_UnityEngine_iOS_RemoteNotification_get_applicationIconBadgeNumber();
		Register_UnityEngine_iOS_RemoteNotification_get_applicationIconBadgeNumber();

		//System.String UnityEngine.iOS.RemoteNotification::get_alertBody()
		void Register_UnityEngine_iOS_RemoteNotification_get_alertBody();
		Register_UnityEngine_iOS_RemoteNotification_get_alertBody();

		//System.String UnityEngine.iOS.RemoteNotification::get_soundName()
		void Register_UnityEngine_iOS_RemoteNotification_get_soundName();
		Register_UnityEngine_iOS_RemoteNotification_get_soundName();

		//System.Void UnityEngine.iOS.RemoteNotification::Destroy()
		void Register_UnityEngine_iOS_RemoteNotification_Destroy();
		Register_UnityEngine_iOS_RemoteNotification_Destroy();

	//End Registrations for type : UnityEngine.iOS.RemoteNotification

	//Start Registrations for type : UnityEngine.Light

		//System.Single UnityEngine.Light::get_intensity()
		void Register_UnityEngine_Light_get_intensity();
		Register_UnityEngine_Light_get_intensity();

		//System.Void UnityEngine.Light::set_intensity(System.Single)
		void Register_UnityEngine_Light_set_intensity();
		Register_UnityEngine_Light_set_intensity();

	//End Registrations for type : UnityEngine.Light

	//Start Registrations for type : UnityEngine.Material

		//System.Boolean UnityEngine.Material::HasProperty(System.Int32)
		void Register_UnityEngine_Material_HasProperty();
		Register_UnityEngine_Material_HasProperty();

		//System.Boolean UnityEngine.Material::SetPass(System.Int32)
		void Register_UnityEngine_Material_SetPass();
		Register_UnityEngine_Material_SetPass();

		//System.Void UnityEngine.Material::DisableKeyword(System.String)
		void Register_UnityEngine_Material_DisableKeyword();
		Register_UnityEngine_Material_DisableKeyword();

		//System.Void UnityEngine.Material::EnableKeyword(System.String)
		void Register_UnityEngine_Material_EnableKeyword();
		Register_UnityEngine_Material_EnableKeyword();

		//System.Void UnityEngine.Material::INTERNAL_CALL_GetColor(UnityEngine.Material,System.Int32,UnityEngine.Color&)
		void Register_UnityEngine_Material_INTERNAL_CALL_GetColor();
		Register_UnityEngine_Material_INTERNAL_CALL_GetColor();

		//System.Void UnityEngine.Material::INTERNAL_CALL_SetColor(UnityEngine.Material,System.Int32,UnityEngine.Color&)
		void Register_UnityEngine_Material_INTERNAL_CALL_SetColor();
		Register_UnityEngine_Material_INTERNAL_CALL_SetColor();

		//System.Void UnityEngine.Material::Internal_CreateWithMaterial(UnityEngine.Material,UnityEngine.Material)
		void Register_UnityEngine_Material_Internal_CreateWithMaterial();
		Register_UnityEngine_Material_Internal_CreateWithMaterial();

		//System.Void UnityEngine.Material::Internal_CreateWithShader(UnityEngine.Material,UnityEngine.Shader)
		void Register_UnityEngine_Material_Internal_CreateWithShader();
		Register_UnityEngine_Material_Internal_CreateWithShader();

		//System.Void UnityEngine.Material::SetFloat(System.Int32,System.Single)
		void Register_UnityEngine_Material_SetFloat();
		Register_UnityEngine_Material_SetFloat();

		//UnityEngine.Texture UnityEngine.Material::GetTexture(System.Int32)
		void Register_UnityEngine_Material_GetTexture();
		Register_UnityEngine_Material_GetTexture();

	//End Registrations for type : UnityEngine.Material

	//Start Registrations for type : UnityEngine.Mathf

		//System.Single UnityEngine.Mathf::PerlinNoise(System.Single,System.Single)
		void Register_UnityEngine_Mathf_PerlinNoise();
		Register_UnityEngine_Mathf_PerlinNoise();

	//End Registrations for type : UnityEngine.Mathf

	//Start Registrations for type : UnityEngine.Matrix4x4

		//System.Void UnityEngine.Matrix4x4::INTERNAL_CALL_TRS(UnityEngine.Vector3&,UnityEngine.Quaternion&,UnityEngine.Vector3&,UnityEngine.Matrix4x4&)
		void Register_UnityEngine_Matrix4x4_INTERNAL_CALL_TRS();
		Register_UnityEngine_Matrix4x4_INTERNAL_CALL_TRS();

	//End Registrations for type : UnityEngine.Matrix4x4

	//Start Registrations for type : UnityEngine.Mesh

		//System.Array UnityEngine.Mesh::ExtractArrayFromList(System.Object)
		void Register_UnityEngine_Mesh_ExtractArrayFromList();
		Register_UnityEngine_Mesh_ExtractArrayFromList();

		//System.Array UnityEngine.Mesh::GetAllocArrayFromChannelImpl(UnityEngine.Mesh/InternalShaderChannel,UnityEngine.Mesh/InternalVertexChannelType,System.Int32)
		void Register_UnityEngine_Mesh_GetAllocArrayFromChannelImpl();
		Register_UnityEngine_Mesh_GetAllocArrayFromChannelImpl();

		//System.Boolean UnityEngine.Mesh::HasChannel(UnityEngine.Mesh/InternalShaderChannel)
		void Register_UnityEngine_Mesh_HasChannel();
		Register_UnityEngine_Mesh_HasChannel();

		//System.Boolean UnityEngine.Mesh::get_canAccess()
		void Register_UnityEngine_Mesh_get_canAccess();
		Register_UnityEngine_Mesh_get_canAccess();

		//System.Boolean UnityEngine.Mesh::get_isReadable()
		void Register_UnityEngine_Mesh_get_isReadable();
		Register_UnityEngine_Mesh_get_isReadable();

		//System.Int32 UnityEngine.Mesh::GetBindposeCount()
		void Register_UnityEngine_Mesh_GetBindposeCount();
		Register_UnityEngine_Mesh_GetBindposeCount();

		//System.Int32 UnityEngine.Mesh::GetBlendShapeFrameCount(System.Int32)
		void Register_UnityEngine_Mesh_GetBlendShapeFrameCount();
		Register_UnityEngine_Mesh_GetBlendShapeFrameCount();

		//System.Int32 UnityEngine.Mesh::GetBlendShapeIndex(System.String)
		void Register_UnityEngine_Mesh_GetBlendShapeIndex();
		Register_UnityEngine_Mesh_GetBlendShapeIndex();

		//System.Int32 UnityEngine.Mesh::get_blendShapeCount()
		void Register_UnityEngine_Mesh_get_blendShapeCount();
		Register_UnityEngine_Mesh_get_blendShapeCount();

		//System.Int32 UnityEngine.Mesh::get_subMeshCount()
		void Register_UnityEngine_Mesh_get_subMeshCount();
		Register_UnityEngine_Mesh_get_subMeshCount();

		//System.Int32 UnityEngine.Mesh::get_vertexBufferCount()
		void Register_UnityEngine_Mesh_get_vertexBufferCount();
		Register_UnityEngine_Mesh_get_vertexBufferCount();

		//System.Int32 UnityEngine.Mesh::get_vertexCount()
		void Register_UnityEngine_Mesh_get_vertexCount();
		Register_UnityEngine_Mesh_get_vertexCount();

		//System.Int32[] UnityEngine.Mesh::GetIndicesImpl(System.Int32)
		void Register_UnityEngine_Mesh_GetIndicesImpl();
		Register_UnityEngine_Mesh_GetIndicesImpl();

		//System.Int32[] UnityEngine.Mesh::GetTrianglesImpl(System.Int32)
		void Register_UnityEngine_Mesh_GetTrianglesImpl();
		Register_UnityEngine_Mesh_GetTrianglesImpl();

		//System.Single UnityEngine.Mesh::GetBlendShapeFrameWeight(System.Int32,System.Int32)
		void Register_UnityEngine_Mesh_GetBlendShapeFrameWeight();
		Register_UnityEngine_Mesh_GetBlendShapeFrameWeight();

		//System.String UnityEngine.Mesh::GetBlendShapeName(System.Int32)
		void Register_UnityEngine_Mesh_GetBlendShapeName();
		Register_UnityEngine_Mesh_GetBlendShapeName();

		//System.UInt32 UnityEngine.Mesh::GetIndexCount(System.Int32)
		void Register_UnityEngine_Mesh_GetIndexCount();
		Register_UnityEngine_Mesh_GetIndexCount();

		//System.UInt32 UnityEngine.Mesh::GetIndexStart(System.Int32)
		void Register_UnityEngine_Mesh_GetIndexStart();
		Register_UnityEngine_Mesh_GetIndexStart();

		//System.Void UnityEngine.Mesh::AddBlendShapeFrame(System.String,System.Single,UnityEngine.Vector3[],UnityEngine.Vector3[],UnityEngine.Vector3[])
		void Register_UnityEngine_Mesh_AddBlendShapeFrame();
		Register_UnityEngine_Mesh_AddBlendShapeFrame();

		//System.Void UnityEngine.Mesh::Clear(System.Boolean)
		void Register_UnityEngine_Mesh_Clear();
		Register_UnityEngine_Mesh_Clear();

		//System.Void UnityEngine.Mesh::ClearBlendShapes()
		void Register_UnityEngine_Mesh_ClearBlendShapes();
		Register_UnityEngine_Mesh_ClearBlendShapes();

		//System.Void UnityEngine.Mesh::CombineMeshes(UnityEngine.CombineInstance[],System.Boolean,System.Boolean)
		void Register_UnityEngine_Mesh_CombineMeshes();
		Register_UnityEngine_Mesh_CombineMeshes();

		//System.Void UnityEngine.Mesh::GetArrayFromChannelImpl(UnityEngine.Mesh/InternalShaderChannel,UnityEngine.Mesh/InternalVertexChannelType,System.Int32,System.Array)
		void Register_UnityEngine_Mesh_GetArrayFromChannelImpl();
		Register_UnityEngine_Mesh_GetArrayFromChannelImpl();

		//System.Void UnityEngine.Mesh::GetBindposesNonAllocImpl(System.Object)
		void Register_UnityEngine_Mesh_GetBindposesNonAllocImpl();
		Register_UnityEngine_Mesh_GetBindposesNonAllocImpl();

		//System.Void UnityEngine.Mesh::GetBlendShapeFrameVertices(System.Int32,System.Int32,UnityEngine.Vector3[],UnityEngine.Vector3[],UnityEngine.Vector3[])
		void Register_UnityEngine_Mesh_GetBlendShapeFrameVertices();
		Register_UnityEngine_Mesh_GetBlendShapeFrameVertices();

		//System.Void UnityEngine.Mesh::GetBoneWeightsNonAllocImpl(System.Object)
		void Register_UnityEngine_Mesh_GetBoneWeightsNonAllocImpl();
		Register_UnityEngine_Mesh_GetBoneWeightsNonAllocImpl();

		//System.Void UnityEngine.Mesh::GetIndicesNonAllocImpl(System.Object,System.Int32)
		void Register_UnityEngine_Mesh_GetIndicesNonAllocImpl();
		Register_UnityEngine_Mesh_GetIndicesNonAllocImpl();

		//System.Void UnityEngine.Mesh::GetTrianglesNonAllocImpl(System.Object,System.Int32)
		void Register_UnityEngine_Mesh_GetTrianglesNonAllocImpl();
		Register_UnityEngine_Mesh_GetTrianglesNonAllocImpl();

		//System.Void UnityEngine.Mesh::INTERNAL_CALL_GetNativeIndexBufferPtr(UnityEngine.Mesh,System.IntPtr&)
		void Register_UnityEngine_Mesh_INTERNAL_CALL_GetNativeIndexBufferPtr();
		Register_UnityEngine_Mesh_INTERNAL_CALL_GetNativeIndexBufferPtr();

		//System.Void UnityEngine.Mesh::INTERNAL_CALL_GetNativeVertexBufferPtr(UnityEngine.Mesh,System.Int32,System.IntPtr&)
		void Register_UnityEngine_Mesh_INTERNAL_CALL_GetNativeVertexBufferPtr();
		Register_UnityEngine_Mesh_INTERNAL_CALL_GetNativeVertexBufferPtr();

		//System.Void UnityEngine.Mesh::INTERNAL_get_bounds(UnityEngine.Bounds&)
		void Register_UnityEngine_Mesh_INTERNAL_get_bounds();
		Register_UnityEngine_Mesh_INTERNAL_get_bounds();

		//System.Void UnityEngine.Mesh::INTERNAL_set_bounds(UnityEngine.Bounds&)
		void Register_UnityEngine_Mesh_INTERNAL_set_bounds();
		Register_UnityEngine_Mesh_INTERNAL_set_bounds();

		//System.Void UnityEngine.Mesh::Internal_Create(UnityEngine.Mesh)
		void Register_UnityEngine_Mesh_Internal_Create();
		Register_UnityEngine_Mesh_Internal_Create();

		//System.Void UnityEngine.Mesh::MarkDynamic()
		void Register_UnityEngine_Mesh_MarkDynamic();
		Register_UnityEngine_Mesh_MarkDynamic();

		//System.Void UnityEngine.Mesh::Optimize()
		void Register_UnityEngine_Mesh_Optimize();
		Register_UnityEngine_Mesh_Optimize();

		//System.Void UnityEngine.Mesh::PrintErrorBadSubmeshIndexIndices()
		void Register_UnityEngine_Mesh_PrintErrorBadSubmeshIndexIndices();
		Register_UnityEngine_Mesh_PrintErrorBadSubmeshIndexIndices();

		//System.Void UnityEngine.Mesh::PrintErrorBadSubmeshIndexTriangles()
		void Register_UnityEngine_Mesh_PrintErrorBadSubmeshIndexTriangles();
		Register_UnityEngine_Mesh_PrintErrorBadSubmeshIndexTriangles();

		//System.Void UnityEngine.Mesh::PrintErrorCantAccessMesh(UnityEngine.Mesh/InternalShaderChannel)
		void Register_UnityEngine_Mesh_PrintErrorCantAccessMesh();
		Register_UnityEngine_Mesh_PrintErrorCantAccessMesh();

		//System.Void UnityEngine.Mesh::PrintErrorCantAccessMeshForIndices()
		void Register_UnityEngine_Mesh_PrintErrorCantAccessMeshForIndices();
		Register_UnityEngine_Mesh_PrintErrorCantAccessMeshForIndices();

		//System.Void UnityEngine.Mesh::RecalculateBounds()
		void Register_UnityEngine_Mesh_RecalculateBounds();
		Register_UnityEngine_Mesh_RecalculateBounds();

		//System.Void UnityEngine.Mesh::RecalculateNormals()
		void Register_UnityEngine_Mesh_RecalculateNormals();
		Register_UnityEngine_Mesh_RecalculateNormals();

		//System.Void UnityEngine.Mesh::ResizeList(System.Object,System.Int32)
		void Register_UnityEngine_Mesh_ResizeList();
		Register_UnityEngine_Mesh_ResizeList();

		//System.Void UnityEngine.Mesh::SetArrayForChannelImpl(UnityEngine.Mesh/InternalShaderChannel,UnityEngine.Mesh/InternalVertexChannelType,System.Int32,System.Array,System.Int32)
		void Register_UnityEngine_Mesh_SetArrayForChannelImpl();
		Register_UnityEngine_Mesh_SetArrayForChannelImpl();

		//System.Void UnityEngine.Mesh::SetIndicesImpl(System.Int32,UnityEngine.MeshTopology,System.Array,System.Int32,System.Boolean)
		void Register_UnityEngine_Mesh_SetIndicesImpl();
		Register_UnityEngine_Mesh_SetIndicesImpl();

		//System.Void UnityEngine.Mesh::SetTrianglesImpl(System.Int32,System.Array,System.Int32,System.Boolean)
		void Register_UnityEngine_Mesh_SetTrianglesImpl();
		Register_UnityEngine_Mesh_SetTrianglesImpl();

		//System.Void UnityEngine.Mesh::UploadMeshData(System.Boolean)
		void Register_UnityEngine_Mesh_UploadMeshData();
		Register_UnityEngine_Mesh_UploadMeshData();

		//System.Void UnityEngine.Mesh::set_bindposes(UnityEngine.Matrix4x4[])
		void Register_UnityEngine_Mesh_set_bindposes();
		Register_UnityEngine_Mesh_set_bindposes();

		//System.Void UnityEngine.Mesh::set_boneWeights(UnityEngine.BoneWeight[])
		void Register_UnityEngine_Mesh_set_boneWeights();
		Register_UnityEngine_Mesh_set_boneWeights();

		//System.Void UnityEngine.Mesh::set_subMeshCount(System.Int32)
		void Register_UnityEngine_Mesh_set_subMeshCount();
		Register_UnityEngine_Mesh_set_subMeshCount();

		//UnityEngine.BoneWeight[] UnityEngine.Mesh::get_boneWeights()
		void Register_UnityEngine_Mesh_get_boneWeights();
		Register_UnityEngine_Mesh_get_boneWeights();

		//UnityEngine.Matrix4x4[] UnityEngine.Mesh::get_bindposes()
		void Register_UnityEngine_Mesh_get_bindposes();
		Register_UnityEngine_Mesh_get_bindposes();

		//UnityEngine.MeshTopology UnityEngine.Mesh::GetTopology(System.Int32)
		void Register_UnityEngine_Mesh_GetTopology();
		Register_UnityEngine_Mesh_GetTopology();

	//End Registrations for type : UnityEngine.Mesh

	//Start Registrations for type : UnityEngine.MeshFilter

		//UnityEngine.Mesh UnityEngine.MeshFilter::get_mesh()
		void Register_UnityEngine_MeshFilter_get_mesh();
		Register_UnityEngine_MeshFilter_get_mesh();

	//End Registrations for type : UnityEngine.MeshFilter

	//Start Registrations for type : UnityEngine.MeshRenderer

		//System.Void UnityEngine.MeshRenderer::set_additionalVertexStreams(UnityEngine.Mesh)
		void Register_UnityEngine_MeshRenderer_set_additionalVertexStreams();
		Register_UnityEngine_MeshRenderer_set_additionalVertexStreams();

		//UnityEngine.Mesh UnityEngine.MeshRenderer::get_additionalVertexStreams()
		void Register_UnityEngine_MeshRenderer_get_additionalVertexStreams();
		Register_UnityEngine_MeshRenderer_get_additionalVertexStreams();

	//End Registrations for type : UnityEngine.MeshRenderer

	//Start Registrations for type : UnityEngine.MonoBehaviour

		//System.Boolean UnityEngine.MonoBehaviour::Internal_IsInvokingAll()
		void Register_UnityEngine_MonoBehaviour_Internal_IsInvokingAll();
		Register_UnityEngine_MonoBehaviour_Internal_IsInvokingAll();

		//System.Boolean UnityEngine.MonoBehaviour::IsInvoking(System.String)
		void Register_UnityEngine_MonoBehaviour_IsInvoking();
		Register_UnityEngine_MonoBehaviour_IsInvoking();

		//System.Boolean UnityEngine.MonoBehaviour::get_useGUILayout()
		void Register_UnityEngine_MonoBehaviour_get_useGUILayout();
		Register_UnityEngine_MonoBehaviour_get_useGUILayout();

		//System.Void UnityEngine.MonoBehaviour::.ctor()
		void Register_UnityEngine_MonoBehaviour__ctor();
		Register_UnityEngine_MonoBehaviour__ctor();

		//System.Void UnityEngine.MonoBehaviour::CancelInvoke(System.String)
		void Register_UnityEngine_MonoBehaviour_CancelInvoke();
		Register_UnityEngine_MonoBehaviour_CancelInvoke();

		//System.Void UnityEngine.MonoBehaviour::Internal_CancelInvokeAll()
		void Register_UnityEngine_MonoBehaviour_Internal_CancelInvokeAll();
		Register_UnityEngine_MonoBehaviour_Internal_CancelInvokeAll();

		//System.Void UnityEngine.MonoBehaviour::Invoke(System.String,System.Single)
		void Register_UnityEngine_MonoBehaviour_Invoke();
		Register_UnityEngine_MonoBehaviour_Invoke();

		//System.Void UnityEngine.MonoBehaviour::InvokeRepeating(System.String,System.Single,System.Single)
		void Register_UnityEngine_MonoBehaviour_InvokeRepeating();
		Register_UnityEngine_MonoBehaviour_InvokeRepeating();

		//System.Void UnityEngine.MonoBehaviour::StopAllCoroutines()
		void Register_UnityEngine_MonoBehaviour_StopAllCoroutines();
		Register_UnityEngine_MonoBehaviour_StopAllCoroutines();

		//System.Void UnityEngine.MonoBehaviour::StopCoroutine(System.String)
		void Register_UnityEngine_MonoBehaviour_StopCoroutine();
		Register_UnityEngine_MonoBehaviour_StopCoroutine();

		//System.Void UnityEngine.MonoBehaviour::StopCoroutineViaEnumerator_Auto(System.Collections.IEnumerator)
		void Register_UnityEngine_MonoBehaviour_StopCoroutineViaEnumerator_Auto();
		Register_UnityEngine_MonoBehaviour_StopCoroutineViaEnumerator_Auto();

		//System.Void UnityEngine.MonoBehaviour::StopCoroutine_Auto(UnityEngine.Coroutine)
		void Register_UnityEngine_MonoBehaviour_StopCoroutine_Auto();
		Register_UnityEngine_MonoBehaviour_StopCoroutine_Auto();

		//System.Void UnityEngine.MonoBehaviour::set_useGUILayout(System.Boolean)
		void Register_UnityEngine_MonoBehaviour_set_useGUILayout();
		Register_UnityEngine_MonoBehaviour_set_useGUILayout();

		//UnityEngine.Coroutine UnityEngine.MonoBehaviour::StartCoroutine(System.String,System.Object)
		void Register_UnityEngine_MonoBehaviour_StartCoroutine();
		Register_UnityEngine_MonoBehaviour_StartCoroutine();

		//UnityEngine.Coroutine UnityEngine.MonoBehaviour::StartCoroutine_Auto_Internal(System.Collections.IEnumerator)
		void Register_UnityEngine_MonoBehaviour_StartCoroutine_Auto_Internal();
		Register_UnityEngine_MonoBehaviour_StartCoroutine_Auto_Internal();

	//End Registrations for type : UnityEngine.MonoBehaviour

	//Start Registrations for type : UnityEngine.Networking.ConnectionConfigInternal

		//System.Byte UnityEngine.Networking.ConnectionConfigInternal::AddChannel(UnityEngine.Networking.QosType)
		void Register_UnityEngine_Networking_ConnectionConfigInternal_AddChannel();
		Register_UnityEngine_Networking_ConnectionConfigInternal_AddChannel();

		//System.Void UnityEngine.Networking.ConnectionConfigInternal::Dispose()
		void Register_UnityEngine_Networking_ConnectionConfigInternal_Dispose();
		Register_UnityEngine_Networking_ConnectionConfigInternal_Dispose();

		//System.Void UnityEngine.Networking.ConnectionConfigInternal::InitAckDelay(System.UInt32)
		void Register_UnityEngine_Networking_ConnectionConfigInternal_InitAckDelay();
		Register_UnityEngine_Networking_ConnectionConfigInternal_InitAckDelay();

		//System.Void UnityEngine.Networking.ConnectionConfigInternal::InitAllCostTimeout(System.UInt32)
		void Register_UnityEngine_Networking_ConnectionConfigInternal_InitAllCostTimeout();
		Register_UnityEngine_Networking_ConnectionConfigInternal_InitAllCostTimeout();

		//System.Void UnityEngine.Networking.ConnectionConfigInternal::InitConnectTimeout(System.UInt32)
		void Register_UnityEngine_Networking_ConnectionConfigInternal_InitConnectTimeout();
		Register_UnityEngine_Networking_ConnectionConfigInternal_InitConnectTimeout();

		//System.Void UnityEngine.Networking.ConnectionConfigInternal::InitDisconnectTimeout(System.UInt32)
		void Register_UnityEngine_Networking_ConnectionConfigInternal_InitDisconnectTimeout();
		Register_UnityEngine_Networking_ConnectionConfigInternal_InitDisconnectTimeout();

		//System.Void UnityEngine.Networking.ConnectionConfigInternal::InitFragmentSize(System.UInt16)
		void Register_UnityEngine_Networking_ConnectionConfigInternal_InitFragmentSize();
		Register_UnityEngine_Networking_ConnectionConfigInternal_InitFragmentSize();

		//System.Void UnityEngine.Networking.ConnectionConfigInternal::InitIsAcksLong(System.Boolean)
		void Register_UnityEngine_Networking_ConnectionConfigInternal_InitIsAcksLong();
		Register_UnityEngine_Networking_ConnectionConfigInternal_InitIsAcksLong();

		//System.Void UnityEngine.Networking.ConnectionConfigInternal::InitMaxCombinedReliableMessageCount(System.UInt16)
		void Register_UnityEngine_Networking_ConnectionConfigInternal_InitMaxCombinedReliableMessageCount();
		Register_UnityEngine_Networking_ConnectionConfigInternal_InitMaxCombinedReliableMessageCount();

		//System.Void UnityEngine.Networking.ConnectionConfigInternal::InitMaxCombinedReliableMessageSize(System.UInt16)
		void Register_UnityEngine_Networking_ConnectionConfigInternal_InitMaxCombinedReliableMessageSize();
		Register_UnityEngine_Networking_ConnectionConfigInternal_InitMaxCombinedReliableMessageSize();

		//System.Void UnityEngine.Networking.ConnectionConfigInternal::InitMaxConnectionAttempt(System.Byte)
		void Register_UnityEngine_Networking_ConnectionConfigInternal_InitMaxConnectionAttempt();
		Register_UnityEngine_Networking_ConnectionConfigInternal_InitMaxConnectionAttempt();

		//System.Void UnityEngine.Networking.ConnectionConfigInternal::InitMaxSentMessageQueueSize(System.UInt16)
		void Register_UnityEngine_Networking_ConnectionConfigInternal_InitMaxSentMessageQueueSize();
		Register_UnityEngine_Networking_ConnectionConfigInternal_InitMaxSentMessageQueueSize();

		//System.Void UnityEngine.Networking.ConnectionConfigInternal::InitMinUpdateTimeout(System.UInt32)
		void Register_UnityEngine_Networking_ConnectionConfigInternal_InitMinUpdateTimeout();
		Register_UnityEngine_Networking_ConnectionConfigInternal_InitMinUpdateTimeout();

		//System.Void UnityEngine.Networking.ConnectionConfigInternal::InitNetworkDropThreshold(System.Byte)
		void Register_UnityEngine_Networking_ConnectionConfigInternal_InitNetworkDropThreshold();
		Register_UnityEngine_Networking_ConnectionConfigInternal_InitNetworkDropThreshold();

		//System.Void UnityEngine.Networking.ConnectionConfigInternal::InitOverflowDropThreshold(System.Byte)
		void Register_UnityEngine_Networking_ConnectionConfigInternal_InitOverflowDropThreshold();
		Register_UnityEngine_Networking_ConnectionConfigInternal_InitOverflowDropThreshold();

		//System.Void UnityEngine.Networking.ConnectionConfigInternal::InitPacketSize(System.UInt16)
		void Register_UnityEngine_Networking_ConnectionConfigInternal_InitPacketSize();
		Register_UnityEngine_Networking_ConnectionConfigInternal_InitPacketSize();

		//System.Void UnityEngine.Networking.ConnectionConfigInternal::InitPingTimeout(System.UInt32)
		void Register_UnityEngine_Networking_ConnectionConfigInternal_InitPingTimeout();
		Register_UnityEngine_Networking_ConnectionConfigInternal_InitPingTimeout();

		//System.Void UnityEngine.Networking.ConnectionConfigInternal::InitReducedPingTimeout(System.UInt32)
		void Register_UnityEngine_Networking_ConnectionConfigInternal_InitReducedPingTimeout();
		Register_UnityEngine_Networking_ConnectionConfigInternal_InitReducedPingTimeout();

		//System.Void UnityEngine.Networking.ConnectionConfigInternal::InitResendTimeout(System.UInt32)
		void Register_UnityEngine_Networking_ConnectionConfigInternal_InitResendTimeout();
		Register_UnityEngine_Networking_ConnectionConfigInternal_InitResendTimeout();

		//System.Void UnityEngine.Networking.ConnectionConfigInternal::InitUsePlatformSpecificProtocols(System.Boolean)
		void Register_UnityEngine_Networking_ConnectionConfigInternal_InitUsePlatformSpecificProtocols();
		Register_UnityEngine_Networking_ConnectionConfigInternal_InitUsePlatformSpecificProtocols();

		//System.Void UnityEngine.Networking.ConnectionConfigInternal::InitWebSocketReceiveBufferMaxSize(System.UInt16)
		void Register_UnityEngine_Networking_ConnectionConfigInternal_InitWebSocketReceiveBufferMaxSize();
		Register_UnityEngine_Networking_ConnectionConfigInternal_InitWebSocketReceiveBufferMaxSize();

		//System.Void UnityEngine.Networking.ConnectionConfigInternal::InitWrapper()
		void Register_UnityEngine_Networking_ConnectionConfigInternal_InitWrapper();
		Register_UnityEngine_Networking_ConnectionConfigInternal_InitWrapper();

	//End Registrations for type : UnityEngine.Networking.ConnectionConfigInternal

	//Start Registrations for type : UnityEngine.Networking.ConnectionSimulatorConfig

		//System.Void UnityEngine.Networking.ConnectionSimulatorConfig::.ctor(System.Int32,System.Int32,System.Int32,System.Int32,System.Single)
		void Register_UnityEngine_Networking_ConnectionSimulatorConfig__ctor();
		Register_UnityEngine_Networking_ConnectionSimulatorConfig__ctor();

		//System.Void UnityEngine.Networking.ConnectionSimulatorConfig::Dispose()
		void Register_UnityEngine_Networking_ConnectionSimulatorConfig_Dispose();
		Register_UnityEngine_Networking_ConnectionSimulatorConfig_Dispose();

	//End Registrations for type : UnityEngine.Networking.ConnectionSimulatorConfig

	//Start Registrations for type : UnityEngine.Networking.DownloadHandler

		//System.Boolean UnityEngine.Networking.DownloadHandler::get_isDone()
		void Register_UnityEngine_Networking_DownloadHandler_get_isDone();
		Register_UnityEngine_Networking_DownloadHandler_get_isDone();

		//System.Void UnityEngine.Networking.DownloadHandler::INTERNAL_CALL_InternalCreateAssetBundle(UnityEngine.Networking.DownloadHandler,System.String,UnityEngine.Hash128&,System.UInt32)
		void Register_UnityEngine_Networking_DownloadHandler_INTERNAL_CALL_InternalCreateAssetBundle();
		Register_UnityEngine_Networking_DownloadHandler_INTERNAL_CALL_InternalCreateAssetBundle();

		//System.Void UnityEngine.Networking.DownloadHandler::InternalCreateAssetBundle(System.String,System.UInt32)
		void Register_UnityEngine_Networking_DownloadHandler_InternalCreateAssetBundle();
		Register_UnityEngine_Networking_DownloadHandler_InternalCreateAssetBundle();

		//System.Void UnityEngine.Networking.DownloadHandler::InternalCreateAudioClip(System.String,UnityEngine.AudioType)
		void Register_UnityEngine_Networking_DownloadHandler_InternalCreateAudioClip();
		Register_UnityEngine_Networking_DownloadHandler_InternalCreateAudioClip();

		//System.Void UnityEngine.Networking.DownloadHandler::InternalCreateBuffer()
		void Register_UnityEngine_Networking_DownloadHandler_InternalCreateBuffer();
		Register_UnityEngine_Networking_DownloadHandler_InternalCreateBuffer();

		//System.Void UnityEngine.Networking.DownloadHandler::InternalCreateScript()
		void Register_UnityEngine_Networking_DownloadHandler_InternalCreateScript();
		Register_UnityEngine_Networking_DownloadHandler_InternalCreateScript();

		//System.Void UnityEngine.Networking.DownloadHandler::InternalCreateTexture(System.Boolean)
		void Register_UnityEngine_Networking_DownloadHandler_InternalCreateTexture();
		Register_UnityEngine_Networking_DownloadHandler_InternalCreateTexture();

		//System.Void UnityEngine.Networking.DownloadHandler::InternalDestroy()
		void Register_UnityEngine_Networking_DownloadHandler_InternalDestroy();
		Register_UnityEngine_Networking_DownloadHandler_InternalDestroy();

	//End Registrations for type : UnityEngine.Networking.DownloadHandler

	//Start Registrations for type : UnityEngine.Networking.GlobalConfigInternal

		//System.Void UnityEngine.Networking.GlobalConfigInternal::Dispose()
		void Register_UnityEngine_Networking_GlobalConfigInternal_Dispose();
		Register_UnityEngine_Networking_GlobalConfigInternal_Dispose();

		//System.Void UnityEngine.Networking.GlobalConfigInternal::InitMaxPacketSize(System.UInt16)
		void Register_UnityEngine_Networking_GlobalConfigInternal_InitMaxPacketSize();
		Register_UnityEngine_Networking_GlobalConfigInternal_InitMaxPacketSize();

		//System.Void UnityEngine.Networking.GlobalConfigInternal::InitReactorMaximumReceivedMessages(System.UInt16)
		void Register_UnityEngine_Networking_GlobalConfigInternal_InitReactorMaximumReceivedMessages();
		Register_UnityEngine_Networking_GlobalConfigInternal_InitReactorMaximumReceivedMessages();

		//System.Void UnityEngine.Networking.GlobalConfigInternal::InitReactorMaximumSentMessages(System.UInt16)
		void Register_UnityEngine_Networking_GlobalConfigInternal_InitReactorMaximumSentMessages();
		Register_UnityEngine_Networking_GlobalConfigInternal_InitReactorMaximumSentMessages();

		//System.Void UnityEngine.Networking.GlobalConfigInternal::InitReactorModel(System.Byte)
		void Register_UnityEngine_Networking_GlobalConfigInternal_InitReactorModel();
		Register_UnityEngine_Networking_GlobalConfigInternal_InitReactorModel();

		//System.Void UnityEngine.Networking.GlobalConfigInternal::InitThreadAwakeTimeout(System.UInt32)
		void Register_UnityEngine_Networking_GlobalConfigInternal_InitThreadAwakeTimeout();
		Register_UnityEngine_Networking_GlobalConfigInternal_InitThreadAwakeTimeout();

		//System.Void UnityEngine.Networking.GlobalConfigInternal::InitWrapper()
		void Register_UnityEngine_Networking_GlobalConfigInternal_InitWrapper();
		Register_UnityEngine_Networking_GlobalConfigInternal_InitWrapper();

	//End Registrations for type : UnityEngine.Networking.GlobalConfigInternal

	//Start Registrations for type : UnityEngine.Networking.HostTopologyInternal

		//System.Int32 UnityEngine.Networking.HostTopologyInternal::AddSpecialConnectionConfigWrapper(UnityEngine.Networking.ConnectionConfigInternal)
		void Register_UnityEngine_Networking_HostTopologyInternal_AddSpecialConnectionConfigWrapper();
		Register_UnityEngine_Networking_HostTopologyInternal_AddSpecialConnectionConfigWrapper();

		//System.Void UnityEngine.Networking.HostTopologyInternal::Dispose()
		void Register_UnityEngine_Networking_HostTopologyInternal_Dispose();
		Register_UnityEngine_Networking_HostTopologyInternal_Dispose();

		//System.Void UnityEngine.Networking.HostTopologyInternal::InitMessagePoolSizeGrowthFactor(System.Single)
		void Register_UnityEngine_Networking_HostTopologyInternal_InitMessagePoolSizeGrowthFactor();
		Register_UnityEngine_Networking_HostTopologyInternal_InitMessagePoolSizeGrowthFactor();

		//System.Void UnityEngine.Networking.HostTopologyInternal::InitReceivedPoolSize(System.UInt16)
		void Register_UnityEngine_Networking_HostTopologyInternal_InitReceivedPoolSize();
		Register_UnityEngine_Networking_HostTopologyInternal_InitReceivedPoolSize();

		//System.Void UnityEngine.Networking.HostTopologyInternal::InitSentMessagePoolSize(System.UInt16)
		void Register_UnityEngine_Networking_HostTopologyInternal_InitSentMessagePoolSize();
		Register_UnityEngine_Networking_HostTopologyInternal_InitSentMessagePoolSize();

		//System.Void UnityEngine.Networking.HostTopologyInternal::InitWrapper(UnityEngine.Networking.ConnectionConfigInternal,System.Int32)
		void Register_UnityEngine_Networking_HostTopologyInternal_InitWrapper();
		Register_UnityEngine_Networking_HostTopologyInternal_InitWrapper();

	//End Registrations for type : UnityEngine.Networking.HostTopologyInternal

	//Start Registrations for type : UnityEngine.Networking.NetworkTransport

		//System.Boolean UnityEngine.Networking.NetworkTransport::Disconnect(System.Int32,System.Int32,System.Byte&)
		void Register_UnityEngine_Networking_NetworkTransport_Disconnect();
		Register_UnityEngine_Networking_NetworkTransport_Disconnect();

		//System.Boolean UnityEngine.Networking.NetworkTransport::RemoveHost(System.Int32)
		void Register_UnityEngine_Networking_NetworkTransport_RemoveHost();
		Register_UnityEngine_Networking_NetworkTransport_RemoveHost();

		//System.Boolean UnityEngine.Networking.NetworkTransport::SendWrapper(System.Int32,System.Int32,System.Int32,System.Byte[],System.Int32,System.Byte&)
		void Register_UnityEngine_Networking_NetworkTransport_SendWrapper();
		Register_UnityEngine_Networking_NetworkTransport_SendWrapper();

		//System.Boolean UnityEngine.Networking.NetworkTransport::StartBroadcastDiscoveryWithData(System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,System.Byte[],System.Int32,System.Int32,System.Byte&)
		void Register_UnityEngine_Networking_NetworkTransport_StartBroadcastDiscoveryWithData();
		Register_UnityEngine_Networking_NetworkTransport_StartBroadcastDiscoveryWithData();

		//System.Boolean UnityEngine.Networking.NetworkTransport::StartBroadcastDiscoveryWithoutData(System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,System.Byte&)
		void Register_UnityEngine_Networking_NetworkTransport_StartBroadcastDiscoveryWithoutData();
		Register_UnityEngine_Networking_NetworkTransport_StartBroadcastDiscoveryWithoutData();

		//System.Boolean UnityEngine.Networking.NetworkTransport::get_IsStarted()
		void Register_UnityEngine_Networking_NetworkTransport_get_IsStarted();
		Register_UnityEngine_Networking_NetworkTransport_get_IsStarted();

		//System.Int32 UnityEngine.Networking.NetworkTransport::AddHostWrapper(UnityEngine.Networking.HostTopologyInternal,System.String,System.Int32,System.Int32,System.Int32)
		void Register_UnityEngine_Networking_NetworkTransport_AddHostWrapper();
		Register_UnityEngine_Networking_NetworkTransport_AddHostWrapper();

		//System.Int32 UnityEngine.Networking.NetworkTransport::AddHostWrapperWithoutIp(UnityEngine.Networking.HostTopologyInternal,System.Int32,System.Int32,System.Int32)
		void Register_UnityEngine_Networking_NetworkTransport_AddHostWrapperWithoutIp();
		Register_UnityEngine_Networking_NetworkTransport_AddHostWrapperWithoutIp();

		//System.Int32 UnityEngine.Networking.NetworkTransport::AddWsHostWrapper(UnityEngine.Networking.HostTopologyInternal,System.String,System.Int32)
		void Register_UnityEngine_Networking_NetworkTransport_AddWsHostWrapper();
		Register_UnityEngine_Networking_NetworkTransport_AddWsHostWrapper();

		//System.Int32 UnityEngine.Networking.NetworkTransport::AddWsHostWrapperWithoutIp(UnityEngine.Networking.HostTopologyInternal,System.Int32)
		void Register_UnityEngine_Networking_NetworkTransport_AddWsHostWrapperWithoutIp();
		Register_UnityEngine_Networking_NetworkTransport_AddWsHostWrapperWithoutIp();

		//System.Int32 UnityEngine.Networking.NetworkTransport::Connect(System.Int32,System.String,System.Int32,System.Int32,System.Byte&)
		void Register_UnityEngine_Networking_NetworkTransport_Connect();
		Register_UnityEngine_Networking_NetworkTransport_Connect();

		//System.Int32 UnityEngine.Networking.NetworkTransport::ConnectToNetworkPeer(System.Int32,System.String,System.Int32,System.Int32,System.Int32,UnityEngine.Networking.Types.NetworkID,UnityEngine.Networking.Types.SourceID,UnityEngine.Networking.Types.NodeID,System.Int32,System.Single,System.Byte&)
		void Register_UnityEngine_Networking_NetworkTransport_ConnectToNetworkPeer();
		Register_UnityEngine_Networking_NetworkTransport_ConnectToNetworkPeer();

		//System.Int32 UnityEngine.Networking.NetworkTransport::ConnectWithSimulator(System.Int32,System.String,System.Int32,System.Int32,System.Byte&,UnityEngine.Networking.ConnectionSimulatorConfig)
		void Register_UnityEngine_Networking_NetworkTransport_ConnectWithSimulator();
		Register_UnityEngine_Networking_NetworkTransport_ConnectWithSimulator();

		//System.Int32 UnityEngine.Networking.NetworkTransport::GetMaxPacketSize()
		void Register_UnityEngine_Networking_NetworkTransport_GetMaxPacketSize();
		Register_UnityEngine_Networking_NetworkTransport_GetMaxPacketSize();

		//System.Int32 UnityEngine.Networking.NetworkTransport::Internal_ConnectEndPoint(System.Int32,System.IntPtr,System.Int32,System.Int32,System.Byte&)
		void Register_UnityEngine_Networking_NetworkTransport_Internal_ConnectEndPoint();
		Register_UnityEngine_Networking_NetworkTransport_Internal_ConnectEndPoint();

		//System.String UnityEngine.Networking.NetworkTransport::GetBroadcastConnectionInfo(System.Int32,System.Int32&,System.Byte&)
		void Register_UnityEngine_Networking_NetworkTransport_GetBroadcastConnectionInfo();
		Register_UnityEngine_Networking_NetworkTransport_GetBroadcastConnectionInfo();

		//System.String UnityEngine.Networking.NetworkTransport::GetConnectionInfo(System.Int32,System.Int32,System.Int32&,System.UInt64&,System.UInt16&,System.Byte&)
		void Register_UnityEngine_Networking_NetworkTransport_GetConnectionInfo();
		Register_UnityEngine_Networking_NetworkTransport_GetConnectionInfo();

		//System.Void UnityEngine.Networking.NetworkTransport::ConnectAsNetworkHost(System.Int32,System.String,System.Int32,UnityEngine.Networking.Types.NetworkID,UnityEngine.Networking.Types.SourceID,UnityEngine.Networking.Types.NodeID,System.Byte&)
		void Register_UnityEngine_Networking_NetworkTransport_ConnectAsNetworkHost();
		Register_UnityEngine_Networking_NetworkTransport_ConnectAsNetworkHost();

		//System.Void UnityEngine.Networking.NetworkTransport::GetBroadcastConnectionMessage(System.Int32,System.Byte[],System.Int32,System.Int32&,System.Byte&)
		void Register_UnityEngine_Networking_NetworkTransport_GetBroadcastConnectionMessage();
		Register_UnityEngine_Networking_NetworkTransport_GetBroadcastConnectionMessage();

		//System.Void UnityEngine.Networking.NetworkTransport::InitWithNoParameters()
		void Register_UnityEngine_Networking_NetworkTransport_InitWithNoParameters();
		Register_UnityEngine_Networking_NetworkTransport_InitWithNoParameters();

		//System.Void UnityEngine.Networking.NetworkTransport::InitWithParameters(UnityEngine.Networking.GlobalConfigInternal)
		void Register_UnityEngine_Networking_NetworkTransport_InitWithParameters();
		Register_UnityEngine_Networking_NetworkTransport_InitWithParameters();

		//System.Void UnityEngine.Networking.NetworkTransport::SetBroadcastCredentials(System.Int32,System.Int32,System.Int32,System.Int32,System.Byte&)
		void Register_UnityEngine_Networking_NetworkTransport_SetBroadcastCredentials();
		Register_UnityEngine_Networking_NetworkTransport_SetBroadcastCredentials();

		//System.Void UnityEngine.Networking.NetworkTransport::StopBroadcastDiscovery()
		void Register_UnityEngine_Networking_NetworkTransport_StopBroadcastDiscovery();
		Register_UnityEngine_Networking_NetworkTransport_StopBroadcastDiscovery();

		//UnityEngine.Networking.NetworkEventType UnityEngine.Networking.NetworkTransport::ReceiveFromHost(System.Int32,System.Int32&,System.Int32&,System.Byte[],System.Int32,System.Int32&,System.Byte&)
		void Register_UnityEngine_Networking_NetworkTransport_ReceiveFromHost();
		Register_UnityEngine_Networking_NetworkTransport_ReceiveFromHost();

		//UnityEngine.Networking.NetworkEventType UnityEngine.Networking.NetworkTransport::ReceiveRelayEventFromHost(System.Int32,System.Byte&)
		void Register_UnityEngine_Networking_NetworkTransport_ReceiveRelayEventFromHost();
		Register_UnityEngine_Networking_NetworkTransport_ReceiveRelayEventFromHost();

	//End Registrations for type : UnityEngine.Networking.NetworkTransport

	//Start Registrations for type : UnityEngine.Networking.UnityWebRequest

		//System.Boolean UnityEngine.Networking.UnityWebRequest::get_isDone()
		void Register_UnityEngine_Networking_UnityWebRequest_get_isDone();
		Register_UnityEngine_Networking_UnityWebRequest_get_isDone();

		//System.Boolean UnityEngine.Networking.UnityWebRequest::get_isError()
		void Register_UnityEngine_Networking_UnityWebRequest_get_isError();
		Register_UnityEngine_Networking_UnityWebRequest_get_isError();

		//System.String UnityEngine.Networking.UnityWebRequest::get_error()
		void Register_UnityEngine_Networking_UnityWebRequest_get_error();
		Register_UnityEngine_Networking_UnityWebRequest_get_error();

		//System.Void UnityEngine.Networking.UnityWebRequest::InternalDestroy()
		void Register_UnityEngine_Networking_UnityWebRequest_InternalDestroy();
		Register_UnityEngine_Networking_UnityWebRequest_InternalDestroy();

		//UnityEngine.Networking.DownloadHandler UnityEngine.Networking.UnityWebRequest::get_downloadHandler()
		void Register_UnityEngine_Networking_UnityWebRequest_get_downloadHandler();
		Register_UnityEngine_Networking_UnityWebRequest_get_downloadHandler();

		//UnityEngine.Networking.UploadHandler UnityEngine.Networking.UnityWebRequest::get_uploadHandler()
		void Register_UnityEngine_Networking_UnityWebRequest_get_uploadHandler();
		Register_UnityEngine_Networking_UnityWebRequest_get_uploadHandler();

	//End Registrations for type : UnityEngine.Networking.UnityWebRequest

	//Start Registrations for type : UnityEngine.Networking.UploadHandler

		//System.Void UnityEngine.Networking.UploadHandler::InternalDestroy()
		void Register_UnityEngine_Networking_UploadHandler_InternalDestroy();
		Register_UnityEngine_Networking_UploadHandler_InternalDestroy();

	//End Registrations for type : UnityEngine.Networking.UploadHandler

	//Start Registrations for type : UnityEngine.NetworkMessageInfo

		//UnityEngine.NetworkView UnityEngine.NetworkMessageInfo::NullNetworkView()
		void Register_UnityEngine_NetworkMessageInfo_NullNetworkView();
		Register_UnityEngine_NetworkMessageInfo_NullNetworkView();

	//End Registrations for type : UnityEngine.NetworkMessageInfo

	//Start Registrations for type : UnityEngine.NetworkPlayer

		//System.Int32 UnityEngine.NetworkPlayer::Internal_GetExternalPort()
		void Register_UnityEngine_NetworkPlayer_Internal_GetExternalPort();
		Register_UnityEngine_NetworkPlayer_Internal_GetExternalPort();

		//System.Int32 UnityEngine.NetworkPlayer::Internal_GetLocalPort()
		void Register_UnityEngine_NetworkPlayer_Internal_GetLocalPort();
		Register_UnityEngine_NetworkPlayer_Internal_GetLocalPort();

		//System.Int32 UnityEngine.NetworkPlayer::Internal_GetPlayerIndex()
		void Register_UnityEngine_NetworkPlayer_Internal_GetPlayerIndex();
		Register_UnityEngine_NetworkPlayer_Internal_GetPlayerIndex();

		//System.Int32 UnityEngine.NetworkPlayer::Internal_GetPort(System.Int32)
		void Register_UnityEngine_NetworkPlayer_Internal_GetPort();
		Register_UnityEngine_NetworkPlayer_Internal_GetPort();

		//System.String UnityEngine.NetworkPlayer::Internal_GetExternalIP()
		void Register_UnityEngine_NetworkPlayer_Internal_GetExternalIP();
		Register_UnityEngine_NetworkPlayer_Internal_GetExternalIP();

		//System.String UnityEngine.NetworkPlayer::Internal_GetGUID(System.Int32)
		void Register_UnityEngine_NetworkPlayer_Internal_GetGUID();
		Register_UnityEngine_NetworkPlayer_Internal_GetGUID();

		//System.String UnityEngine.NetworkPlayer::Internal_GetIPAddress(System.Int32)
		void Register_UnityEngine_NetworkPlayer_Internal_GetIPAddress();
		Register_UnityEngine_NetworkPlayer_Internal_GetIPAddress();

		//System.String UnityEngine.NetworkPlayer::Internal_GetLocalGUID()
		void Register_UnityEngine_NetworkPlayer_Internal_GetLocalGUID();
		Register_UnityEngine_NetworkPlayer_Internal_GetLocalGUID();

		//System.String UnityEngine.NetworkPlayer::Internal_GetLocalIP()
		void Register_UnityEngine_NetworkPlayer_Internal_GetLocalIP();
		Register_UnityEngine_NetworkPlayer_Internal_GetLocalIP();

	//End Registrations for type : UnityEngine.NetworkPlayer

	//Start Registrations for type : UnityEngine.NetworkView

		//UnityEngine.NetworkView UnityEngine.NetworkView::INTERNAL_CALL_Find(UnityEngine.NetworkViewID&)
		void Register_UnityEngine_NetworkView_INTERNAL_CALL_Find();
		Register_UnityEngine_NetworkView_INTERNAL_CALL_Find();

	//End Registrations for type : UnityEngine.NetworkView

	//Start Registrations for type : UnityEngine.NetworkViewID

		//System.Boolean UnityEngine.NetworkViewID::INTERNAL_CALL_Internal_Compare(UnityEngine.NetworkViewID&,UnityEngine.NetworkViewID&)
		void Register_UnityEngine_NetworkViewID_INTERNAL_CALL_Internal_Compare();
		Register_UnityEngine_NetworkViewID_INTERNAL_CALL_Internal_Compare();

		//System.Boolean UnityEngine.NetworkViewID::INTERNAL_CALL_Internal_IsMine(UnityEngine.NetworkViewID&)
		void Register_UnityEngine_NetworkViewID_INTERNAL_CALL_Internal_IsMine();
		Register_UnityEngine_NetworkViewID_INTERNAL_CALL_Internal_IsMine();

		//System.String UnityEngine.NetworkViewID::INTERNAL_CALL_Internal_GetString(UnityEngine.NetworkViewID&)
		void Register_UnityEngine_NetworkViewID_INTERNAL_CALL_Internal_GetString();
		Register_UnityEngine_NetworkViewID_INTERNAL_CALL_Internal_GetString();

		//System.Void UnityEngine.NetworkViewID::INTERNAL_CALL_Internal_GetOwner(UnityEngine.NetworkViewID&,UnityEngine.NetworkPlayer&)
		void Register_UnityEngine_NetworkViewID_INTERNAL_CALL_Internal_GetOwner();
		Register_UnityEngine_NetworkViewID_INTERNAL_CALL_Internal_GetOwner();

		//System.Void UnityEngine.NetworkViewID::INTERNAL_get_unassigned(UnityEngine.NetworkViewID&)
		void Register_UnityEngine_NetworkViewID_INTERNAL_get_unassigned();
		Register_UnityEngine_NetworkViewID_INTERNAL_get_unassigned();

	//End Registrations for type : UnityEngine.NetworkViewID

	//Start Registrations for type : UnityEngine.Object

		//System.Boolean UnityEngine.Object::DoesObjectWithInstanceIDExist(System.Int32)
		void Register_UnityEngine_Object_DoesObjectWithInstanceIDExist();
		Register_UnityEngine_Object_DoesObjectWithInstanceIDExist();

		//System.Int32 UnityEngine.Object::GetOffsetOfInstanceIDInCPlusPlusObject()
		void Register_UnityEngine_Object_GetOffsetOfInstanceIDInCPlusPlusObject();
		Register_UnityEngine_Object_GetOffsetOfInstanceIDInCPlusPlusObject();

		//System.String UnityEngine.Object::ToString()
		void Register_UnityEngine_Object_ToString();
		Register_UnityEngine_Object_ToString();

		//System.String UnityEngine.Object::get_name()
		void Register_UnityEngine_Object_get_name();
		Register_UnityEngine_Object_get_name();

		//System.Void UnityEngine.Object::Destroy(UnityEngine.Object,System.Single)
		void Register_UnityEngine_Object_Destroy();
		Register_UnityEngine_Object_Destroy();

		//System.Void UnityEngine.Object::DestroyImmediate(UnityEngine.Object,System.Boolean)
		void Register_UnityEngine_Object_DestroyImmediate();
		Register_UnityEngine_Object_DestroyImmediate();

		//System.Void UnityEngine.Object::DestroyObject(UnityEngine.Object,System.Single)
		void Register_UnityEngine_Object_DestroyObject();
		Register_UnityEngine_Object_DestroyObject();

		//System.Void UnityEngine.Object::DontDestroyOnLoad(UnityEngine.Object)
		void Register_UnityEngine_Object_DontDestroyOnLoad();
		Register_UnityEngine_Object_DontDestroyOnLoad();

		//System.Void UnityEngine.Object::EnsureRunningOnMainThread()
		void Register_UnityEngine_Object_EnsureRunningOnMainThread();
		Register_UnityEngine_Object_EnsureRunningOnMainThread();

		//System.Void UnityEngine.Object::set_hideFlags(UnityEngine.HideFlags)
		void Register_UnityEngine_Object_set_hideFlags();
		Register_UnityEngine_Object_set_hideFlags();

		//System.Void UnityEngine.Object::set_name(System.String)
		void Register_UnityEngine_Object_set_name();
		Register_UnityEngine_Object_set_name();

		//UnityEngine.HideFlags UnityEngine.Object::get_hideFlags()
		void Register_UnityEngine_Object_get_hideFlags();
		Register_UnityEngine_Object_get_hideFlags();

		//UnityEngine.Object UnityEngine.Object::INTERNAL_CALL_Internal_InstantiateSingle(UnityEngine.Object,UnityEngine.Vector3&,UnityEngine.Quaternion&)
		void Register_UnityEngine_Object_INTERNAL_CALL_Internal_InstantiateSingle();
		Register_UnityEngine_Object_INTERNAL_CALL_Internal_InstantiateSingle();

		//UnityEngine.Object UnityEngine.Object::INTERNAL_CALL_Internal_InstantiateSingleWithParent(UnityEngine.Object,UnityEngine.Transform,UnityEngine.Vector3&,UnityEngine.Quaternion&)
		void Register_UnityEngine_Object_INTERNAL_CALL_Internal_InstantiateSingleWithParent();
		Register_UnityEngine_Object_INTERNAL_CALL_Internal_InstantiateSingleWithParent();

		//UnityEngine.Object UnityEngine.Object::Internal_CloneSingle(UnityEngine.Object)
		void Register_UnityEngine_Object_Internal_CloneSingle();
		Register_UnityEngine_Object_Internal_CloneSingle();

		//UnityEngine.Object UnityEngine.Object::Internal_CloneSingleWithParent(UnityEngine.Object,UnityEngine.Transform,System.Boolean)
		void Register_UnityEngine_Object_Internal_CloneSingleWithParent();
		Register_UnityEngine_Object_Internal_CloneSingleWithParent();

		//UnityEngine.Object[] UnityEngine.Object::FindObjectsOfType(System.Type)
		void Register_UnityEngine_Object_FindObjectsOfType();
		Register_UnityEngine_Object_FindObjectsOfType();

		//UnityEngine.Object[] UnityEngine.Object::FindObjectsOfTypeIncludingAssets(System.Type)
		void Register_UnityEngine_Object_FindObjectsOfTypeIncludingAssets();
		Register_UnityEngine_Object_FindObjectsOfTypeIncludingAssets();

		//UnityEngine.Object[] UnityEngine.Object::FindSceneObjectsOfType(System.Type)
		void Register_UnityEngine_Object_FindSceneObjectsOfType();
		Register_UnityEngine_Object_FindSceneObjectsOfType();

	//End Registrations for type : UnityEngine.Object

	//Start Registrations for type : UnityEngine.Physics

		//System.Boolean UnityEngine.Physics::INTERNAL_CALL_Internal_Raycast(UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.RaycastHit&,System.Single,System.Int32,UnityEngine.QueryTriggerInteraction)
		void Register_UnityEngine_Physics_INTERNAL_CALL_Internal_Raycast();
		Register_UnityEngine_Physics_INTERNAL_CALL_Internal_Raycast();

		//System.Boolean UnityEngine.Physics::INTERNAL_CALL_Internal_RaycastTest(UnityEngine.Vector3&,UnityEngine.Vector3&,System.Single,System.Int32,UnityEngine.QueryTriggerInteraction)
		void Register_UnityEngine_Physics_INTERNAL_CALL_Internal_RaycastTest();
		Register_UnityEngine_Physics_INTERNAL_CALL_Internal_RaycastTest();

		//UnityEngine.Collider[] UnityEngine.Physics::INTERNAL_CALL_OverlapSphere(UnityEngine.Vector3&,System.Single,System.Int32,UnityEngine.QueryTriggerInteraction)
		void Register_UnityEngine_Physics_INTERNAL_CALL_OverlapSphere();
		Register_UnityEngine_Physics_INTERNAL_CALL_OverlapSphere();

		//UnityEngine.RaycastHit[] UnityEngine.Physics::INTERNAL_CALL_RaycastAll(UnityEngine.Vector3&,UnityEngine.Vector3&,System.Single,System.Int32,UnityEngine.QueryTriggerInteraction)
		void Register_UnityEngine_Physics_INTERNAL_CALL_RaycastAll();
		Register_UnityEngine_Physics_INTERNAL_CALL_RaycastAll();

	//End Registrations for type : UnityEngine.Physics

	//Start Registrations for type : UnityEngine.Physics2D

		//System.Void UnityEngine.Physics2D::INTERNAL_CALL_Internal_Raycast(UnityEngine.Vector2&,UnityEngine.Vector2&,System.Single,System.Int32,System.Single,System.Single,UnityEngine.RaycastHit2D&)
		void Register_UnityEngine_Physics2D_INTERNAL_CALL_Internal_Raycast();
		Register_UnityEngine_Physics2D_INTERNAL_CALL_Internal_Raycast();

		//UnityEngine.Collider2D[] UnityEngine.Physics2D::INTERNAL_CALL_OverlapCircleAll(UnityEngine.Vector2&,System.Single,System.Int32,System.Single,System.Single)
		void Register_UnityEngine_Physics2D_INTERNAL_CALL_OverlapCircleAll();
		Register_UnityEngine_Physics2D_INTERNAL_CALL_OverlapCircleAll();

		//UnityEngine.RaycastHit2D[] UnityEngine.Physics2D::INTERNAL_CALL_GetRayIntersectionAll(UnityEngine.Ray&,System.Single,System.Int32)
		void Register_UnityEngine_Physics2D_INTERNAL_CALL_GetRayIntersectionAll();
		Register_UnityEngine_Physics2D_INTERNAL_CALL_GetRayIntersectionAll();

	//End Registrations for type : UnityEngine.Physics2D

	//Start Registrations for type : UnityEngine.Ping

		//System.Boolean UnityEngine.Ping::get_isDone()
		void Register_UnityEngine_Ping_get_isDone();
		Register_UnityEngine_Ping_get_isDone();

		//System.Int32 UnityEngine.Ping::get_time()
		void Register_UnityEngine_Ping_get_time();
		Register_UnityEngine_Ping_get_time();

		//System.String UnityEngine.Ping::get_ip()
		void Register_UnityEngine_Ping_get_ip();
		Register_UnityEngine_Ping_get_ip();

		//System.Void UnityEngine.Ping::.ctor(System.String)
		void Register_UnityEngine_Ping__ctor();
		Register_UnityEngine_Ping__ctor();

		//System.Void UnityEngine.Ping::DestroyPing()
		void Register_UnityEngine_Ping_DestroyPing();
		Register_UnityEngine_Ping_DestroyPing();

	//End Registrations for type : UnityEngine.Ping

	//Start Registrations for type : UnityEngine.Quaternion

		//System.Void UnityEngine.Quaternion::INTERNAL_CALL_AngleAxis(System.Single,UnityEngine.Vector3&,UnityEngine.Quaternion&)
		void Register_UnityEngine_Quaternion_INTERNAL_CALL_AngleAxis();
		Register_UnityEngine_Quaternion_INTERNAL_CALL_AngleAxis();

		//System.Void UnityEngine.Quaternion::INTERNAL_CALL_FromToRotation(UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Quaternion&)
		void Register_UnityEngine_Quaternion_INTERNAL_CALL_FromToRotation();
		Register_UnityEngine_Quaternion_INTERNAL_CALL_FromToRotation();

		//System.Void UnityEngine.Quaternion::INTERNAL_CALL_Internal_FromEulerRad(UnityEngine.Vector3&,UnityEngine.Quaternion&)
		void Register_UnityEngine_Quaternion_INTERNAL_CALL_Internal_FromEulerRad();
		Register_UnityEngine_Quaternion_INTERNAL_CALL_Internal_FromEulerRad();

		//System.Void UnityEngine.Quaternion::INTERNAL_CALL_Internal_ToEulerRad(UnityEngine.Quaternion&,UnityEngine.Vector3&)
		void Register_UnityEngine_Quaternion_INTERNAL_CALL_Internal_ToEulerRad();
		Register_UnityEngine_Quaternion_INTERNAL_CALL_Internal_ToEulerRad();

		//System.Void UnityEngine.Quaternion::INTERNAL_CALL_Inverse(UnityEngine.Quaternion&,UnityEngine.Quaternion&)
		void Register_UnityEngine_Quaternion_INTERNAL_CALL_Inverse();
		Register_UnityEngine_Quaternion_INTERNAL_CALL_Inverse();

		//System.Void UnityEngine.Quaternion::INTERNAL_CALL_LookRotation(UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Quaternion&)
		void Register_UnityEngine_Quaternion_INTERNAL_CALL_LookRotation();
		Register_UnityEngine_Quaternion_INTERNAL_CALL_LookRotation();

		//System.Void UnityEngine.Quaternion::INTERNAL_CALL_Slerp(UnityEngine.Quaternion&,UnityEngine.Quaternion&,System.Single,UnityEngine.Quaternion&)
		void Register_UnityEngine_Quaternion_INTERNAL_CALL_Slerp();
		Register_UnityEngine_Quaternion_INTERNAL_CALL_Slerp();

	//End Registrations for type : UnityEngine.Quaternion

	//Start Registrations for type : UnityEngine.Random

		//System.Int32 UnityEngine.Random::RandomRangeInt(System.Int32,System.Int32)
		void Register_UnityEngine_Random_RandomRangeInt();
		Register_UnityEngine_Random_RandomRangeInt();

		//System.Single UnityEngine.Random::Range(System.Single,System.Single)
		void Register_UnityEngine_Random_Range();
		Register_UnityEngine_Random_Range();

	//End Registrations for type : UnityEngine.Random

	//Start Registrations for type : UnityEngine.RectOffset

		//System.Int32 UnityEngine.RectOffset::get_bottom()
		void Register_UnityEngine_RectOffset_get_bottom();
		Register_UnityEngine_RectOffset_get_bottom();

		//System.Int32 UnityEngine.RectOffset::get_horizontal()
		void Register_UnityEngine_RectOffset_get_horizontal();
		Register_UnityEngine_RectOffset_get_horizontal();

		//System.Int32 UnityEngine.RectOffset::get_left()
		void Register_UnityEngine_RectOffset_get_left();
		Register_UnityEngine_RectOffset_get_left();

		//System.Int32 UnityEngine.RectOffset::get_right()
		void Register_UnityEngine_RectOffset_get_right();
		Register_UnityEngine_RectOffset_get_right();

		//System.Int32 UnityEngine.RectOffset::get_top()
		void Register_UnityEngine_RectOffset_get_top();
		Register_UnityEngine_RectOffset_get_top();

		//System.Int32 UnityEngine.RectOffset::get_vertical()
		void Register_UnityEngine_RectOffset_get_vertical();
		Register_UnityEngine_RectOffset_get_vertical();

		//System.Void UnityEngine.RectOffset::Cleanup()
		void Register_UnityEngine_RectOffset_Cleanup();
		Register_UnityEngine_RectOffset_Cleanup();

		//System.Void UnityEngine.RectOffset::INTERNAL_CALL_Add(UnityEngine.RectOffset,UnityEngine.Rect&,UnityEngine.Rect&)
		void Register_UnityEngine_RectOffset_INTERNAL_CALL_Add();
		Register_UnityEngine_RectOffset_INTERNAL_CALL_Add();

		//System.Void UnityEngine.RectOffset::INTERNAL_CALL_Remove(UnityEngine.RectOffset,UnityEngine.Rect&,UnityEngine.Rect&)
		void Register_UnityEngine_RectOffset_INTERNAL_CALL_Remove();
		Register_UnityEngine_RectOffset_INTERNAL_CALL_Remove();

		//System.Void UnityEngine.RectOffset::Init()
		void Register_UnityEngine_RectOffset_Init();
		Register_UnityEngine_RectOffset_Init();

		//System.Void UnityEngine.RectOffset::set_bottom(System.Int32)
		void Register_UnityEngine_RectOffset_set_bottom();
		Register_UnityEngine_RectOffset_set_bottom();

		//System.Void UnityEngine.RectOffset::set_left(System.Int32)
		void Register_UnityEngine_RectOffset_set_left();
		Register_UnityEngine_RectOffset_set_left();

		//System.Void UnityEngine.RectOffset::set_right(System.Int32)
		void Register_UnityEngine_RectOffset_set_right();
		Register_UnityEngine_RectOffset_set_right();

		//System.Void UnityEngine.RectOffset::set_top(System.Int32)
		void Register_UnityEngine_RectOffset_set_top();
		Register_UnityEngine_RectOffset_set_top();

	//End Registrations for type : UnityEngine.RectOffset

	//Start Registrations for type : UnityEngine.RectTransform

		//System.Void UnityEngine.RectTransform::INTERNAL_get_anchorMax(UnityEngine.Vector2&)
		void Register_UnityEngine_RectTransform_INTERNAL_get_anchorMax();
		Register_UnityEngine_RectTransform_INTERNAL_get_anchorMax();

		//System.Void UnityEngine.RectTransform::INTERNAL_get_anchorMin(UnityEngine.Vector2&)
		void Register_UnityEngine_RectTransform_INTERNAL_get_anchorMin();
		Register_UnityEngine_RectTransform_INTERNAL_get_anchorMin();

		//System.Void UnityEngine.RectTransform::INTERNAL_get_anchoredPosition(UnityEngine.Vector2&)
		void Register_UnityEngine_RectTransform_INTERNAL_get_anchoredPosition();
		Register_UnityEngine_RectTransform_INTERNAL_get_anchoredPosition();

		//System.Void UnityEngine.RectTransform::INTERNAL_get_pivot(UnityEngine.Vector2&)
		void Register_UnityEngine_RectTransform_INTERNAL_get_pivot();
		Register_UnityEngine_RectTransform_INTERNAL_get_pivot();

		//System.Void UnityEngine.RectTransform::INTERNAL_get_rect(UnityEngine.Rect&)
		void Register_UnityEngine_RectTransform_INTERNAL_get_rect();
		Register_UnityEngine_RectTransform_INTERNAL_get_rect();

		//System.Void UnityEngine.RectTransform::INTERNAL_get_sizeDelta(UnityEngine.Vector2&)
		void Register_UnityEngine_RectTransform_INTERNAL_get_sizeDelta();
		Register_UnityEngine_RectTransform_INTERNAL_get_sizeDelta();

		//System.Void UnityEngine.RectTransform::INTERNAL_set_anchorMax(UnityEngine.Vector2&)
		void Register_UnityEngine_RectTransform_INTERNAL_set_anchorMax();
		Register_UnityEngine_RectTransform_INTERNAL_set_anchorMax();

		//System.Void UnityEngine.RectTransform::INTERNAL_set_anchorMin(UnityEngine.Vector2&)
		void Register_UnityEngine_RectTransform_INTERNAL_set_anchorMin();
		Register_UnityEngine_RectTransform_INTERNAL_set_anchorMin();

		//System.Void UnityEngine.RectTransform::INTERNAL_set_anchoredPosition(UnityEngine.Vector2&)
		void Register_UnityEngine_RectTransform_INTERNAL_set_anchoredPosition();
		Register_UnityEngine_RectTransform_INTERNAL_set_anchoredPosition();

		//System.Void UnityEngine.RectTransform::INTERNAL_set_pivot(UnityEngine.Vector2&)
		void Register_UnityEngine_RectTransform_INTERNAL_set_pivot();
		Register_UnityEngine_RectTransform_INTERNAL_set_pivot();

		//System.Void UnityEngine.RectTransform::INTERNAL_set_sizeDelta(UnityEngine.Vector2&)
		void Register_UnityEngine_RectTransform_INTERNAL_set_sizeDelta();
		Register_UnityEngine_RectTransform_INTERNAL_set_sizeDelta();

		//System.Void UnityEngine.RectTransform::set_drivenByObject(UnityEngine.Object)
		void Register_UnityEngine_RectTransform_set_drivenByObject();
		Register_UnityEngine_RectTransform_set_drivenByObject();

		//System.Void UnityEngine.RectTransform::set_drivenProperties(UnityEngine.DrivenTransformProperties)
		void Register_UnityEngine_RectTransform_set_drivenProperties();
		Register_UnityEngine_RectTransform_set_drivenProperties();

		//UnityEngine.DrivenTransformProperties UnityEngine.RectTransform::get_drivenProperties()
		void Register_UnityEngine_RectTransform_get_drivenProperties();
		Register_UnityEngine_RectTransform_get_drivenProperties();

		//UnityEngine.Object UnityEngine.RectTransform::get_drivenByObject()
		void Register_UnityEngine_RectTransform_get_drivenByObject();
		Register_UnityEngine_RectTransform_get_drivenByObject();

	//End Registrations for type : UnityEngine.RectTransform

	//Start Registrations for type : UnityEngine.RectTransformUtility

		//System.Boolean UnityEngine.RectTransformUtility::INTERNAL_CALL_RectangleContainsScreenPoint(UnityEngine.RectTransform,UnityEngine.Vector2&,UnityEngine.Camera)
		void Register_UnityEngine_RectTransformUtility_INTERNAL_CALL_RectangleContainsScreenPoint();
		Register_UnityEngine_RectTransformUtility_INTERNAL_CALL_RectangleContainsScreenPoint();

		//System.Void UnityEngine.RectTransformUtility::INTERNAL_CALL_PixelAdjustPoint(UnityEngine.Vector2&,UnityEngine.Transform,UnityEngine.Canvas,UnityEngine.Vector2&)
		void Register_UnityEngine_RectTransformUtility_INTERNAL_CALL_PixelAdjustPoint();
		Register_UnityEngine_RectTransformUtility_INTERNAL_CALL_PixelAdjustPoint();

		//System.Void UnityEngine.RectTransformUtility::INTERNAL_CALL_PixelAdjustRect(UnityEngine.RectTransform,UnityEngine.Canvas,UnityEngine.Rect&)
		void Register_UnityEngine_RectTransformUtility_INTERNAL_CALL_PixelAdjustRect();
		Register_UnityEngine_RectTransformUtility_INTERNAL_CALL_PixelAdjustRect();

	//End Registrations for type : UnityEngine.RectTransformUtility

	//Start Registrations for type : UnityEngine.Renderer

		//System.Int32 UnityEngine.Renderer::get_sortingLayerID()
		void Register_UnityEngine_Renderer_get_sortingLayerID();
		Register_UnityEngine_Renderer_get_sortingLayerID();

		//System.Int32 UnityEngine.Renderer::get_sortingOrder()
		void Register_UnityEngine_Renderer_get_sortingOrder();
		Register_UnityEngine_Renderer_get_sortingOrder();

		//System.Void UnityEngine.Renderer::set_enabled(System.Boolean)
		void Register_UnityEngine_Renderer_set_enabled();
		Register_UnityEngine_Renderer_set_enabled();

		//UnityEngine.Material UnityEngine.Renderer::get_material()
		void Register_UnityEngine_Renderer_get_material();
		Register_UnityEngine_Renderer_get_material();

		//UnityEngine.Material[] UnityEngine.Renderer::get_materials()
		void Register_UnityEngine_Renderer_get_materials();
		Register_UnityEngine_Renderer_get_materials();

	//End Registrations for type : UnityEngine.Renderer

	//Start Registrations for type : UnityEngine.Rendering.CommandBuffer

		//System.Void UnityEngine.Rendering.CommandBuffer::ReleaseBuffer()
		void Register_UnityEngine_Rendering_CommandBuffer_ReleaseBuffer();
		Register_UnityEngine_Rendering_CommandBuffer_ReleaseBuffer();

	//End Registrations for type : UnityEngine.Rendering.CommandBuffer

	//Start Registrations for type : UnityEngine.Rendering.SplashScreen

		//System.Boolean UnityEngine.Rendering.SplashScreen::get_isFinished()
		void Register_UnityEngine_Rendering_SplashScreen_get_isFinished();
		Register_UnityEngine_Rendering_SplashScreen_get_isFinished();

	//End Registrations for type : UnityEngine.Rendering.SplashScreen

	//Start Registrations for type : UnityEngine.RenderSettings

		//System.Void UnityEngine.RenderSettings::INTERNAL_set_ambientGroundColor(UnityEngine.Color&)
		void Register_UnityEngine_RenderSettings_INTERNAL_set_ambientGroundColor();
		Register_UnityEngine_RenderSettings_INTERNAL_set_ambientGroundColor();

	//End Registrations for type : UnityEngine.RenderSettings

	//Start Registrations for type : UnityEngine.RenderTexture

		//System.Int32 UnityEngine.RenderTexture::Internal_GetHeight(UnityEngine.RenderTexture)
		void Register_UnityEngine_RenderTexture_Internal_GetHeight();
		Register_UnityEngine_RenderTexture_Internal_GetHeight();

		//System.Int32 UnityEngine.RenderTexture::Internal_GetWidth(UnityEngine.RenderTexture)
		void Register_UnityEngine_RenderTexture_Internal_GetWidth();
		Register_UnityEngine_RenderTexture_Internal_GetWidth();

	//End Registrations for type : UnityEngine.RenderTexture

	//Start Registrations for type : UnityEngine.Resources

		//System.Void UnityEngine.Resources::UnloadAsset(UnityEngine.Object)
		void Register_UnityEngine_Resources_UnloadAsset();
		Register_UnityEngine_Resources_UnloadAsset();

		//UnityEngine.AsyncOperation UnityEngine.Resources::UnloadUnusedAssets()
		void Register_UnityEngine_Resources_UnloadUnusedAssets();
		Register_UnityEngine_Resources_UnloadUnusedAssets();

		//UnityEngine.Object UnityEngine.Resources::GetBuiltinResource(System.Type,System.String)
		void Register_UnityEngine_Resources_GetBuiltinResource();
		Register_UnityEngine_Resources_GetBuiltinResource();

		//UnityEngine.Object UnityEngine.Resources::Load(System.String,System.Type)
		void Register_UnityEngine_Resources_Load();
		Register_UnityEngine_Resources_Load();

		//UnityEngine.Object[] UnityEngine.Resources::FindObjectsOfTypeAll(System.Type)
		void Register_UnityEngine_Resources_FindObjectsOfTypeAll();
		Register_UnityEngine_Resources_FindObjectsOfTypeAll();

		//UnityEngine.Object[] UnityEngine.Resources::LoadAll(System.String,System.Type)
		void Register_UnityEngine_Resources_LoadAll();
		Register_UnityEngine_Resources_LoadAll();

		//UnityEngine.ResourceRequest UnityEngine.Resources::LoadAsync(System.String,System.Type)
		void Register_UnityEngine_Resources_LoadAsync();
		Register_UnityEngine_Resources_LoadAsync();

	//End Registrations for type : UnityEngine.Resources

	//Start Registrations for type : UnityEngine.Rigidbody

		//System.Void UnityEngine.Rigidbody::INTERNAL_CALL_AddForce(UnityEngine.Rigidbody,UnityEngine.Vector3&,UnityEngine.ForceMode)
		void Register_UnityEngine_Rigidbody_INTERNAL_CALL_AddForce();
		Register_UnityEngine_Rigidbody_INTERNAL_CALL_AddForce();

		//System.Void UnityEngine.Rigidbody::INTERNAL_CALL_AddRelativeForce(UnityEngine.Rigidbody,UnityEngine.Vector3&,UnityEngine.ForceMode)
		void Register_UnityEngine_Rigidbody_INTERNAL_CALL_AddRelativeForce();
		Register_UnityEngine_Rigidbody_INTERNAL_CALL_AddRelativeForce();

		//System.Void UnityEngine.Rigidbody::INTERNAL_CALL_MovePosition(UnityEngine.Rigidbody,UnityEngine.Vector3&)
		void Register_UnityEngine_Rigidbody_INTERNAL_CALL_MovePosition();
		Register_UnityEngine_Rigidbody_INTERNAL_CALL_MovePosition();

		//System.Void UnityEngine.Rigidbody::INTERNAL_CALL_MoveRotation(UnityEngine.Rigidbody,UnityEngine.Quaternion&)
		void Register_UnityEngine_Rigidbody_INTERNAL_CALL_MoveRotation();
		Register_UnityEngine_Rigidbody_INTERNAL_CALL_MoveRotation();

		//System.Void UnityEngine.Rigidbody::INTERNAL_get_angularVelocity(UnityEngine.Vector3&)
		void Register_UnityEngine_Rigidbody_INTERNAL_get_angularVelocity();
		Register_UnityEngine_Rigidbody_INTERNAL_get_angularVelocity();

		//System.Void UnityEngine.Rigidbody::INTERNAL_get_position(UnityEngine.Vector3&)
		void Register_UnityEngine_Rigidbody_INTERNAL_get_position();
		Register_UnityEngine_Rigidbody_INTERNAL_get_position();

		//System.Void UnityEngine.Rigidbody::INTERNAL_get_rotation(UnityEngine.Quaternion&)
		void Register_UnityEngine_Rigidbody_INTERNAL_get_rotation();
		Register_UnityEngine_Rigidbody_INTERNAL_get_rotation();

		//System.Void UnityEngine.Rigidbody::INTERNAL_get_velocity(UnityEngine.Vector3&)
		void Register_UnityEngine_Rigidbody_INTERNAL_get_velocity();
		Register_UnityEngine_Rigidbody_INTERNAL_get_velocity();

		//System.Void UnityEngine.Rigidbody::INTERNAL_set_angularVelocity(UnityEngine.Vector3&)
		void Register_UnityEngine_Rigidbody_INTERNAL_set_angularVelocity();
		Register_UnityEngine_Rigidbody_INTERNAL_set_angularVelocity();

		//System.Void UnityEngine.Rigidbody::INTERNAL_set_position(UnityEngine.Vector3&)
		void Register_UnityEngine_Rigidbody_INTERNAL_set_position();
		Register_UnityEngine_Rigidbody_INTERNAL_set_position();

		//System.Void UnityEngine.Rigidbody::INTERNAL_set_rotation(UnityEngine.Quaternion&)
		void Register_UnityEngine_Rigidbody_INTERNAL_set_rotation();
		Register_UnityEngine_Rigidbody_INTERNAL_set_rotation();

		//System.Void UnityEngine.Rigidbody::INTERNAL_set_velocity(UnityEngine.Vector3&)
		void Register_UnityEngine_Rigidbody_INTERNAL_set_velocity();
		Register_UnityEngine_Rigidbody_INTERNAL_set_velocity();

	//End Registrations for type : UnityEngine.Rigidbody

	//Start Registrations for type : UnityEngine.Rigidbody2D

		//System.Single UnityEngine.Rigidbody2D::get_angularVelocity()
		void Register_UnityEngine_Rigidbody2D_get_angularVelocity();
		Register_UnityEngine_Rigidbody2D_get_angularVelocity();

		//System.Single UnityEngine.Rigidbody2D::get_rotation()
		void Register_UnityEngine_Rigidbody2D_get_rotation();
		Register_UnityEngine_Rigidbody2D_get_rotation();

		//System.Void UnityEngine.Rigidbody2D::INTERNAL_CALL_MoveRotation(UnityEngine.Rigidbody2D,System.Single)
		void Register_UnityEngine_Rigidbody2D_INTERNAL_CALL_MoveRotation();
		Register_UnityEngine_Rigidbody2D_INTERNAL_CALL_MoveRotation();

		//System.Void UnityEngine.Rigidbody2D::INTERNAL_get_position(UnityEngine.Vector2&)
		void Register_UnityEngine_Rigidbody2D_INTERNAL_get_position();
		Register_UnityEngine_Rigidbody2D_INTERNAL_get_position();

		//System.Void UnityEngine.Rigidbody2D::INTERNAL_get_velocity(UnityEngine.Vector2&)
		void Register_UnityEngine_Rigidbody2D_INTERNAL_get_velocity();
		Register_UnityEngine_Rigidbody2D_INTERNAL_get_velocity();

		//System.Void UnityEngine.Rigidbody2D::INTERNAL_set_position(UnityEngine.Vector2&)
		void Register_UnityEngine_Rigidbody2D_INTERNAL_set_position();
		Register_UnityEngine_Rigidbody2D_INTERNAL_set_position();

		//System.Void UnityEngine.Rigidbody2D::INTERNAL_set_velocity(UnityEngine.Vector2&)
		void Register_UnityEngine_Rigidbody2D_INTERNAL_set_velocity();
		Register_UnityEngine_Rigidbody2D_INTERNAL_set_velocity();

		//System.Void UnityEngine.Rigidbody2D::set_angularVelocity(System.Single)
		void Register_UnityEngine_Rigidbody2D_set_angularVelocity();
		Register_UnityEngine_Rigidbody2D_set_angularVelocity();

		//System.Void UnityEngine.Rigidbody2D::set_rotation(System.Single)
		void Register_UnityEngine_Rigidbody2D_set_rotation();
		Register_UnityEngine_Rigidbody2D_set_rotation();

	//End Registrations for type : UnityEngine.Rigidbody2D

	//Start Registrations for type : UnityEngine.SceneManagement.Scene

		//System.Int32 UnityEngine.SceneManagement.Scene::GetBuildIndexInternal(System.Int32)
		void Register_UnityEngine_SceneManagement_Scene_GetBuildIndexInternal();
		Register_UnityEngine_SceneManagement_Scene_GetBuildIndexInternal();

		//System.String UnityEngine.SceneManagement.Scene::GetNameInternal(System.Int32)
		void Register_UnityEngine_SceneManagement_Scene_GetNameInternal();
		Register_UnityEngine_SceneManagement_Scene_GetNameInternal();

	//End Registrations for type : UnityEngine.SceneManagement.Scene

	//Start Registrations for type : UnityEngine.SceneManagement.SceneManager

		//System.Int32 UnityEngine.SceneManagement.SceneManager::get_sceneCountInBuildSettings()
		void Register_UnityEngine_SceneManagement_SceneManager_get_sceneCountInBuildSettings();
		Register_UnityEngine_SceneManagement_SceneManager_get_sceneCountInBuildSettings();

		//System.Void UnityEngine.SceneManagement.SceneManager::INTERNAL_CALL_GetActiveScene(UnityEngine.SceneManagement.Scene&)
		void Register_UnityEngine_SceneManagement_SceneManager_INTERNAL_CALL_GetActiveScene();
		Register_UnityEngine_SceneManagement_SceneManager_INTERNAL_CALL_GetActiveScene();

		//System.Void UnityEngine.SceneManagement.SceneManager::INTERNAL_CALL_GetSceneAt(System.Int32,UnityEngine.SceneManagement.Scene&)
		void Register_UnityEngine_SceneManagement_SceneManager_INTERNAL_CALL_GetSceneAt();
		Register_UnityEngine_SceneManagement_SceneManager_INTERNAL_CALL_GetSceneAt();

		//UnityEngine.AsyncOperation UnityEngine.SceneManagement.SceneManager::LoadSceneAsyncNameIndexInternal(System.String,System.Int32,System.Boolean,System.Boolean)
		void Register_UnityEngine_SceneManagement_SceneManager_LoadSceneAsyncNameIndexInternal();
		Register_UnityEngine_SceneManagement_SceneManager_LoadSceneAsyncNameIndexInternal();

		//UnityEngine.AsyncOperation UnityEngine.SceneManagement.SceneManager::UnloadSceneNameIndexInternal(System.String,System.Int32,System.Boolean,System.Boolean&)
		void Register_UnityEngine_SceneManagement_SceneManager_UnloadSceneNameIndexInternal();
		Register_UnityEngine_SceneManagement_SceneManager_UnloadSceneNameIndexInternal();

	//End Registrations for type : UnityEngine.SceneManagement.SceneManager

	//Start Registrations for type : UnityEngine.Screen

		//System.Int32 UnityEngine.Screen::get_height()
		void Register_UnityEngine_Screen_get_height();
		Register_UnityEngine_Screen_get_height();

		//System.Int32 UnityEngine.Screen::get_width()
		void Register_UnityEngine_Screen_get_width();
		Register_UnityEngine_Screen_get_width();

		//System.Single UnityEngine.Screen::get_dpi()
		void Register_UnityEngine_Screen_get_dpi();
		Register_UnityEngine_Screen_get_dpi();

	//End Registrations for type : UnityEngine.Screen

	//Start Registrations for type : UnityEngine.ScriptableObject

		//System.Void UnityEngine.ScriptableObject::INTERNAL_CALL_SetDirty(UnityEngine.ScriptableObject)
		void Register_UnityEngine_ScriptableObject_INTERNAL_CALL_SetDirty();
		Register_UnityEngine_ScriptableObject_INTERNAL_CALL_SetDirty();

		//System.Void UnityEngine.ScriptableObject::Internal_CreateScriptableObject(UnityEngine.ScriptableObject)
		void Register_UnityEngine_ScriptableObject_Internal_CreateScriptableObject();
		Register_UnityEngine_ScriptableObject_Internal_CreateScriptableObject();

		//UnityEngine.ScriptableObject UnityEngine.ScriptableObject::CreateInstance(System.String)
		void Register_UnityEngine_ScriptableObject_CreateInstance();
		Register_UnityEngine_ScriptableObject_CreateInstance();

		//UnityEngine.ScriptableObject UnityEngine.ScriptableObject::CreateInstanceFromType(System.Type)
		void Register_UnityEngine_ScriptableObject_CreateInstanceFromType();
		Register_UnityEngine_ScriptableObject_CreateInstanceFromType();

	//End Registrations for type : UnityEngine.ScriptableObject

	//Start Registrations for type : UnityEngine.Shader

		//System.Int32 UnityEngine.Shader::PropertyToID(System.String)
		void Register_UnityEngine_Shader_PropertyToID();
		Register_UnityEngine_Shader_PropertyToID();

		//UnityEngine.Shader UnityEngine.Shader::Find(System.String)
		void Register_UnityEngine_Shader_Find();
		Register_UnityEngine_Shader_Find();

	//End Registrations for type : UnityEngine.Shader

	//Start Registrations for type : UnityEngine.SkinnedMeshRenderer

		//System.Boolean UnityEngine.SkinnedMeshRenderer::get_skinnedMotionVectors()
		void Register_UnityEngine_SkinnedMeshRenderer_get_skinnedMotionVectors();
		Register_UnityEngine_SkinnedMeshRenderer_get_skinnedMotionVectors();

		//System.Boolean UnityEngine.SkinnedMeshRenderer::get_updateWhenOffscreen()
		void Register_UnityEngine_SkinnedMeshRenderer_get_updateWhenOffscreen();
		Register_UnityEngine_SkinnedMeshRenderer_get_updateWhenOffscreen();

		//System.Single UnityEngine.SkinnedMeshRenderer::GetBlendShapeWeight(System.Int32)
		void Register_UnityEngine_SkinnedMeshRenderer_GetBlendShapeWeight();
		Register_UnityEngine_SkinnedMeshRenderer_GetBlendShapeWeight();

		//System.Void UnityEngine.SkinnedMeshRenderer::BakeMesh(UnityEngine.Mesh)
		void Register_UnityEngine_SkinnedMeshRenderer_BakeMesh();
		Register_UnityEngine_SkinnedMeshRenderer_BakeMesh();

		//System.Void UnityEngine.SkinnedMeshRenderer::INTERNAL_get_localBounds(UnityEngine.Bounds&)
		void Register_UnityEngine_SkinnedMeshRenderer_INTERNAL_get_localBounds();
		Register_UnityEngine_SkinnedMeshRenderer_INTERNAL_get_localBounds();

		//System.Void UnityEngine.SkinnedMeshRenderer::INTERNAL_set_localBounds(UnityEngine.Bounds&)
		void Register_UnityEngine_SkinnedMeshRenderer_INTERNAL_set_localBounds();
		Register_UnityEngine_SkinnedMeshRenderer_INTERNAL_set_localBounds();

		//System.Void UnityEngine.SkinnedMeshRenderer::SetBlendShapeWeight(System.Int32,System.Single)
		void Register_UnityEngine_SkinnedMeshRenderer_SetBlendShapeWeight();
		Register_UnityEngine_SkinnedMeshRenderer_SetBlendShapeWeight();

		//System.Void UnityEngine.SkinnedMeshRenderer::set_bones(UnityEngine.Transform[])
		void Register_UnityEngine_SkinnedMeshRenderer_set_bones();
		Register_UnityEngine_SkinnedMeshRenderer_set_bones();

		//System.Void UnityEngine.SkinnedMeshRenderer::set_quality(UnityEngine.SkinQuality)
		void Register_UnityEngine_SkinnedMeshRenderer_set_quality();
		Register_UnityEngine_SkinnedMeshRenderer_set_quality();

		//System.Void UnityEngine.SkinnedMeshRenderer::set_rootBone(UnityEngine.Transform)
		void Register_UnityEngine_SkinnedMeshRenderer_set_rootBone();
		Register_UnityEngine_SkinnedMeshRenderer_set_rootBone();

		//System.Void UnityEngine.SkinnedMeshRenderer::set_sharedMesh(UnityEngine.Mesh)
		void Register_UnityEngine_SkinnedMeshRenderer_set_sharedMesh();
		Register_UnityEngine_SkinnedMeshRenderer_set_sharedMesh();

		//System.Void UnityEngine.SkinnedMeshRenderer::set_skinnedMotionVectors(System.Boolean)
		void Register_UnityEngine_SkinnedMeshRenderer_set_skinnedMotionVectors();
		Register_UnityEngine_SkinnedMeshRenderer_set_skinnedMotionVectors();

		//System.Void UnityEngine.SkinnedMeshRenderer::set_updateWhenOffscreen(System.Boolean)
		void Register_UnityEngine_SkinnedMeshRenderer_set_updateWhenOffscreen();
		Register_UnityEngine_SkinnedMeshRenderer_set_updateWhenOffscreen();

		//UnityEngine.Mesh UnityEngine.SkinnedMeshRenderer::get_sharedMesh()
		void Register_UnityEngine_SkinnedMeshRenderer_get_sharedMesh();
		Register_UnityEngine_SkinnedMeshRenderer_get_sharedMesh();

		//UnityEngine.SkinQuality UnityEngine.SkinnedMeshRenderer::get_quality()
		void Register_UnityEngine_SkinnedMeshRenderer_get_quality();
		Register_UnityEngine_SkinnedMeshRenderer_get_quality();

		//UnityEngine.Transform UnityEngine.SkinnedMeshRenderer::get_rootBone()
		void Register_UnityEngine_SkinnedMeshRenderer_get_rootBone();
		Register_UnityEngine_SkinnedMeshRenderer_get_rootBone();

		//UnityEngine.Transform[] UnityEngine.SkinnedMeshRenderer::get_bones()
		void Register_UnityEngine_SkinnedMeshRenderer_get_bones();
		Register_UnityEngine_SkinnedMeshRenderer_get_bones();

	//End Registrations for type : UnityEngine.SkinnedMeshRenderer

	//Start Registrations for type : UnityEngine.SocialPlatforms.GameCenter.GameCenterPlatform

		//System.Boolean UnityEngine.SocialPlatforms.GameCenter.GameCenterPlatform::Internal_Authenticated()
		void Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_Authenticated();
		Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_Authenticated();

		//System.Boolean UnityEngine.SocialPlatforms.GameCenter.GameCenterPlatform::Internal_Underage()
		void Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_Underage();
		Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_Underage();

		//System.String UnityEngine.SocialPlatforms.GameCenter.GameCenterPlatform::Internal_UserID()
		void Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_UserID();
		Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_UserID();

		//System.String UnityEngine.SocialPlatforms.GameCenter.GameCenterPlatform::Internal_UserName()
		void Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_UserName();
		Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_UserName();

		//System.Void UnityEngine.SocialPlatforms.GameCenter.GameCenterPlatform::Internal_Authenticate()
		void Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_Authenticate();
		Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_Authenticate();

		//System.Void UnityEngine.SocialPlatforms.GameCenter.GameCenterPlatform::Internal_LoadAchievementDescriptions(System.Object)
		void Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_LoadAchievementDescriptions();
		Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_LoadAchievementDescriptions();

		//System.Void UnityEngine.SocialPlatforms.GameCenter.GameCenterPlatform::Internal_LoadAchievements(System.Object)
		void Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_LoadAchievements();
		Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_LoadAchievements();

		//System.Void UnityEngine.SocialPlatforms.GameCenter.GameCenterPlatform::Internal_LoadFriends(System.Object)
		void Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_LoadFriends();
		Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_LoadFriends();

		//System.Void UnityEngine.SocialPlatforms.GameCenter.GameCenterPlatform::Internal_LoadScores(System.String,System.Object)
		void Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_LoadScores();
		Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_LoadScores();

		//System.Void UnityEngine.SocialPlatforms.GameCenter.GameCenterPlatform::Internal_LoadUsers(System.String[],System.Object)
		void Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_LoadUsers();
		Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_LoadUsers();

		//System.Void UnityEngine.SocialPlatforms.GameCenter.GameCenterPlatform::Internal_ReportProgress(System.String,System.Double,System.Object)
		void Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_ReportProgress();
		Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_ReportProgress();

		//System.Void UnityEngine.SocialPlatforms.GameCenter.GameCenterPlatform::Internal_ReportScore(System.Int64,System.String,System.Object)
		void Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_ReportScore();
		Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_ReportScore();

		//System.Void UnityEngine.SocialPlatforms.GameCenter.GameCenterPlatform::Internal_ResetAllAchievements()
		void Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_ResetAllAchievements();
		Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_ResetAllAchievements();

		//System.Void UnityEngine.SocialPlatforms.GameCenter.GameCenterPlatform::Internal_ShowAchievementsUI()
		void Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_ShowAchievementsUI();
		Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_ShowAchievementsUI();

		//System.Void UnityEngine.SocialPlatforms.GameCenter.GameCenterPlatform::Internal_ShowDefaultAchievementBanner(System.Boolean)
		void Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_ShowDefaultAchievementBanner();
		Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_ShowDefaultAchievementBanner();

		//System.Void UnityEngine.SocialPlatforms.GameCenter.GameCenterPlatform::Internal_ShowLeaderboardUI()
		void Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_ShowLeaderboardUI();
		Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_ShowLeaderboardUI();

		//System.Void UnityEngine.SocialPlatforms.GameCenter.GameCenterPlatform::Internal_ShowSpecificLeaderboardUI(System.String,System.Int32)
		void Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_ShowSpecificLeaderboardUI();
		Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_ShowSpecificLeaderboardUI();

		//UnityEngine.Texture2D UnityEngine.SocialPlatforms.GameCenter.GameCenterPlatform::Internal_UserImage()
		void Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_UserImage();
		Register_UnityEngine_SocialPlatforms_GameCenter_GameCenterPlatform_Internal_UserImage();

	//End Registrations for type : UnityEngine.SocialPlatforms.GameCenter.GameCenterPlatform

	//Start Registrations for type : UnityEngine.SocialPlatforms.GameCenter.GcLeaderboard

		//System.Boolean UnityEngine.SocialPlatforms.GameCenter.GcLeaderboard::Loading()
		void Register_UnityEngine_SocialPlatforms_GameCenter_GcLeaderboard_Loading();
		Register_UnityEngine_SocialPlatforms_GameCenter_GcLeaderboard_Loading();

		//System.Void UnityEngine.SocialPlatforms.GameCenter.GcLeaderboard::Dispose()
		void Register_UnityEngine_SocialPlatforms_GameCenter_GcLeaderboard_Dispose();
		Register_UnityEngine_SocialPlatforms_GameCenter_GcLeaderboard_Dispose();

		//System.Void UnityEngine.SocialPlatforms.GameCenter.GcLeaderboard::Internal_LoadScores(System.String,System.Int32,System.Int32,System.String[],System.Int32,System.Int32,System.Object)
		void Register_UnityEngine_SocialPlatforms_GameCenter_GcLeaderboard_Internal_LoadScores();
		Register_UnityEngine_SocialPlatforms_GameCenter_GcLeaderboard_Internal_LoadScores();

	//End Registrations for type : UnityEngine.SocialPlatforms.GameCenter.GcLeaderboard

	//Start Registrations for type : UnityEngine.SortingLayer

		//System.Int32 UnityEngine.SortingLayer::GetLayerValueFromID(System.Int32)
		void Register_UnityEngine_SortingLayer_GetLayerValueFromID();
		Register_UnityEngine_SortingLayer_GetLayerValueFromID();

	//End Registrations for type : UnityEngine.SortingLayer

	//Start Registrations for type : UnityEngine.Sprite

		//System.Boolean UnityEngine.Sprite::get_packed()
		void Register_UnityEngine_Sprite_get_packed();
		Register_UnityEngine_Sprite_get_packed();

		//System.Single UnityEngine.Sprite::get_pixelsPerUnit()
		void Register_UnityEngine_Sprite_get_pixelsPerUnit();
		Register_UnityEngine_Sprite_get_pixelsPerUnit();

		//System.Void UnityEngine.Sprite::INTERNAL_get_border(UnityEngine.Vector4&)
		void Register_UnityEngine_Sprite_INTERNAL_get_border();
		Register_UnityEngine_Sprite_INTERNAL_get_border();

		//System.Void UnityEngine.Sprite::INTERNAL_get_rect(UnityEngine.Rect&)
		void Register_UnityEngine_Sprite_INTERNAL_get_rect();
		Register_UnityEngine_Sprite_INTERNAL_get_rect();

		//System.Void UnityEngine.Sprite::INTERNAL_get_textureRect(UnityEngine.Rect&)
		void Register_UnityEngine_Sprite_INTERNAL_get_textureRect();
		Register_UnityEngine_Sprite_INTERNAL_get_textureRect();

		//UnityEngine.Sprite UnityEngine.Sprite::INTERNAL_CALL_Create(UnityEngine.Texture2D,UnityEngine.Rect&,UnityEngine.Vector2&,System.Single,System.UInt32,UnityEngine.SpriteMeshType,UnityEngine.Vector4&)
		void Register_UnityEngine_Sprite_INTERNAL_CALL_Create();
		Register_UnityEngine_Sprite_INTERNAL_CALL_Create();

		//UnityEngine.Texture2D UnityEngine.Sprite::get_associatedAlphaSplitTexture()
		void Register_UnityEngine_Sprite_get_associatedAlphaSplitTexture();
		Register_UnityEngine_Sprite_get_associatedAlphaSplitTexture();

		//UnityEngine.Texture2D UnityEngine.Sprite::get_texture()
		void Register_UnityEngine_Sprite_get_texture();
		Register_UnityEngine_Sprite_get_texture();

	//End Registrations for type : UnityEngine.Sprite

	//Start Registrations for type : UnityEngine.SpriteRenderer

		//System.Void UnityEngine.SpriteRenderer::INTERNAL_get_color(UnityEngine.Color&)
		void Register_UnityEngine_SpriteRenderer_INTERNAL_get_color();
		Register_UnityEngine_SpriteRenderer_INTERNAL_get_color();

		//System.Void UnityEngine.SpriteRenderer::INTERNAL_set_color(UnityEngine.Color&)
		void Register_UnityEngine_SpriteRenderer_INTERNAL_set_color();
		Register_UnityEngine_SpriteRenderer_INTERNAL_set_color();

		//System.Void UnityEngine.SpriteRenderer::SetSprite_INTERNAL(UnityEngine.Sprite)
		void Register_UnityEngine_SpriteRenderer_SetSprite_INTERNAL();
		Register_UnityEngine_SpriteRenderer_SetSprite_INTERNAL();

	//End Registrations for type : UnityEngine.SpriteRenderer

	//Start Registrations for type : UnityEngine.Sprites.DataUtility

		//System.Void UnityEngine.Sprites.DataUtility::INTERNAL_CALL_GetInnerUV(UnityEngine.Sprite,UnityEngine.Vector4&)
		void Register_UnityEngine_Sprites_DataUtility_INTERNAL_CALL_GetInnerUV();
		Register_UnityEngine_Sprites_DataUtility_INTERNAL_CALL_GetInnerUV();

		//System.Void UnityEngine.Sprites.DataUtility::INTERNAL_CALL_GetOuterUV(UnityEngine.Sprite,UnityEngine.Vector4&)
		void Register_UnityEngine_Sprites_DataUtility_INTERNAL_CALL_GetOuterUV();
		Register_UnityEngine_Sprites_DataUtility_INTERNAL_CALL_GetOuterUV();

		//System.Void UnityEngine.Sprites.DataUtility::INTERNAL_CALL_GetPadding(UnityEngine.Sprite,UnityEngine.Vector4&)
		void Register_UnityEngine_Sprites_DataUtility_INTERNAL_CALL_GetPadding();
		Register_UnityEngine_Sprites_DataUtility_INTERNAL_CALL_GetPadding();

		//System.Void UnityEngine.Sprites.DataUtility::Internal_GetMinSize(UnityEngine.Sprite,UnityEngine.Vector2&)
		void Register_UnityEngine_Sprites_DataUtility_Internal_GetMinSize();
		Register_UnityEngine_Sprites_DataUtility_Internal_GetMinSize();

	//End Registrations for type : UnityEngine.Sprites.DataUtility

	//Start Registrations for type : UnityEngine.SystemInfo

		//System.String UnityEngine.SystemInfo::get_deviceUniqueIdentifier()
		void Register_UnityEngine_SystemInfo_get_deviceUniqueIdentifier();
		Register_UnityEngine_SystemInfo_get_deviceUniqueIdentifier();

		//UnityEngine.OperatingSystemFamily UnityEngine.SystemInfo::get_operatingSystemFamily()
		void Register_UnityEngine_SystemInfo_get_operatingSystemFamily();
		Register_UnityEngine_SystemInfo_get_operatingSystemFamily();

	//End Registrations for type : UnityEngine.SystemInfo

	//Start Registrations for type : UnityEngine.TextAsset

		//System.String UnityEngine.TextAsset::get_text()
		void Register_UnityEngine_TextAsset_get_text();
		Register_UnityEngine_TextAsset_get_text();

	//End Registrations for type : UnityEngine.TextAsset

	//Start Registrations for type : UnityEngine.TextGenerator

		//System.Boolean UnityEngine.TextGenerator::INTERNAL_CALL_Populate_Internal_cpp(UnityEngine.TextGenerator,System.String,UnityEngine.Font,UnityEngine.Color&,System.Int32,System.Single,System.Single,UnityEngine.FontStyle,System.Boolean,System.Boolean,System.Int32,System.Int32,System.Int32,System.Int32,System.Boolean,UnityEngine.TextAnchor,System.Single,System.Single,System.Single,System.Single,System.Boolean,System.Boolean,System.UInt32&)
		void Register_UnityEngine_TextGenerator_INTERNAL_CALL_Populate_Internal_cpp();
		Register_UnityEngine_TextGenerator_INTERNAL_CALL_Populate_Internal_cpp();

		//System.Int32 UnityEngine.TextGenerator::get_characterCount()
		void Register_UnityEngine_TextGenerator_get_characterCount();
		Register_UnityEngine_TextGenerator_get_characterCount();

		//System.Int32 UnityEngine.TextGenerator::get_fontSizeUsedForBestFit()
		void Register_UnityEngine_TextGenerator_get_fontSizeUsedForBestFit();
		Register_UnityEngine_TextGenerator_get_fontSizeUsedForBestFit();

		//System.Int32 UnityEngine.TextGenerator::get_lineCount()
		void Register_UnityEngine_TextGenerator_get_lineCount();
		Register_UnityEngine_TextGenerator_get_lineCount();

		//System.Int32 UnityEngine.TextGenerator::get_vertexCount()
		void Register_UnityEngine_TextGenerator_get_vertexCount();
		Register_UnityEngine_TextGenerator_get_vertexCount();

		//System.Void UnityEngine.TextGenerator::Dispose_cpp()
		void Register_UnityEngine_TextGenerator_Dispose_cpp();
		Register_UnityEngine_TextGenerator_Dispose_cpp();

		//System.Void UnityEngine.TextGenerator::GetCharactersInternal(System.Object)
		void Register_UnityEngine_TextGenerator_GetCharactersInternal();
		Register_UnityEngine_TextGenerator_GetCharactersInternal();

		//System.Void UnityEngine.TextGenerator::GetLinesInternal(System.Object)
		void Register_UnityEngine_TextGenerator_GetLinesInternal();
		Register_UnityEngine_TextGenerator_GetLinesInternal();

		//System.Void UnityEngine.TextGenerator::GetVerticesInternal(System.Object)
		void Register_UnityEngine_TextGenerator_GetVerticesInternal();
		Register_UnityEngine_TextGenerator_GetVerticesInternal();

		//System.Void UnityEngine.TextGenerator::INTERNAL_get_rectExtents(UnityEngine.Rect&)
		void Register_UnityEngine_TextGenerator_INTERNAL_get_rectExtents();
		Register_UnityEngine_TextGenerator_INTERNAL_get_rectExtents();

		//System.Void UnityEngine.TextGenerator::Init()
		void Register_UnityEngine_TextGenerator_Init();
		Register_UnityEngine_TextGenerator_Init();

		//UnityEngine.UICharInfo[] UnityEngine.TextGenerator::GetCharactersArray()
		void Register_UnityEngine_TextGenerator_GetCharactersArray();
		Register_UnityEngine_TextGenerator_GetCharactersArray();

		//UnityEngine.UILineInfo[] UnityEngine.TextGenerator::GetLinesArray()
		void Register_UnityEngine_TextGenerator_GetLinesArray();
		Register_UnityEngine_TextGenerator_GetLinesArray();

		//UnityEngine.UIVertex[] UnityEngine.TextGenerator::GetVerticesArray()
		void Register_UnityEngine_TextGenerator_GetVerticesArray();
		Register_UnityEngine_TextGenerator_GetVerticesArray();

	//End Registrations for type : UnityEngine.TextGenerator

	//Start Registrations for type : UnityEngine.Texture

		//System.Int32 UnityEngine.Texture::Internal_GetHeight(UnityEngine.Texture)
		void Register_UnityEngine_Texture_Internal_GetHeight();
		Register_UnityEngine_Texture_Internal_GetHeight();

		//System.Int32 UnityEngine.Texture::Internal_GetWidth(UnityEngine.Texture)
		void Register_UnityEngine_Texture_Internal_GetWidth();
		Register_UnityEngine_Texture_Internal_GetWidth();

		//System.Void UnityEngine.Texture::INTERNAL_get_texelSize(UnityEngine.Vector2&)
		void Register_UnityEngine_Texture_INTERNAL_get_texelSize();
		Register_UnityEngine_Texture_INTERNAL_get_texelSize();

		//System.Void UnityEngine.Texture::set_filterMode(UnityEngine.FilterMode)
		void Register_UnityEngine_Texture_set_filterMode();
		Register_UnityEngine_Texture_set_filterMode();

		//UnityEngine.TextureWrapMode UnityEngine.Texture::get_wrapMode()
		void Register_UnityEngine_Texture_get_wrapMode();
		Register_UnityEngine_Texture_get_wrapMode();

	//End Registrations for type : UnityEngine.Texture

	//Start Registrations for type : UnityEngine.Texture2D

		//System.Void UnityEngine.Texture2D::Apply(System.Boolean,System.Boolean)
		void Register_UnityEngine_Texture2D_Apply();
		Register_UnityEngine_Texture2D_Apply();

		//System.Void UnityEngine.Texture2D::INTERNAL_CALL_GetPixelBilinear(UnityEngine.Texture2D,System.Single,System.Single,UnityEngine.Color&)
		void Register_UnityEngine_Texture2D_INTERNAL_CALL_GetPixelBilinear();
		Register_UnityEngine_Texture2D_INTERNAL_CALL_GetPixelBilinear();

		//System.Void UnityEngine.Texture2D::INTERNAL_CALL_SetPixel(UnityEngine.Texture2D,System.Int32,System.Int32,UnityEngine.Color&)
		void Register_UnityEngine_Texture2D_INTERNAL_CALL_SetPixel();
		Register_UnityEngine_Texture2D_INTERNAL_CALL_SetPixel();

		//System.Void UnityEngine.Texture2D::Internal_Create(UnityEngine.Texture2D,System.Int32,System.Int32,UnityEngine.TextureFormat,System.Boolean,System.Boolean,System.IntPtr)
		void Register_UnityEngine_Texture2D_Internal_Create();
		Register_UnityEngine_Texture2D_Internal_Create();

		//UnityEngine.Texture2D UnityEngine.Texture2D::get_whiteTexture()
		void Register_UnityEngine_Texture2D_get_whiteTexture();
		Register_UnityEngine_Texture2D_get_whiteTexture();

	//End Registrations for type : UnityEngine.Texture2D

	//Start Registrations for type : UnityEngine.Time

		//System.Int32 UnityEngine.Time::get_frameCount()
		void Register_UnityEngine_Time_get_frameCount();
		Register_UnityEngine_Time_get_frameCount();

		//System.Single UnityEngine.Time::get_deltaTime()
		void Register_UnityEngine_Time_get_deltaTime();
		Register_UnityEngine_Time_get_deltaTime();

		//System.Single UnityEngine.Time::get_fixedDeltaTime()
		void Register_UnityEngine_Time_get_fixedDeltaTime();
		Register_UnityEngine_Time_get_fixedDeltaTime();

		//System.Single UnityEngine.Time::get_realtimeSinceStartup()
		void Register_UnityEngine_Time_get_realtimeSinceStartup();
		Register_UnityEngine_Time_get_realtimeSinceStartup();

		//System.Single UnityEngine.Time::get_time()
		void Register_UnityEngine_Time_get_time();
		Register_UnityEngine_Time_get_time();

		//System.Single UnityEngine.Time::get_timeScale()
		void Register_UnityEngine_Time_get_timeScale();
		Register_UnityEngine_Time_get_timeScale();

		//System.Single UnityEngine.Time::get_unscaledDeltaTime()
		void Register_UnityEngine_Time_get_unscaledDeltaTime();
		Register_UnityEngine_Time_get_unscaledDeltaTime();

		//System.Single UnityEngine.Time::get_unscaledTime()
		void Register_UnityEngine_Time_get_unscaledTime();
		Register_UnityEngine_Time_get_unscaledTime();

		//System.Void UnityEngine.Time::set_timeScale(System.Single)
		void Register_UnityEngine_Time_set_timeScale();
		Register_UnityEngine_Time_set_timeScale();

	//End Registrations for type : UnityEngine.Time

	//Start Registrations for type : UnityEngine.TouchScreenKeyboard

		//System.Boolean UnityEngine.TouchScreenKeyboard::get_active()
		void Register_UnityEngine_TouchScreenKeyboard_get_active();
		Register_UnityEngine_TouchScreenKeyboard_get_active();

		//System.Boolean UnityEngine.TouchScreenKeyboard::get_canGetSelection()
		void Register_UnityEngine_TouchScreenKeyboard_get_canGetSelection();
		Register_UnityEngine_TouchScreenKeyboard_get_canGetSelection();

		//System.Boolean UnityEngine.TouchScreenKeyboard::get_done()
		void Register_UnityEngine_TouchScreenKeyboard_get_done();
		Register_UnityEngine_TouchScreenKeyboard_get_done();

		//System.Boolean UnityEngine.TouchScreenKeyboard::get_wasCanceled()
		void Register_UnityEngine_TouchScreenKeyboard_get_wasCanceled();
		Register_UnityEngine_TouchScreenKeyboard_get_wasCanceled();

		//System.String UnityEngine.TouchScreenKeyboard::get_text()
		void Register_UnityEngine_TouchScreenKeyboard_get_text();
		Register_UnityEngine_TouchScreenKeyboard_get_text();

		//System.Void UnityEngine.TouchScreenKeyboard::Destroy()
		void Register_UnityEngine_TouchScreenKeyboard_Destroy();
		Register_UnityEngine_TouchScreenKeyboard_Destroy();

		//System.Void UnityEngine.TouchScreenKeyboard::GetSelectionInternal(System.Int32&,System.Int32&)
		void Register_UnityEngine_TouchScreenKeyboard_GetSelectionInternal();
		Register_UnityEngine_TouchScreenKeyboard_GetSelectionInternal();

		//System.Void UnityEngine.TouchScreenKeyboard::TouchScreenKeyboard_InternalConstructorHelper(UnityEngine.TouchScreenKeyboard_InternalConstructorHelperArguments&,System.String,System.String)
		void Register_UnityEngine_TouchScreenKeyboard_TouchScreenKeyboard_InternalConstructorHelper();
		Register_UnityEngine_TouchScreenKeyboard_TouchScreenKeyboard_InternalConstructorHelper();

		//System.Void UnityEngine.TouchScreenKeyboard::set_active(System.Boolean)
		void Register_UnityEngine_TouchScreenKeyboard_set_active();
		Register_UnityEngine_TouchScreenKeyboard_set_active();

		//System.Void UnityEngine.TouchScreenKeyboard::set_hideInput(System.Boolean)
		void Register_UnityEngine_TouchScreenKeyboard_set_hideInput();
		Register_UnityEngine_TouchScreenKeyboard_set_hideInput();

		//System.Void UnityEngine.TouchScreenKeyboard::set_text(System.String)
		void Register_UnityEngine_TouchScreenKeyboard_set_text();
		Register_UnityEngine_TouchScreenKeyboard_set_text();

	//End Registrations for type : UnityEngine.TouchScreenKeyboard

	//Start Registrations for type : UnityEngine.Transform

		//System.Boolean UnityEngine.Transform::IsChildOf(UnityEngine.Transform)
		void Register_UnityEngine_Transform_IsChildOf();
		Register_UnityEngine_Transform_IsChildOf();

		//System.Boolean UnityEngine.Transform::get_hasChanged()
		void Register_UnityEngine_Transform_get_hasChanged();
		Register_UnityEngine_Transform_get_hasChanged();

		//System.Int32 UnityEngine.Transform::GetChildCount()
		void Register_UnityEngine_Transform_GetChildCount();
		Register_UnityEngine_Transform_GetChildCount();

		//System.Int32 UnityEngine.Transform::GetSiblingIndex()
		void Register_UnityEngine_Transform_GetSiblingIndex();
		Register_UnityEngine_Transform_GetSiblingIndex();

		//System.Int32 UnityEngine.Transform::get_childCount()
		void Register_UnityEngine_Transform_get_childCount();
		Register_UnityEngine_Transform_get_childCount();

		//System.Int32 UnityEngine.Transform::get_hierarchyCapacity()
		void Register_UnityEngine_Transform_get_hierarchyCapacity();
		Register_UnityEngine_Transform_get_hierarchyCapacity();

		//System.Int32 UnityEngine.Transform::get_hierarchyCount()
		void Register_UnityEngine_Transform_get_hierarchyCount();
		Register_UnityEngine_Transform_get_hierarchyCount();

		//System.Void UnityEngine.Transform::DetachChildren()
		void Register_UnityEngine_Transform_DetachChildren();
		Register_UnityEngine_Transform_DetachChildren();

		//System.Void UnityEngine.Transform::INTERNAL_CALL_GetLocalEulerAngles(UnityEngine.Transform,UnityEngine.RotationOrder,UnityEngine.Vector3&)
		void Register_UnityEngine_Transform_INTERNAL_CALL_GetLocalEulerAngles();
		Register_UnityEngine_Transform_INTERNAL_CALL_GetLocalEulerAngles();

		//System.Void UnityEngine.Transform::INTERNAL_CALL_InverseTransformDirection(UnityEngine.Transform,UnityEngine.Vector3&,UnityEngine.Vector3&)
		void Register_UnityEngine_Transform_INTERNAL_CALL_InverseTransformDirection();
		Register_UnityEngine_Transform_INTERNAL_CALL_InverseTransformDirection();

		//System.Void UnityEngine.Transform::INTERNAL_CALL_InverseTransformPoint(UnityEngine.Transform,UnityEngine.Vector3&,UnityEngine.Vector3&)
		void Register_UnityEngine_Transform_INTERNAL_CALL_InverseTransformPoint();
		Register_UnityEngine_Transform_INTERNAL_CALL_InverseTransformPoint();

		//System.Void UnityEngine.Transform::INTERNAL_CALL_InverseTransformVector(UnityEngine.Transform,UnityEngine.Vector3&,UnityEngine.Vector3&)
		void Register_UnityEngine_Transform_INTERNAL_CALL_InverseTransformVector();
		Register_UnityEngine_Transform_INTERNAL_CALL_InverseTransformVector();

		//System.Void UnityEngine.Transform::INTERNAL_CALL_LookAt(UnityEngine.Transform,UnityEngine.Vector3&,UnityEngine.Vector3&)
		void Register_UnityEngine_Transform_INTERNAL_CALL_LookAt();
		Register_UnityEngine_Transform_INTERNAL_CALL_LookAt();

		//System.Void UnityEngine.Transform::INTERNAL_CALL_RotateAround(UnityEngine.Transform,UnityEngine.Vector3&,System.Single)
		void Register_UnityEngine_Transform_INTERNAL_CALL_RotateAround();
		Register_UnityEngine_Transform_INTERNAL_CALL_RotateAround();

		//System.Void UnityEngine.Transform::INTERNAL_CALL_RotateAroundInternal(UnityEngine.Transform,UnityEngine.Vector3&,System.Single)
		void Register_UnityEngine_Transform_INTERNAL_CALL_RotateAroundInternal();
		Register_UnityEngine_Transform_INTERNAL_CALL_RotateAroundInternal();

		//System.Void UnityEngine.Transform::INTERNAL_CALL_RotateAroundLocal(UnityEngine.Transform,UnityEngine.Vector3&,System.Single)
		void Register_UnityEngine_Transform_INTERNAL_CALL_RotateAroundLocal();
		Register_UnityEngine_Transform_INTERNAL_CALL_RotateAroundLocal();

		//System.Void UnityEngine.Transform::INTERNAL_CALL_SetLocalEulerAngles(UnityEngine.Transform,UnityEngine.Vector3&,UnityEngine.RotationOrder)
		void Register_UnityEngine_Transform_INTERNAL_CALL_SetLocalEulerAngles();
		Register_UnityEngine_Transform_INTERNAL_CALL_SetLocalEulerAngles();

		//System.Void UnityEngine.Transform::INTERNAL_CALL_TransformDirection(UnityEngine.Transform,UnityEngine.Vector3&,UnityEngine.Vector3&)
		void Register_UnityEngine_Transform_INTERNAL_CALL_TransformDirection();
		Register_UnityEngine_Transform_INTERNAL_CALL_TransformDirection();

		//System.Void UnityEngine.Transform::INTERNAL_CALL_TransformPoint(UnityEngine.Transform,UnityEngine.Vector3&,UnityEngine.Vector3&)
		void Register_UnityEngine_Transform_INTERNAL_CALL_TransformPoint();
		Register_UnityEngine_Transform_INTERNAL_CALL_TransformPoint();

		//System.Void UnityEngine.Transform::INTERNAL_CALL_TransformVector(UnityEngine.Transform,UnityEngine.Vector3&,UnityEngine.Vector3&)
		void Register_UnityEngine_Transform_INTERNAL_CALL_TransformVector();
		Register_UnityEngine_Transform_INTERNAL_CALL_TransformVector();

		//System.Void UnityEngine.Transform::INTERNAL_get_localPosition(UnityEngine.Vector3&)
		void Register_UnityEngine_Transform_INTERNAL_get_localPosition();
		Register_UnityEngine_Transform_INTERNAL_get_localPosition();

		//System.Void UnityEngine.Transform::INTERNAL_get_localRotation(UnityEngine.Quaternion&)
		void Register_UnityEngine_Transform_INTERNAL_get_localRotation();
		Register_UnityEngine_Transform_INTERNAL_get_localRotation();

		//System.Void UnityEngine.Transform::INTERNAL_get_localScale(UnityEngine.Vector3&)
		void Register_UnityEngine_Transform_INTERNAL_get_localScale();
		Register_UnityEngine_Transform_INTERNAL_get_localScale();

		//System.Void UnityEngine.Transform::INTERNAL_get_localToWorldMatrix(UnityEngine.Matrix4x4&)
		void Register_UnityEngine_Transform_INTERNAL_get_localToWorldMatrix();
		Register_UnityEngine_Transform_INTERNAL_get_localToWorldMatrix();

		//System.Void UnityEngine.Transform::INTERNAL_get_lossyScale(UnityEngine.Vector3&)
		void Register_UnityEngine_Transform_INTERNAL_get_lossyScale();
		Register_UnityEngine_Transform_INTERNAL_get_lossyScale();

		//System.Void UnityEngine.Transform::INTERNAL_get_position(UnityEngine.Vector3&)
		void Register_UnityEngine_Transform_INTERNAL_get_position();
		Register_UnityEngine_Transform_INTERNAL_get_position();

		//System.Void UnityEngine.Transform::INTERNAL_get_rotation(UnityEngine.Quaternion&)
		void Register_UnityEngine_Transform_INTERNAL_get_rotation();
		Register_UnityEngine_Transform_INTERNAL_get_rotation();

		//System.Void UnityEngine.Transform::INTERNAL_get_worldToLocalMatrix(UnityEngine.Matrix4x4&)
		void Register_UnityEngine_Transform_INTERNAL_get_worldToLocalMatrix();
		Register_UnityEngine_Transform_INTERNAL_get_worldToLocalMatrix();

		//System.Void UnityEngine.Transform::INTERNAL_set_localPosition(UnityEngine.Vector3&)
		void Register_UnityEngine_Transform_INTERNAL_set_localPosition();
		Register_UnityEngine_Transform_INTERNAL_set_localPosition();

		//System.Void UnityEngine.Transform::INTERNAL_set_localRotation(UnityEngine.Quaternion&)
		void Register_UnityEngine_Transform_INTERNAL_set_localRotation();
		Register_UnityEngine_Transform_INTERNAL_set_localRotation();

		//System.Void UnityEngine.Transform::INTERNAL_set_localScale(UnityEngine.Vector3&)
		void Register_UnityEngine_Transform_INTERNAL_set_localScale();
		Register_UnityEngine_Transform_INTERNAL_set_localScale();

		//System.Void UnityEngine.Transform::INTERNAL_set_position(UnityEngine.Vector3&)
		void Register_UnityEngine_Transform_INTERNAL_set_position();
		Register_UnityEngine_Transform_INTERNAL_set_position();

		//System.Void UnityEngine.Transform::INTERNAL_set_rotation(UnityEngine.Quaternion&)
		void Register_UnityEngine_Transform_INTERNAL_set_rotation();
		Register_UnityEngine_Transform_INTERNAL_set_rotation();

		//System.Void UnityEngine.Transform::SetAsFirstSibling()
		void Register_UnityEngine_Transform_SetAsFirstSibling();
		Register_UnityEngine_Transform_SetAsFirstSibling();

		//System.Void UnityEngine.Transform::SetAsLastSibling()
		void Register_UnityEngine_Transform_SetAsLastSibling();
		Register_UnityEngine_Transform_SetAsLastSibling();

		//System.Void UnityEngine.Transform::SetParent(UnityEngine.Transform,System.Boolean)
		void Register_UnityEngine_Transform_SetParent();
		Register_UnityEngine_Transform_SetParent();

		//System.Void UnityEngine.Transform::SetSiblingIndex(System.Int32)
		void Register_UnityEngine_Transform_SetSiblingIndex();
		Register_UnityEngine_Transform_SetSiblingIndex();

		//System.Void UnityEngine.Transform::set_hasChanged(System.Boolean)
		void Register_UnityEngine_Transform_set_hasChanged();
		Register_UnityEngine_Transform_set_hasChanged();

		//System.Void UnityEngine.Transform::set_hierarchyCapacity(System.Int32)
		void Register_UnityEngine_Transform_set_hierarchyCapacity();
		Register_UnityEngine_Transform_set_hierarchyCapacity();

		//System.Void UnityEngine.Transform::set_parentInternal(UnityEngine.Transform)
		void Register_UnityEngine_Transform_set_parentInternal();
		Register_UnityEngine_Transform_set_parentInternal();

		//UnityEngine.Transform UnityEngine.Transform::Find(System.String)
		void Register_UnityEngine_Transform_Find();
		Register_UnityEngine_Transform_Find();

		//UnityEngine.Transform UnityEngine.Transform::GetChild(System.Int32)
		void Register_UnityEngine_Transform_GetChild();
		Register_UnityEngine_Transform_GetChild();

		//UnityEngine.Transform UnityEngine.Transform::get_parentInternal()
		void Register_UnityEngine_Transform_get_parentInternal();
		Register_UnityEngine_Transform_get_parentInternal();

		//UnityEngine.Transform UnityEngine.Transform::get_root()
		void Register_UnityEngine_Transform_get_root();
		Register_UnityEngine_Transform_get_root();

	//End Registrations for type : UnityEngine.Transform

	//Start Registrations for type : UnityEngine.UnhandledExceptionHandler

		//System.Void UnityEngine.UnhandledExceptionHandler::NativeUnhandledExceptionHandler()
		void Register_UnityEngine_UnhandledExceptionHandler_NativeUnhandledExceptionHandler();
		Register_UnityEngine_UnhandledExceptionHandler_NativeUnhandledExceptionHandler();

	//End Registrations for type : UnityEngine.UnhandledExceptionHandler

	//Start Registrations for type : UnityEngine.UnityLogWriter

		//System.Void UnityEngine.UnityLogWriter::WriteStringToUnityLog(System.String)
		void Register_UnityEngine_UnityLogWriter_WriteStringToUnityLog();
		Register_UnityEngine_UnityLogWriter_WriteStringToUnityLog();

	//End Registrations for type : UnityEngine.UnityLogWriter

	//Start Registrations for type : UnityEngine.WWW

		//System.Boolean UnityEngine.WWW::get_isDone()
		void Register_UnityEngine_WWW_get_isDone();
		Register_UnityEngine_WWW_get_isDone();

		//System.Byte[] UnityEngine.WWW::get_bytes()
		void Register_UnityEngine_WWW_get_bytes();
		Register_UnityEngine_WWW_get_bytes();

		//System.String UnityEngine.WWW::get_error()
		void Register_UnityEngine_WWW_get_error();
		Register_UnityEngine_WWW_get_error();

		//System.String UnityEngine.WWW::get_responseHeadersString()
		void Register_UnityEngine_WWW_get_responseHeadersString();
		Register_UnityEngine_WWW_get_responseHeadersString();

		//System.Void UnityEngine.WWW::DestroyWWW(System.Boolean)
		void Register_UnityEngine_WWW_DestroyWWW();
		Register_UnityEngine_WWW_DestroyWWW();

		//System.Void UnityEngine.WWW::InitWWW(System.String,System.Byte[],System.String[])
		void Register_UnityEngine_WWW_InitWWW();
		Register_UnityEngine_WWW_InitWWW();

	//End Registrations for type : UnityEngine.WWW

}
